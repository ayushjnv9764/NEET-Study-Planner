# NEET CRACKER — Ayush's roadmap (pasted 2026-09-09, msgs 250-256)

North star Ayush stated: the app must drive Learn → Practice → Test → Analyze →
Find mistakes → Revise → Improve → Repeat → Crack NEET, not just be a question app.

Status legend: [x] done in-app · [~] partial · [ ] not started.
Base = v6.1. Content reality as of 2026-09-09: BOT 2393 (NCERT line-by-line,
20 ch), PHY ~63 (starter + KPP-06×25), CHEM ~12, ZOO 0. True 45/45/45/45 NEET
papers impossible until Chem/Zoo/Phys packs exist → PDF import pipeline is the
content unlock (see roadmap notes). Ayush's top-10 priority list at end.

## Phase 1 — Core app experience
- [x] Home screen has hero/countdown/streak/goal (Home tab, v4-v6) — roadmap asks for welcome msg, continue-learning, questions-solved-today, quick subject access (some exist, review vs list)
- [ ] Nav restructure to Test/Revision/Analytics areas (current tabs: Home/Study/Practice/Progress/Settings). NOTE: roadmap tabs drop the Study planner that runs Ayush's Momentum day — keep planner.
- [ ] Splash screen + logo animation + loading/error states
- [x] UI cards/buttons/fonts/animations (v5 futuristic + v6.1 motion) — [ ] Dark mode / light mode toggle

## Phase 2 — Question practice system
- [x] Subject selection → QuizActivity (Practice tab "Pick a subject") — msg 250 wants this de-emphasized in favor of a real TEST hub
- [~] Chapter selection: Botany chapters wired; general Class 11/12 → Chapter → Topic drill tree not built; packs need class/topic fields
- [ ] Question filters: easy/medium/hard/PYQ/NCERT/important/random/bookmarked/wrong — needs per-question tags (difficulty, year, source)
- [~] Question screen: has #/total, timer, bookmark, next; lacks report button; prev/clear exist in exam mode; QuizActivity is instant-feedback engine
- [x] Answer feedback (QuizActivity): correct/wrong + explanation; lacks difficulty/Ncert-ref structured blocks
- [~] Question actions: bookmark, mark-for-revision/difficult/note/retry-later — only bookmark today

## Phase 3 — Test system  (highest priority for Ayush)
- [x] Chapter test (v7.0 Test Center: chapter cards auto-show for chapters with ≥8 Qs; Botany 20 + KPP; no #-of-questions/time picker yet)
- [x] Subject test (v7.0: per-subject test cards) 
- [ ] Part test: multi-chapter selection across subjects — not built
- [x] Full NEET mock (v7.0): subject-wise assembly ≤45/subject in NEET order Physics→Chemistry→Botany→Zoology, SECTION banners in-test. Grows as packs arrive. Real 200-min/180-Q spec still ~approximate (54 s/Q).
- [x] Test features: countdown, palette, clear response, prev/next, submit, auto-submit
- [~] Palette states (v7.0: current cyan, answered, amber-ring = marked-for-review toggle; no distinct not-answered/not-visited yet)

## Phase 4 — Result system
- [x] Result screen: score, correct/wrong/unattempted, accuracy, time, subject split, verdict, mocks-taken/best
- [x] NEET marking +4/−1/0
- [x] Subject-wise result rows
- [ ] Result actions: retry wrongs, view solutions, share, new test (partially — "Review my mistakes" exists)

## Phase 5 — Mistake analysis
- [ ] Mistake classification (conceptual/factual/calc/silly/misread/guess) + dashboard + recommendations — not built; would need per-mistake self-report UI

## Phase 6 — Revision system
- [x] Revision home basics: bookmarks + wrong questions + drill mistakes
- [x] Wrong-question book auto-saves (wrong q, dates, attempts)
- [ ] Spaced revision 1/3/7/15/30-day schedule + "N questions due today" reminder — not built
- [ ] Weak-chapter auto-detect (below 50% weak etc.)

## Phase 7 — Analytics
- [~] Overall/subject accuracy + answered counts exist (Progress tab); no chapter analytics, weak detection, weekly/monthly trends, score progress

## Phase 8 — Planner
- [x] Daily plan (My Day, Momentum-synced), tasks/goals/timer exist partially (Study tab); roadmap's question-goal (e.g. 200/day) tracking partially exists on Home

## Phase 9 — NCERT system
- [x] Botany NCERT line-by-line = the 2,393-Q bank; Zoology/Chem/Phys packs pending (msg 226 standing ask)
- [ ] Important-lines/highlight/notes system — not built

## Phase 10 — PYQ system
- [ ] PYQ home/filters/years/analysis — not built; needs tagged PYQ content

## Phases 11-13 — Subject toolkits (formula book, reactions, biology facts)
- [ ] Formula/reaction/revision books — not built (long-tail, content-heavy)

## Phase 14 — Bookmarks
- [~] Bookmark + remove + drill exist; no categories/notes/practice-from-category

## Phase 15 — Notes
- [ ] Personal notes per subject/chapter — not built

## Phase 16 — Gamification
- [x] Streak exists; [ ] achievements, daily challenge — not built

## Phase 17 — Notifications
- [x] Study/bed-check reminders exist (Alarms); [ ] revision/test/day-goal reminders

## Phase 18 — Search
- [ ] Global search across chapters/topics/questions — not built

## Phase 19 — Profile/Settings
- [x] Settings; [ ] profile stats page / target-exam fields

## Phase 20 — Data
- [x] Progress persisted offline (SharedPreferences+JSON); [~] backup/restore (none, only stored in-app); no export

## Phase 21 — Content management
- [~] Question DB has id/subject/chapter/q/options/answer; no difficulty/explanation-on-every-q/PYQ/tags. Quality: Botany 2393 verified clean.

## Phase 22 — Final structure (nav vision, msg 255)
HOME · PRACTICE · TEST · REVISION · NCERT · PYQs · ANALYTICS · PLANNER · PROFILE.
Bottom bar can hold ~5-6; recommend nesting NCERT/PYQs/books under a library hub.

---
## Ayush dev order (top of his list)
1 Home screen → 2 Nav → 3 Question practice → 4 Chapter select → 5 Filters →
6 Bookmarks → 7 Wrong-q system → 8 Chapter test → 9 Subject test → 10 Full mock
→ 11 Result → 12 Marking → 13 Test analysis → 14 Mistake class → 15 Revision →
16 Analytics → 17 Weak chapters → 18 Daily planner → ... 20 NCERT → 21 PYQ ...
(Items with [x] above already satisfy most of steps 1-18 in current form.)

## Top-10 for "next version" (his words)
TEST SYSTEM · RESULT SYSTEM · WRONG QUESTION BOOK · BOOKMARK SYSTEM ·
CHAPTER-WISE PRACTICE · ANALYTICS · REVISION SYSTEM · PYQ SYSTEM ·
NCERT BIOLOGY · FULL NEET MOCK.

## Open product decisions (2026-09-09, updated after v7.0)
- PDF→import standing content path confirmed by Ayush ("I will provide later"); Import already reads a JSON pack tagged s/chapter; assistant converts PDF→JSON. Task #36.
- v7.0 Test Center shipped (subject-wise full mock + chapter/subject cards + mark-for-review). Still open: Part test picker, per-test Q-count/time picker.
- ✅ v8.0 Command Center core SHIPPED (task #38 closed) — Coach.kt rule engine + ANC COACH card on Home: live Qs/focus/accuracy/streak + TODAY'S PRIORITY (weakest chapter, WEAK/AVG/GOOD/STRONG banding + one-line advice + one-tap chapter drill). APK msg 277. Still parked from the ANC spec: XP/levels/achievements, splash+opening animation, glassmorphism/command-center reskin, mission/daily-plan generator, circular timer, health-check radar — each needs data that Coach already rolls up, so they slot in as v9+. Big visual reskin gated on Ayush testing v8.0.
- ✅ v8.1 Momentum sync SHIPPED (task #39 closed) — MomentumPlan.kt loads assets/momentum_plan.json (CNR-1 course flow, Day 1 = 10-Jul-2026 → Day 194 = 19-Mar-2027, 194 class days Mon–Sat + 7 PT/MT + 8 holidays). Home MOMENTUM · CNR-1 card (warm-orange, below ANC COACH): "Day N of 194", today's Phy/Chem/Bot/Zoo chapters via colored chips, next plan test countdown, Open full Momentum plan → MomentumPlanActivity (today hero + 10 coming class days + upcoming tests). Version 8.1 (code 15). APK this session. Parked for v8.2: Ayan's NRTS Real-Test 2027 series as a separately-named plan surface (msg 305, differentiated from Ayush) and Ayush's ELITE 28-Test series calendar (msg 303) so Momentum-test countdowns come from the real series. Practice-test PDFs (msgs 285–297) awaiting scope answer from Ayush.
- ✅ v8.2 ELITE test series SHIPPED (task #43 closed, msg 364) — Ayush's ELITE NEET-2027 28-Sunday series (msg 303/351, ask 350/358). assets/elite_series.json = 28 tests (23-Aug-26 → 24-Apr-27; Part Tests 1-18 with per-subject chapter lists, Cumulative 4/8/12/16 with covers:[n], Mocks 19-28 full). EliteSeries.kt: loader + next(date) + prepFor() resolving series chapter names → app (subjectKey, idx) by exact norm across buckets (bio topics Momentum files under the other bio subject — Biological Classification/Ecology/Microbes→BOT-in-app, Evolution/Biomolecules-in-bio → resolved by name); untracked names shown "•". MomentumPlanActivity retitled "Plan + Test Series": NEXT-UP hero (Part Test 3, 20-Sep: per-subject ✓/○ prep from Store.isDone) + full series list. Home momentum card Next: now prefers the NEAREST test across Elite vs CNR-1 flow (Elite #3 20-Sep beats PT-4 21-Nov). Version 8.2 (code 16). Parked next: Ayan NRTS (task #40), PYQ NEET 2024 pilot (task #42).
- ✅ v8.2.1 (code 17, 2026-09-09) — Ayush's msg 368/372 correction: the CNR-1 momentum plan is NOT removed. His msg 368 "remove previous momentum plan" meant the v8.2 layout had buried today's view under the 28-test ELITE list. Fix: MomentumPlanActivity shows the MOMENTUM · CNR-1 current-day card ("Day 49 of 194" = today, topics from the lecture-planner PDF source mom_raw.txt — Day 49 09-Sep: KTG | Isomerism | – | Biomolecules) FIRST, ELITE series beneath; auto-advances by date. My earlier scope-check (msg 370) was over-interpreting — confirmed keep CNR-1, nothing deleted.
- ✅ v8.3 Ayan NRTS SHIPPED (task #40 closed, msg 381) — Ayan's NRTS Real-Test 2027 series (msg 305; go msg 378). assets/ayan_nrts.json = 21 Sunday tests 26-Jul-26→11-Apr-27; scope part/xi(12, "11th full syllabus")/full(15-21). AyanSeries.kt: loader + next (NRTS 04, 20-Sep-26, cumulative of 1-3) + label "NRTS NN". AyanPlanActivity (manifest-registered): teal (0xFF00695C) next-test hero with per-subject chapter lists (no prep ticks — Ayan's prep isn't in the app) + full remaining-test list. Home teal card "AYAN · NRTS REAL TEST / Ayan's plan — separate from yours" under the Momentum card → activity. Day-49 card + ELITE untouched. Version 8.3 (code 18). Parked next: PYQ NEET-2024 pilot (task #42).
- Nav restructure gated; keep Study/planner tab.
