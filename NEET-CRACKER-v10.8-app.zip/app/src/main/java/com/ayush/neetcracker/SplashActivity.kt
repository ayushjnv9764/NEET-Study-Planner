package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * v8.7 brand splash. Timed reveal per Ayush's spec:
 * 0.0 invisible -> 0.3s logo fades in -> 0.5s logo scales ->
 * 0.8s NEET CRACKER -> 1.2s AYUSH EDITION -> ~1.9s smooth transition.
 * Routes to Onboarding on a fresh install, otherwise straight to MainActivity.
 */
class SplashActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val steps = ArrayList<Runnable>()
    private var launched = false

    private lateinit var emblem: FrameLayout
    private lateinit var ring: View
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var tag: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.background = Fx.gradient(0xFF0B1233.toInt(), 0xFF3B2F8F.toInt(), 0xFF6C5CE7.toInt())
        setContentView(root)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        root.addView(col, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ---- emblem: ring + gradient disc + monogram ----
        emblem = FrameLayout(this)
        val disc = GradientDrawable()
        disc.shape = GradientDrawable.OVAL
        disc.orientation = GradientDrawable.Orientation.TL_BR
        disc.colors = intArrayOf(0xFF22D3EE.toInt(), 0xFF6C5CE7.toInt())
        emblem.background = disc

        ring = View(this)
        val ringBg = GradientDrawable()
        ringBg.shape = GradientDrawable.OVAL
        ringBg.setStroke(Ui.dp(this, 2), 0x6622D3EE.toInt())
        ring.background = ringBg

        val wrap = FrameLayout(this)
        val s = Ui.dp(this, 136)
        wrap.addView(ring, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        val ds = Ui.dp(this, 112)
        wrap.addView(emblem, FrameLayout.LayoutParams(ds, ds, Gravity.CENTER))

        val mono = Ui.text(this, "NC", 34f, Color.WHITE, true)
        mono.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        mono.gravity = Gravity.CENTER
        emblem.addView(mono, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        emblem.alpha = 0f
        emblem.scaleX = 0.92f
        emblem.scaleY = 0.92f

        wrap.layoutParams = LinearLayout.LayoutParams(s, s)
        col.addView(wrap)

        // ---- brand copy ----
        title = brand("NEET CRACKER", 32f, Color.WHITE, 0.14f)
        val l1 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l1.topMargin = Ui.dp(this, 34)
        col.addView(title, l1)

        sub = brand("BY AYUSH", 15f, 0xFF22D3EE.toInt(), 0.42f)
        val l2 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l2.topMargin = Ui.dp(this, 10)
        col.addView(sub, l2)

        tag = brand("STUDY SMART · PRACTICE HARD · CRACK NEET", 11f, 0xFFFFC24B.toInt(), 0.18f)
        val l3 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l3.topMargin = Ui.dp(this, 28)
        col.addView(tag, l3)

        listOf(title, sub, tag).forEach { it.alpha = 0f }

        // v9.7: warm the heavy caches while the splash animation plays (~2 s of
        // idle screen), so the first Practice/Quiz screen doesn't parse the
        // 1.1 MB question bank on the UI thread.
        Thread { Store.warm(this) }.start()

        run()
    }

    private fun brand(s: String, sp: Float, col: Int, ls: Float): TextView {
        val tv = Ui.text(this, s, sp, col, true)
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        tv.letterSpacing = ls
        return tv
    }

    private fun run() {
        delay(160) { // ~0.3s: logo fades in + slight scale
            emblem.animate().alpha(1f).scaleX(1.06f).scaleY(1.06f)
                .setDuration(380).setInterpolator(DecelerateInterpolator(1.4f)).start()
        }
        delay(620) { // ~0.8s: settle scale, ring glow pulse
            emblem.animate().scaleX(1f).scaleY(1f).setDuration(240).start()
            ring.animate().scaleX(1.14f).scaleY(1.14f).alpha(0.5f).setDuration(320)
                .withEndAction {
                    ring.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(240)
                        .setInterpolator(OvershootInterpolator(1.6f)).start()
                }.start()
        }
        delay(830) { reveal(title) }  // ~0.8s: NEET CRACKER
        delay(1230) { reveal(sub) }   // ~1.2s: AYUSH EDITION
        delay(1530) { reveal(tag) }   // tagline
        delay(1960) { goNext() }      // ~1.8s+: hand off
    }

    /** Fade + tiny rise-in for a brand line. */
    private fun reveal(v: View) {
        v.animate().alpha(1f).translationY(0f).setDuration(260)
            .setInterpolator(DecelerateInterpolator(1.4f)).start()
    }

    private fun delay(ms: Long, block: () -> Unit) {
        val r = Runnable { block() }
        steps.add(r)
        handler.postDelayed(r, ms)
    }

    override fun onDestroy() {
        steps.forEach { handler.removeCallbacks(it) }
        super.onDestroy()
    }

    private fun goNext() {
        if (launched) return
        launched = true
        val target = if (Store.needsOnboarding(this))
            Intent(this, OnboardingActivity::class.java)
        else Intent(this, MainActivity::class.java)
        startActivity(target)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
