package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Weak-topic analysis (design spec — "weak-topic detection" / "performance"):
 * reads the real attempt log through Coach.chapterStats and names the chapters
 * actually holding Ayush back, worst first, each with a one-tap drill.
 *
 * Pure analysis over data already recorded — no new storage, no engine change.
 * A chapter only appears in FOCUS HERE once it has been attempted at least once,
 * so the screen stays honest: it shows real performance, not guesses.
 */
class WeakTopicsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val c = this
        val stats = Coach.chapterStats(c)                     // busiest first
        val practised = stats.filter { it.answered > 0 }
        val overall = Coach.overallAccuracy(c)

        val root = Ui.column(c)
        root.setBackgroundColor(Ui.color(c, R.color.bg))
        root.addView(header())

        val sv = ScrollView(c)
        val col = Ui.column(c)
        col.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 28))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(Ui.text(c, "Where to focus next — from your real attempts.", 14f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 12))

        if (practised.isEmpty()) {
            col.addView(emptyCard())
            setContentView(root)
            return
        }

        // ---- summary ----
        val hero = Ui.column(c)
        hero.background = Ui.cardBg(c, 0xFFF3EEFF.toInt(), 18)
        hero.setPadding(Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18))
        hero.addView(Ui.text(c, "OVERALL ACCURACY", 11f, Ui.color(c, R.color.primary), true))
        val big = Ui.text(c, if (overall < 0) "—" else "$overall%", 44f, Ui.color(c, R.color.primary), true)
        big.setTypeface(null, Typeface.BOLD)
        hero.addView(big)
        hero.addView(Ui.text(c, "${practised.size} chapter${if (practised.size == 1) "" else "s"} practised so far", 13.5f, Ui.color(c, R.color.text_sub)))
        col.addView(hero)

        // ---- weakest chapters, worst accuracy first ----
        val weak = practised
            .sortedWith(compareBy({ it.acc }, { -it.answered }))
            .take(8)

        col.addView(Ui.space(c, 22))
        col.addView(sectionLabel("FOCUS HERE"))
        col.addView(Ui.space(c, 8))
        col.addView(Ui.text(c, "Your lowest-accuracy chapters. Drill one and its score climbs.", 12.5f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 10))
        for (s in weak) {
            col.addView(topicRow(s, drillable = true))
            col.addView(Ui.space(c, 8))
        }

        // ---- chapters that are holding up ----
        val strong = practised.filter { it.answered >= 2 && it.acc >= 70 }
            .sortedByDescending { it.acc }.take(3)
        if (strong.isNotEmpty()) {
            col.addView(Ui.space(c, 16))
            col.addView(sectionLabel("GOING WELL"))
            col.addView(Ui.space(c, 8))
            for (s in strong) {
                col.addView(topicRow(s, drillable = false))
                col.addView(Ui.space(c, 8))
            }
        }

        setContentView(root)
    }

    // ---------------- pieces ----------------

    private fun header(): LinearLayout {
        val c = this
        val h = Ui.row(c)
        h.setPadding(Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 4))
        val back = Ui.text(c, "‹", 30f, Ui.color(c, R.color.primary), true)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        Fx.press(back)
        h.addView(back, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        val title = Ui.text(c, "Weak topics", 20f, Ui.color(c, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        h.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 6)
        })
        return h
    }

    private fun sectionLabel(t: String): TextView =
        Ui.text(this, t, 11f, Ui.color(this, R.color.text_sub), true)

    /** acc → colour: red under 50, amber under 70, green otherwise. */
    private fun bandColor(acc: Int): Int = when {
        acc < 50 -> Theme.ink(this, 0xFFE0524D.toInt())
        acc < 70 -> Theme.ink(this, 0xFFC77B1F.toInt())
        else -> Ui.color(this, R.color.primary)
    }

    private fun topicRow(s: Coach.ChapterStat, drillable: Boolean): LinearLayout {
        val c = this
        val accent = bandColor(s.acc)

        val card = Ui.column(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))

        // top line: chapter name + accuracy
        val top = Ui.row(c)
        top.gravity = Gravity.CENTER_VERTICAL
        val nameCol = Ui.column(c)
        nameCol.addView(Ui.text(c, s.chapter.ifBlank { Coach.subjectName(s.subject) }, 15f, Ui.color(c, R.color.text_main), true))
        nameCol.addView(Ui.text(c, "${Coach.subjectName(s.subject)} · ${s.answered} Q · ${Coach.bandLabel(s.acc)}", 12f, Ui.color(c, R.color.text_sub)))
        top.addView(nameCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val pct = Ui.text(c, "${s.acc}%", 17f, accent, true)
        pct.setTypeface(null, Typeface.BOLD)
        top.addView(pct)
        card.addView(top)

        // accuracy bar
        card.addView(Ui.space(c, 8))
        val track = LinearLayout(c)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(c, 0xFFE4EBE7.toInt(), 3)
        val fill = View(c)
        fill.background = Ui.cardBg(c, accent, 3)
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(c, 6), (s.acc.coerceAtLeast(2)) / 100f))
        card.addView(track)

        if (drillable) {
            card.addView(Ui.space(c, 12))
            val drill = Ui.button(c, "Drill this chapter", true)
            drill.gravity = Gravity.CENTER
            drill.setOnClickListener { startDrill(s) }
            card.addView(drill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 46)))
        }
        return card
    }

    private fun startDrill(s: Coach.ChapterStat) {
        val ids = Coach.drillIds(this, s.subject, s.chapter, cap = 50)
        if (ids.isEmpty()) {
            Ui.toast(this, "No questions in this chapter yet")
            return
        }
        val i = Intent(this, QuizActivity::class.java)
        i.putExtra("ids", ids.joinToString(","))
        i.putExtra("subject", s.subject)
        startActivity(i)
    }

    private fun emptyCard(): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFE7F3EC.toInt(), 16)
        card.setPadding(Ui.dp(c, 18), Ui.dp(c, 20), Ui.dp(c, 18), Ui.dp(c, 20))
        card.addView(Ui.text(c, "Not enough data yet", 18f, Ui.color(c, R.color.primary), true))
        card.addView(Ui.space(c, 6))
        card.addView(Ui.text(c, "Practise a few chapters and this screen will name exactly which ones are dragging your score down — and let you fix them one tap at a time.", 14f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 14))
        val p = Ui.button(c, "Go practice", false)
        p.gravity = Gravity.CENTER
        p.setOnClickListener { finish() }
        card.addView(p, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 48)))
        return card
    }
}
