package com.ayush.neetcracker

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Helpers shared by the bottom-nav tabs. */
private fun tabScroll(host: MainActivity): Pair<ScrollView, LinearLayout> {
    val sv = ScrollView(host)
    sv.setBackgroundColor(Ui.color(host, R.color.bg))
    sv.isFillViewport = true
    val col = Ui.column(host)
    val pad = Ui.dp(host, 16)
    col.setPadding(pad, Ui.dp(host, 18), pad, Ui.dp(host, 24))
    sv.addView(col, android.widget.FrameLayout.LayoutParams(
        android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
    return sv to col
}

private fun LinearLayout.card(host: MainActivity, body: LinearLayout.() -> Unit): LinearLayout {
    val card = Ui.column(host)
    card.background = Ui.cardBg(host)
    card.setPadding(Ui.dp(host, 16), Ui.dp(host, 14), Ui.dp(host, 16), Ui.dp(host, 14))
    card.body()
    this.addView(card, Ui.margins(0, 0, 0, 0, host).apply {
        bottomMargin = Ui.dp(host, 12)
    })
    return card
}

private fun LinearLayout.bigButton(host: MainActivity, label: String, filled: Boolean = true, onClick: () -> Unit) {
    val b = Ui.button(host, label, filled)
    b.setOnClickListener { onClick() }
    Ui.clickable(host, b)
    this.addView(b, Ui.margins(0, 0, 0, 0, host))
    (b.layoutParams as LinearLayout.LayoutParams).bottomMargin = Ui.dp(host, 8)
}

private fun LinearLayout.section(host: MainActivity, title: String) {
    this.addView(Ui.heading(host, title), Ui.margins(0, Ui.dp(host, 4), 0, Ui.dp(host, 8), host))
}

private fun fmtMin(min: Int): String = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

private fun daysUntil(date: String): Int {
    val now = Calendar.getInstance()
    now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0); now.set(Calendar.SECOND, 0); now.set(Calendar.MILLISECOND, 0)
    val t = Store.parse(date) ?: return 0
    val tm = Calendar.getInstance()
    tm.timeInMillis = t.timeInMillis
    tm.set(Calendar.HOUR_OF_DAY, 0); tm.set(Calendar.MINUTE, 0); tm.set(Calendar.SECOND, 0); tm.set(Calendar.MILLISECOND, 0)
    return ((tm.timeInMillis - now.timeInMillis) / 86400000L).toInt()
}

private fun testCountdown(date: String): String {
    val cal = Store.parse(date)
    val label = if (cal != null) SimpleDateFormat("d MMM", Locale.US).format(cal.time) else date
    return when (val d = daysUntil(date)) {
        0 -> "Today — $label"
        1 -> "Tomorrow — $label"
        in 2..Int.MAX_VALUE -> "in $d days — $label"
        else -> "Done — $label"
    }
}

object TabHome {

    // v10.4: card entry animations play on a FRESH tab entry only. Replaying them
    // on a silent refresh — e.g. right after tapping "Mark as done" — made the whole
    // page look like it re-loaded; Ayush asked for only the button to move.
    private var animateIn = true

    /** Fade a card in on first entry; on a refresh leave it fully drawn. */
    private fun entry(v: View, delayMs: Long, durMs: Long = 240) {
        if (!animateIn) return
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(durMs).setStartDelay(delayMs).start()
    }

    fun build(host: MainActivity, animateInTab: Boolean = true): ScrollView {
        animateIn = animateInTab
        val (sv, col) = tabScroll(host)
        val c = host

        // ---- greeting header (design spec §4: name + avatar → Profile) ----
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        val dateTxt = SimpleDateFormat("EEEE, d MMM", Locale.US).format(Calendar.getInstance().time)
        val greet = Ui.row(c)
        greet.gravity = android.view.Gravity.CENTER_VERTICAL
        // v8.25: the round photo moved up into the top app bar (top-left); the
        // header is text-only now.
        val left = Ui.column(c)
        left.addView(Ui.text(c, "$part, ${Store.name(c)}", 24f, Ui.color(c, R.color.text_main), true))
        left.addView(Ui.text(c, dateTxt, 13f, Ui.color(c, R.color.text_sub)))
        greet.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // v9.6 §4: today's plan is built once here and reused by the "Today's plan"
        // section below, so the header can show live progress without a second pass.
        val dayBlocks = MyDay.build(c)
        val doneCount = dayBlocks.count { blockIsDone(host, it) }
        val nextBlock = dayBlocks.firstOrNull { !blockIsDone(host, it) && it.endMin > 0 }

        val hdrBadge = Ui.column(c)
        hdrBadge.gravity = Gravity.CENTER
        hdrBadge.background = Ui.cardBg(c, Ui.color(c, R.color.card), 14)
        hdrBadge.setPadding(Ui.dp(c, 14), Ui.dp(c, 6), Ui.dp(c, 14), Ui.dp(c, 6))
        hdrBadge.addView(Ui.text(c, "$doneCount/${dayBlocks.size}", 18f, Ui.color(c, R.color.primary), true))
        hdrBadge.addView(Ui.text(c, "blocks done", 10.5f, Ui.color(c, R.color.text_sub)))
        greet.addView(hdrBadge)
        col.addView(greet)

        // ---- today at a glance: plan progress + what's next ----
        col.addView(Ui.space(c, 12))
        val todayCard = Ui.column(c)
        todayCard.background = Ui.cardBg(c, Ui.color(c, R.color.card), 14)
        todayCard.setPadding(Ui.dp(c, 14), Ui.dp(c, 11), Ui.dp(c, 14), Ui.dp(c, 11))
        val tTop = Ui.row(c)
        tTop.addView(Ui.text(c, "TODAY", 11f, Ui.color(c, R.color.text_sub), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tTop.addView(
            Ui.text(c, "for ${Store.name(c)} · ${dateTxt.substringBefore(",")}", 11f, Ui.color(c, R.color.text_sub))
        )
        todayCard.addView(tTop)
        todayCard.addView(Ui.space(c, 8))
        val tBar = LinearLayout(c)
        tBar.orientation = LinearLayout.HORIZONTAL
        tBar.weightSum = 1f
        tBar.background = Ui.cardBg(c, 0xFFE4EBE7.toInt(), 6)
        val tFill = View(c)
        tFill.background = Ui.cardBg(c, Ui.color(c, R.color.primary), 6)
        tBar.addView(tFill, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0f))
        todayCard.addView(tBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 8)))
        val frac = if (dayBlocks.isEmpty()) 0f else doneCount.toFloat() / dayBlocks.size
        tFill.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, frac)
        todayCard.addView(Ui.space(c, 9))
        if (nextBlock != null) {
            val tNext = Ui.row(c)
            tNext.gravity = Gravity.CENTER_VERTICAL
            tNext.addView(Ui.text(c, "NEXT", 10.5f, Ui.color(c, R.color.primary), true))
            tNext.addView(
                Ui.text(c, "${fmtMin(nextBlock.startMin)}  ${nextBlock.title}", 13f, Ui.color(c, R.color.text_main), true).apply {
                    setPadding(Ui.dp(c, 8), 0, 0, 0)
                },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            todayCard.addView(tNext)
        } else if (dayBlocks.isNotEmpty()) {
            todayCard.addView(Ui.text(c, "Every block is done — day closed.", 13f, Ui.color(c, R.color.primary), true))
        }
        col.addView(todayCard)
        col.addView(Ui.space(c, 13))

        // ---- countdown hero (v5 futuristic) ----
        val days = Store.daysToExam(c)
        val pctHero = (Store.dailyTargetFraction(c) * 100).toInt()
        val hero = Ui.column(c)
        hero.background = Fx.gradient(0xFF3D2B9F.toInt(), 0xFF7B2FF7.toInt())
        hero.setPadding(Ui.dp(c, 18), Ui.dp(c, 16), Ui.dp(c, 18), Ui.dp(c, 14))
        val heroTop = Ui.row(c)
        heroTop.addView(
            Ui.text(c, "NEET ${Store.examDate(c).take(4)} · ${Store.name(c)}", 12f, 0xFFD9E2FF.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        heroTop.addView(Ui.text(c, Store.examLabel(c), 12f, 0xFFB9C6FF.toInt()))
        hero.addView(heroTop)
        val dRow = Ui.row(c)
        dRow.gravity = Gravity.BOTTOM
        dRow.addView(Ui.text(c, "$days", 46f, Color.WHITE, true))
        val daysLbl = Ui.text(c, "days to go", 15f, 0xFFE6EBFF.toInt())
        daysLbl.setPadding(0, 0, 0, Ui.dp(c, 9))
        dRow.addView(daysLbl)
        hero.addView(dRow)
        hero.addView(Ui.space(c, 12))
        val sRow = Ui.row(c)
        fun heroStat(container: LinearLayout, weight: Float, big: String, label: String) {
            val s = Ui.column(c)
            s.gravity = Gravity.CENTER
            s.addView(Ui.text(c, big, 20f, Color.WHITE, true))
            s.addView(Ui.text(c, label, 12f, 0xFFB9C6FF.toInt()))
            container.addView(s, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight))
        }
        heroStat(sRow, 1f, "${Store.streak(c)}", "day streak")
        heroStat(sRow, 1f, "$pctHero%", "of today's goal")
        val mockBest = Store.bestMock(c)
        heroStat(sRow, 1f, if (mockBest == 0) "—" else "+$mockBest", "best mock")
        hero.addView(sRow)
        col.addView(hero, Ui.margins(0, 0, 0, 12, c))
        // v6.1: hero fades in a beat after the tab lands (first entry only)
        entry(hero, 70, 300)

        // ---- v8.8 quick actions: the four big moves of a study day ----
        quickActions(host, col)

        // ---- v8.8 continue studying: pick up the live chapter ----
        continueCard(host, col)

        // v8: ANC coach — today's real priority from Ayush's own data
        coachCard(host, col)

        // v8.1: Momentum sync — where Ayush's coaching day sits in the course flow
        momentumCard(host, col)

        // v8.3: Ayan's NRTS — friend's plan, clearly separate
        if (AyanSeries.has(c)) ayanCard(host, col)

        // ---- Momentum tests (sync with coaching) ----
        val tests = Store.momentumTests(c).filter { it.date >= Store.todayKey() }.sortedBy { it.date }
        if (tests.isNotEmpty()) {
            col.card(c) {
                addView(Ui.text(c, "Momentum tests", 15f, Ui.color(c, R.color.primary), true))
                for (t in tests.take(2)) {
                    val sub = Subjects.byKey(t.subject)
                    val nm = sub?.name ?: t.subject
                    val ch = sub?.chapters?.getOrNull(t.chapter) ?: "Chapter ${t.chapter + 1}"
                    addView(Ui.space(c, 6))
                    addView(Ui.text(c, "$nm · $ch", 15f, Ui.color(c, R.color.text_main), true))
                    addView(Ui.text(c, testCountdown(t.date), 13f, Ui.color(c, R.color.accent)))
                }
                if (tests.size > 2) addView(Ui.text(c, "+${tests.size - 2} more — manage in Profile", 12f, Ui.color(c, R.color.text_sub)))
            }
        }

        // ---- Today's plan (My Day) ----
        col.section(c, "Today's plan")
        for ((k, b) in dayBlocks.withIndex()) {
            val card = blockCard(host, b)
            // v6.1: the day's blocks step in one after another (first entry only)
            entry(card, 130 + k * 45L, 200)
            col.addView(card)
        }
        col.addView(Ui.space(c, 2))

        // v10.2: the targets, the priority order and the rule, kept with the plan
        dailyPlanCard(host, col)

        // ---- quick tools ----
        col.card(c) {
            val row = Ui.row(c)
            addView(row)
            quick(row, c, "⏱ Timer") { host.startPlain(TimerActivity::class.java) }
            quick(row, c, "📋 Planner") { host.startPlain(PlannerActivity::class.java) }
            quick(row, c, "🎯 Practice") { host.switchTab("practice") }
        }

        // ---- closing line ----
        col.addView(
            Ui.text(c, quotes[(Calendar.getInstance().get(Calendar.DAY_OF_YEAR) - 1) % quotes.size], 13f,
                Ui.color(c, R.color.text_sub)
            ).apply { gravity = Gravity.CENTER }
        )
        return sv
    }

    // ---------------- block card ----------------
    private fun blockCard(host: MainActivity, b: MyDay.Block): View {
        val c = host
        val today = Store.todayKey()
        val (bg, accent) = tint(c, b)
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, bg)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))

        val head = Ui.row(c)
        card.addView(head)
        val time = Ui.text(c, "${fmtMin(b.startMin)}–${fmtMin(b.endMin)}", 13f, accent, true)
        time.setPadding(0, 0, Ui.dp(c, 10), 0)
        head.addView(time)
        val title = Ui.text(c, b.title, 15f, Ui.color(c, R.color.text_main), true)
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // status circle on the right
        val status = Ui.text(c, statusChar(host, b), 17f, accent, true)
        status.gravity = Gravity.CENTER
        status.setPadding(Ui.dp(c, 6), 0, 0, 0)
        head.addView(status)

        if (b.sub.isNotEmpty()) {
            card.addView(Ui.text(c, b.sub, 13f, Ui.color(c, R.color.text_sub)))
        }

        // tap + chip line. A chip is its own button so a lecture tap opens YouTube,
        // not the card's action (the whole-card listener used to swallow it).
        if (b.chip.isNotEmpty()) {
            card.addView(Ui.space(c, 6))
            val chip = Ui.text(c, b.chip, 13f, accent, true)
            chip.setTypeface(null, Typeface.BOLD)
            chip.gravity = Gravity.CENTER
            chip.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12), Ui.dp(c, 6))
            chip.background = Ui.cardBg(c, 0x10000000.toInt(), 12)
            chip.setOnClickListener { chipTap(host, b) }
            Fx.press(chip)
            card.addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        // v10.2: an explicit done / not-done control on every block, so a plain
        // study slot (Chemistry, Physics, a break) can be ticked off without
        // guessing that tapping the whole card is how you mark it.
        card.addView(Ui.space(c, 8))
        val done = blockIsDone(host, b)
        val toggle = Ui.text(c, if (done) "✓  Done" else "Mark as done", 12.5f,
            if (done) Theme.onAccent(c) else accent, true)
        toggle.gravity = Gravity.CENTER
        toggle.setPadding(Ui.dp(c, 14), Ui.dp(c, 7), Ui.dp(c, 14), Ui.dp(c, 7))
        toggle.background = Ui.cardBg(c, if (done) accent else 0x10000000.toInt(), 12)
        toggle.setOnClickListener {
            val nowDone: Boolean
            if (blockIsDone(host, b)) {
                Store.setBlockDone(c, today, b.id, false)
                // Un-ticking a Biology card also withdraws today's sprint log, so the
                // header ✓ and the button can never disagree.
                if ((b.subj == "BOT" || b.subj == "ZOO") && Store.bioLoggedToday(c, b.subj)) {
                    MyDay.undoBioPart(c, b.subj)
                }
                nowDone = false
            } else {
                Store.setBlockDone(c, today, b.id, true)
                nowDone = true
            }
            // v10.4: the tap animates the BUTTON, not the page. Paint the new state
            // straight onto the button and spring it, then let a deferred, silent
            // refresh sync the header badge and progress bar underneath it.
            toggle.text = if (nowDone) "✓  Done" else "Mark as done"
            toggle.setTextColor(if (nowDone) Theme.onAccent(c) else accent)
            toggle.background = Ui.cardBg(c, if (nowDone) accent else 0x10000000.toInt(), 12)
            Fx.pop(toggle)
            toggle.postDelayed({ host.refresh() }, 240)
        }
        Fx.press(toggle)

        // v10.6: an explicit edit affordance beside it — the plan is his to shape.
        val edit = Ui.text(c, "Edit", 12.5f, Ui.color(c, R.color.text_sub), true)
        edit.gravity = Gravity.CENTER
        edit.setPadding(Ui.dp(c, 14), Ui.dp(c, 7), Ui.dp(c, 14), Ui.dp(c, 7))
        edit.background = Ui.cardBg(c, 0x10000000.toInt(), 12)
        edit.setOnClickListener { host.editPlanBlock(b) }
        Fx.press(edit)

        val actions = Ui.row(c)
        actions.addView(toggle, LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(edit, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = Ui.dp(c, 8)
        })
        card.addView(actions)

        card.setOnClickListener { tap(host, b) }
        Fx.press(card)
        return card
    }

    /** v10.2: Ayush's daily targets, priority order and the rule, kept with the plan. */
    private fun dailyPlanCard(host: MainActivity, col: LinearLayout) {
        val c = host
        col.card(c) {
            addView(Ui.text(c, "AYUSH'S DAILY PLAN", 15f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 9))
            addView(Ui.text(c, "DAILY TARGET", 10.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.space(c, 3))
            for ((label, value) in MyDay.DAILY_TARGETS) {
                val r = Ui.row(c)
                r.addView(Ui.text(c, label, 13.5f, Ui.color(c, R.color.text_main), true),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(Ui.text(c, value, 13.5f, Ui.color(c, R.color.text_sub)))
                addView(r)
            }
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "DAILY PRIORITY", 10.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.space(c, 3))
            for ((i, p) in MyDay.DAILY_PRIORITY.withIndex()) {
                addView(Ui.text(c, "${i + 1}.  $p", 13.5f, Ui.color(c, R.color.text_main)))
            }
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "RULE", 10.5f, Ui.color(c, R.color.primary), true))
            addView(Ui.text(c, MyDay.DAILY_RULE, 13f, Ui.color(c, R.color.text_main)))
        }
    }

    /** A chip (e.g. "Watch lecture ▸", "Open checklist") is a self-contained tap target. */
    private fun chipTap(host: MainActivity, b: MyDay.Block) {
        when {
            b.chip.startsWith("Watch lecture") -> MyDay.openPlaylist(host, b.subj)
            b.chip == "Open checklist" -> host.startSub(ChecklistActivity::class.java, "mode",
                if (b.kind == MyDay.KIND_BUS)
                    (if (b.id == "bus_out") MyDay.BUS_SET_OUT else MyDay.BUS_SET_IN)
                else MyDay.BED_SET)
            b.chip == "Open Practice tab" -> host.switchTab("practice")
            else -> tap(host, b) // informational chips (e.g. class hours) act like the card
        }
    }

    /**
     * v10.2: a block is done when Ayush ticked it himself, or — for a Biology card —
     * when today's chapter sprint is already logged. Both feed the header badge and
     * the "NEXT" pointer, so the explicit toggle and the sprint tap agree.
     */
    private fun blockIsDone(host: MainActivity, b: MyDay.Block): Boolean {
        val c = host
        if (Store.blockDone(c, Store.todayKey(), b.id)) return true
        return (b.subj == "BOT" || b.subj == "ZOO") && Store.bioLoggedToday(c, b.subj)
    }

    private fun statusChar(host: MainActivity, b: MyDay.Block): String {
        val c = host
        val today = Store.todayKey()
        return when {
            b.kind == MyDay.KIND_BUS -> {
                val t = Store.ticks(c, today, if (b.id == "bus_out") MyDay.BUS_SET_OUT else MyDay.BUS_SET_IN)
                when {
                    t.isNotEmpty() -> "${t.size}/3"
                    blockIsDone(host, b) -> "✓"
                    else -> "○"
                }
            }
            b.kind == MyDay.KIND_BED -> {
                val t = Store.ticks(c, today, MyDay.BED_SET)
                when {
                    t.isNotEmpty() -> "${t.size}/${MyDay.BED_ITEMS.size}"
                    blockIsDone(host, b) -> "✓"
                    else -> "○"
                }
            }
            blockIsDone(host, b) -> "✓"
            else -> "○"
        }
    }

    private fun tap(host: MainActivity, b: MyDay.Block) {
        val c = host
        val today = Store.todayKey()
        when {
            // A bio card logs today's sprint part; tapping it again UNDOES a mistaken tick.
            b.subj == "BOT" || b.subj == "ZOO" -> {
                val sub = Subjects.byKey(b.subj)!!
                val msg = if (Store.bioLoggedToday(c, b.subj)) {
                    Store.setBlockDone(c, today, b.id, false) // v10.2: keep the tick in step
                    MyDay.undoBioPart(c, b.subj)
                } else {
                    val a = MyDay.activeChapter(c, b.subj)
                    if (a == null) "All ${sub.name} chapters done 🎉"
                    else MyDay.logBioPart(c, b.subj).also { Store.setBlockDone(c, today, b.id, true) }
                }
                host.toast(msg)
                host.refresh()
            }
            b.kind == MyDay.KIND_BUS -> host.startSub(ChecklistActivity::class.java, "mode",
                if (b.id == "bus_out") MyDay.BUS_SET_OUT else MyDay.BUS_SET_IN)
            b.kind == MyDay.KIND_BED -> host.startSub(ChecklistActivity::class.java, "mode", MyDay.BED_SET)
            b.kind == MyDay.KIND_CLASS -> Ui.toast(c, "Coaching hour — soak up the class, note doubts for tonight")
            b.chip == "Open Practice tab" -> host.switchTab("practice")
            else -> {
                Store.setBlockDone(c, today, b.id, !Store.blockDone(c, today, b.id))
                host.refresh()
            }
        }
    }

    private fun tint(c: android.content.Context, b: MyDay.Block): Pair<Int, Int> {
        val white = 0xFFFFFFFF.toInt()
        return when (b.subj) {
            "BOT" -> 0xFFE7F3EC.toInt() to Ui.color(c, R.color.primary)
            "ZOO" -> 0xFFE7F3EC.toInt() to Ui.color(c, R.color.primary)
            "CHEM" -> 0xFFFFF3E0.toInt() to 0xFFC77B1F.toInt()
            "PHY" -> 0xFFE9EFF7.toInt() to 0xFF2F6FB2.toInt()
            else -> when (b.kind) {
                MyDay.KIND_BUS -> 0xFFFFF6E3.toInt() to 0xFFB8860B.toInt()
                MyDay.KIND_BED -> 0xFFFBEFF3.toInt() to 0xFFB03A5B.toInt()
                MyDay.KIND_CLASS -> 0xFFEDEAF7.toInt() to 0xFF6C5CE7.toInt()
                MyDay.KIND_SLEEP -> 0xFFEEF0F2.toInt() to 0xFF5C6B7A.toInt()
                else -> white to Ui.color(c, R.color.text_sub)
            }
        }
    }

    private fun quick(row: LinearLayout, c: android.content.Context, label: String, onClick: () -> Unit) {
        val b = Ui.text(c, label, 13f, Ui.color(c, R.color.text_main), true)
        b.gravity = Gravity.CENTER
        b.setPadding(Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10))
        b.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
        b.setOnClickListener { onClick() }
        Ui.clickable(c, b)
        row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = Ui.dp(c, 6)
        })
    }

    // ---- v8.8 quick actions: a 2×2 of the four big daily moves ----
    private fun quickActions(host: MainActivity, col: LinearLayout) {
        val c = host
        val r1 = Ui.row(c)
        col.addView(r1, Ui.margins(0, 0, 0, 10, c))
        quickTile(r1, c, "📖", "STUDY", "chapters · lectures", 0xFFE7F3EC.toInt()) {
            host.switchTab("study")
        }
        quickTile(r1, c, "🎯", "PRACTICE", "drills · question bank", 0xFFE9EFF7.toInt()) {
            host.switchTab("practice")
        }
        val r2 = Ui.row(c)
        col.addView(r2, Ui.margins(0, 0, 0, 10, c))
        quickTile(r2, c, "📝", "PYQ", "past year papers", 0xFFFFF3E0.toInt()) {
            host.startPlain(ExamActivity::class.java)
        }
        quickTile(r2, c, "🏁", "TEST", "full mocks · subject tests", 0xFFEDEAF7.toInt()) {
            host.startPlain(ExamActivity::class.java)
        }
    }

    /**
     * One large quick-action tile. Icon sits in a clean white chip (reads as an
     * app icon, not a floating emoji), title bold + short single-line caption
     * (rule 8 — no clipped text), whole tile is the tap target (rule 2).
     */
    private fun quickTile(
        row: LinearLayout, c: MainActivity, emoji: String, title: String,
        desc: String, tint: Int, onClick: () -> Unit
    ) {
        val t = Ui.column(c)
        t.background = Ui.cardBg(c, tint, 16)
        t.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 12), 0)
        // two flexible spacers keep the content vertically centred in the fixed tile height
        t.addView(View(c), LinearLayout.LayoutParams(0, 0, 1f))

        val head = Ui.row(c)
        head.gravity = Gravity.CENTER_VERTICAL
        val chip = Ui.text(c, emoji, 15f, Color.BLACK)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(c, Color.WHITE, 17)
        head.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34)))
        val tt = Ui.text(c, title, 14f, Ui.color(c, R.color.text_main), true)
        tt.setSingleLine(true)
        head.addView(tt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 10)
        })
        val chev = Ui.text(c, "›", 16f, Ui.color(c, R.color.text_sub))
        head.addView(chev)
        t.addView(head, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 38)))

        val dd = Ui.text(c, desc, 11f, Ui.color(c, R.color.text_sub))
        dd.setSingleLine(true)
        dd.ellipsize = android.text.TextUtils.TruncateAt.END
        t.addView(dd, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(c, 3)
        })

        t.addView(View(c), LinearLayout.LayoutParams(0, 0, 1f))
        t.setOnClickListener { onClick() }
        Fx.press(t)
        val lp = LinearLayout.LayoutParams(0, Ui.dp(c, 96), 1f)
        if (row.childCount > 0) lp.marginStart = Ui.dp(c, 8)
        row.addView(t, lp)
    }

    // ---- v8.8 continue studying: surface the live chapter + one-tap resume ----
    private fun continueCard(host: MainActivity, col: LinearLayout) {
        val c = host
        val key = continueSubject(c) ?: return
        val sub = Subjects.byKey(key) ?: return
        val idx = nextUndone(c, key) ?: return
        val chName = sub.chapters.getOrNull(idx) ?: return
        val done = Store.doneCount(c, key)
        val frac = if (sub.chapters.isEmpty()) 0f else done.toFloat() / sub.chapters.size

        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFF2EFFC.toInt(), 16, 0xFFC9BBF5.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        val head = Ui.row(c)
        head.addView(
            Ui.text(c, "CONTINUE STUDYING", 11f, 0xFF5B3FC4.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val subChip = Ui.text(c, sub.name.uppercase(), 11f, Color.WHITE, true)
        subChip.gravity = Gravity.CENTER
        subChip.setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4))
        subChip.background = Ui.cardBg(c, 0xFF5B3FC4.toInt(), 10)
        head.addView(subChip)
        card.addView(head)
        card.addView(Ui.space(c, 9))
        card.addView(Ui.text(c, chName, 19f, Ui.color(c, R.color.text_main), true))
        card.addView(Ui.text(
            c, "Chapter ${idx + 1} of ${sub.chapters.size} · $done chapters done",
            12f, Ui.color(c, R.color.text_sub)
        ))
        card.addView(Ui.space(c, 9))
        Ui.addProgressRow(card, c, "", frac)
        card.addView(Ui.space(c, 12))
        val go = Ui.text(c, "Continue this chapter →", 14f, Color.WHITE, true)
        go.gravity = Gravity.CENTER
        go.setPadding(Ui.dp(c, 14), Ui.dp(c, 11), Ui.dp(c, 14), Ui.dp(c, 11))
        go.background = Ui.cardBg(c, 0xFF5B3FC4.toInt(), 12)
        go.setOnClickListener { host.startSub(SubjectActivity::class.java, "key", key) }
        Fx.press(go)
        card.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        // whole card resumes the chapter too — big tap target (rule 2)
        card.setOnClickListener { host.startSub(SubjectActivity::class.java, "key", key) }
        Fx.press(card)
        entry(card, 90, 260)
        col.addView(card, Ui.margins(0, 0, 0, 12, c))
    }

    /** A live chapter pin wins; otherwise the least-finished subject. */
    private fun continueSubject(c: MainActivity): String? {
        for (s in Subjects.ALL) {
            val pin = Store.pinnedIndex(c, s.key)
            if (pin >= 0 && pin < s.chapters.size && !Store.isDone(c, s.key, pin)) return s.key
        }
        var best: String? = null
        var bestFrac = 2f
        for (s in Subjects.ALL) {
            if (s.chapters.isEmpty()) continue
            val size = s.chapters.size
            val done = Store.doneCount(c, s.key)
            if (done >= size) continue
            val f = done.toFloat() / size
            if (f < bestFrac) {
                bestFrac = f
                best = s.key
            }
        }
        return best
    }

    private fun nextUndone(c: MainActivity, key: String): Int? {
        val sub = Subjects.byKey(key) ?: return null
        for (i in sub.chapters.indices) if (!Store.isDone(c, key, i)) return i
        return null
    }

    // ---- v8 Command Center: ANC coach card ----
    private fun coachCard(host: MainActivity, col: LinearLayout) {
        val c = host
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFF2EFFC.toInt(), 16, 0xFFC9BBF5.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))

        val head = Ui.row(c)
        head.addView(
            Ui.text(c, "ANC COACH", 12f, 0xFF5B3FC4.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(Ui.text(c, "● SYSTEM ONLINE", 11f, 0xFF2E7D32.toInt(), true))
        card.addView(head)
        card.addView(Ui.text(c, "offline AI · reads your real practice data", 12f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 12))

        val row = Ui.row(c)
        val acc = Coach.overallAccuracy(c)
        coachStat(row, c, "${Store.questionsToday(c)}", "Qs today")
        coachStat(row, c, "${Store.minutesToday(c)}m", "focus today")
        coachStat(row, c, if (acc < 0) "—" else "$acc%", "accuracy")
        coachStat(row, c, "${Store.streak(c)}d", "streak")
        card.addView(row)
        card.addView(Ui.space(c, 12))

        card.addView(Ui.text(c, "TODAY'S PRIORITY", 12f, Ui.color(c, R.color.text_sub), true))
        card.addView(Ui.space(c, 4))
        val p = Coach.priority(c)
        if (p == null) {
            card.addView(Ui.text(c, Coach.recommend(-1), 14f, Ui.color(c, R.color.text_main), true))
        } else {
            card.addView(Ui.text(c, p.chapter, 17f, 0xFF3D2B9F.toInt(), true))
            card.addView(Ui.space(c, 2))
            val band = Coach.bandLabel(p.acc)
            card.addView(
                Ui.text(c, "${Coach.subjectName(p.subject)} · ${p.answered} answered · $band ${p.acc}%", 13f, bandColor(band), true)
            )
            card.addView(Ui.space(c, 6))
            card.addView(Ui.text(c, Coach.recommend(p.acc), 13f, Ui.color(c, R.color.text_sub)))
            card.addView(Ui.space(c, 8))
            val subj = p.subject
            val chapter = p.chapter
            val go = Ui.text(c, "▶ Drill this chapter", 13f, Color.WHITE, true)
            go.gravity = Gravity.CENTER
            go.setPadding(Ui.dp(c, 14), Ui.dp(c, 9), Ui.dp(c, 14), Ui.dp(c, 9))
            go.background = Ui.cardBg(c, 0xFF5B3FC4.toInt(), 12)
            go.setOnClickListener {
                // bank is parsed only on tap, not on every Home render
                val ids = Coach.drillIds(c, subj, chapter)
                if (ids.isEmpty()) Ui.toast(c, "No questions in the bank for that chapter yet")
                else host.startSub(QuizActivity::class.java, "ids", ids.joinToString(","))
            }
            Fx.press(go)
            card.addView(go, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        entry(card, 120, 260)
        col.addView(card, Ui.margins(0, 0, 0, 12, c))
    }

    // ---- v8.1 Momentum sync: where today sits in Ayush's coaching course flow ----
    private fun momentumCard(host: MainActivity, col: LinearLayout) {
        val c = host
        if (!MomentumPlan.has(c)) return
        val anchor = MomentumPlan.anchor(c) ?: return

        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFFFF3E0.toInt(), 16, 0xFFE3C58F.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))

        val head = Ui.row(c)
        head.addView(
            Ui.text(c, "MOMENTUM · CNR-1", 12f, 0xFFB26A00.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(Ui.text(c, "Day ${anchor.day} of ${MomentumPlan.planDays(c)}", 11f, 0xFFB26A00.toInt(), true))
        card.addView(head)
        card.addView(Ui.text(c, "your Momentum class · what's taught today", 12f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 10))

        val today = MomentumPlan.today(c)
        if (today != null && today.kind == "test") {
            card.addView(Ui.text(c, "${today.label} today — Momentum test day", 16f, 0xFFB26A00.toInt(), true))
        } else if (today != null && today.kind == "holiday") {
            card.addView(Ui.text(c, "No class today — Momentum off day", 15f, Ui.color(c, R.color.text_main), true))
        } else {
            for (slot in MomentumPlan.SLOTS) {
                val topic = anchor.topic(slot)
                if (topic == "-") continue
                planSubjectLine(card, c, slot, topic)
            }
        }

        val nextElite = EliteSeries.next(c)
        val nextPlan = MomentumPlan.nextTests(c, 1).firstOrNull()
        val nextLine: String? = when {
            nextElite != null && nextPlan != null ->
                if (nextElite.date <= nextPlan.date)
                    "Next test: ${EliteSeries.label(nextElite)} · ${testCountdown(nextElite.date)}"
                else "Next test: ${nextPlan.label} · ${testCountdown(nextPlan.date)}"
            nextElite != null -> "Next test: ${EliteSeries.label(nextElite)} · ${testCountdown(nextElite.date)}"
            nextPlan != null -> "Next test: ${nextPlan.label} · ${testCountdown(nextPlan.date)}"
            else -> null
        }
        if (nextLine != null) {
            card.addView(Ui.space(c, 9))
            card.addView(Ui.text(c, nextLine, 14f, 0xFF9A4A00.toInt(), true))
        }
        card.addView(Ui.space(c, 10))

        val open = Ui.text(c, "Open plan + test series →", 14f, Color.WHITE, true)
        open.gravity = Gravity.CENTER
        open.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10))
        open.background = Ui.cardBg(c, 0xFFB26A00.toInt(), 12)
        open.setOnClickListener { host.startPlain(MomentumPlanActivity::class.java) }
        Fx.press(open)
        card.addView(open, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        entry(card, 170, 260)
        col.addView(card, Ui.margins(0, 0, 0, 12, c))
    }

    /** Ayan's NRTS plan card — teal, clearly not Ayush's own plan. */
    private fun ayanCard(host: MainActivity, col: LinearLayout) {
        val c = host
        val nxt = AyanSeries.next(c) ?: return

        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFE4F2F0.toInt(), 16, 0xFF9ECCC5.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        val head = Ui.row(c)
        head.addView(
            Ui.text(c, "AYAN · NRTS REAL TEST", 12f, 0xFF00695C.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(Ui.text(c, "NRTS 2027", 11f, 0xFF00695C.toInt(), true))
        card.addView(head)
        card.addView(Ui.text(c, "Ayan's plan — separate from yours", 12f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 10))

        card.addView(Ui.text(c, "Next: ${AyanSeries.label(nxt)} · ${testCountdown(nxt.date)}",
            15f, 0xFF00695C.toInt(), true))
        if (nxt.scope != "part") {
            card.addView(Ui.text(c, AyanSeries.scopeLabel(nxt), 12f, Ui.color(c, R.color.text_sub)))
        }
        card.addView(Ui.space(c, 10))

        val open = Ui.text(c, "Open Ayan's NRTS plan →", 14f, Color.WHITE, true)
        open.gravity = Gravity.CENTER
        open.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10))
        open.background = Ui.cardBg(c, 0xFF00695C.toInt(), 12)
        open.setOnClickListener { host.startPlain(AyanPlanActivity::class.java) }
        Fx.press(open)
        card.addView(open, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        entry(card, 190, 260)
        col.addView(card, Ui.margins(0, 0, 0, 12, c))
    }

    private fun planSubjectLine(container: LinearLayout, c: MainActivity, slot: String, topic: String) {
        val tint = MomentumPlan.SLOT_TINT[slot] ?: 0xFF5C6B7A.toInt()
        val chip = Ui.text(c, slot, 10f, Color.WHITE, true)
        chip.gravity = Gravity.CENTER
        chip.setPadding(Ui.dp(c, 7), Ui.dp(c, 3), Ui.dp(c, 7), Ui.dp(c, 3))
        chip.background = Ui.cardBg(c, tint, 6)
        chip.minWidth = Ui.dp(c, 40)
        val row = Ui.row(c)
        row.addView(chip)
        val tv = Ui.text(c, topic, 14f, Ui.color(c, R.color.text_main))
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 10)
        })
        container.addView(row, Ui.margins(0, 4, 0, 0, c))
    }

    private fun coachStat(container: LinearLayout, c: android.content.Context, big: String, label: String) {
        val s = Ui.column(c)
        s.gravity = Gravity.CENTER
        s.addView(Ui.text(c, big, 17f, 0xFF4C2BD9.toInt(), true))
        s.addView(Ui.text(c, label, 11f, Ui.color(c, R.color.text_sub)))
        container.addView(s, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun bandColor(band: String): Int = when (band) {
        "WEAK" -> 0xFFE53935.toInt()
        "AVERAGE" -> 0xFFE08A00.toInt()
        "GOOD" -> 0xFF2F6FB2.toInt()
        else -> 0xFF2E7D32.toInt()
    }

    private val quotes = arrayOf(
        "Small daily efforts build big results.",
        "Discipline beats motivation — every single day.",
        "One chapter a day keeps the panic away.",
        "Your future self is watching. Study for them.",
        "Consistency is the real superpower.",
        "Every question you solve is a mark you protect.",
        "Don't count the days. Make the days count.",
        "The only way out is through."
    )
}

object TabStudy {

    // v10.4: same rule as TabHome — subject tiles stagger in on a fresh entry only.
    private var animateIn = true

    fun build(host: MainActivity, animateInTab: Boolean = true): ScrollView {
        animateIn = animateInTab
        val (sv, col) = tabScroll(host)
        val c = host

        // ---- page intro (design spec §6) ----
        val head = Ui.row(c)
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = Ui.column(c)
        titles.addView(Ui.text(c, "Study", 22f, Ui.color(c, R.color.text_main), true))
        titles.addView(Ui.text(c, "Continue your preparation", 13f, Ui.color(c, R.color.text_sub)))
        head.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // v9.8: the revision queue surfaced where he starts the day, not only inside the hub.
        val due = Store.revisionDue(c).size
        val dueChip = Ui.text(c, if (due > 0) "$due to revise ›" else "All revised ✓", 12f,
            if (due > 0) 0xFFFFFFFF.toInt() else Ui.color(c, R.color.primary), true)
        dueChip.gravity = Gravity.CENTER
        dueChip.setPadding(Ui.dp(c, 12), Ui.dp(c, 7), Ui.dp(c, 12), Ui.dp(c, 7))
        dueChip.background = Ui.cardBg(c,
            if (due > 0) Ui.color(c, R.color.primary) else 0xFFEAF1EC.toInt(), 14)
        if (due > 0) {
            dueChip.setOnClickListener { host.startPlain(RevisionActivity::class.java) }
            Fx.press(dueChip)
        }
        head.addView(dueChip, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col.addView(head)
        col.addView(Ui.space(c, 14))

        focusCard(host, col)

        // accuracy per subject, computed once — the tiles below would otherwise each walk the log
        val accByKey = HashMap<String, Int>()
        for (s in Subjects.ALL) accByKey[s.key] = Store.accuracy(c, s.key)

        col.section(c, "Subjects")
        for ((i, s) in Subjects.ALL.withIndex()) {
            val nextIdx = s.chapters.indices.firstOrNull { !Store.isDone(c, s.key, it) }
            subjectTile(host, col, s, accByKey[s.key] ?: -1, nextIdx, i * 45L)
        }

        col.section(c, "Planner")
        col.card(c) {
            val row = Ui.row(c)
            addView(row)
            val chip = Ui.text(c, "📋", 15f, Color.BLACK)
            chip.gravity = Gravity.CENTER
            chip.background = Ui.cardBg(c, Color.WHITE, 17)
            row.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 36)))
            val mid = Ui.column(c)
            mid.gravity = Gravity.CENTER_VERTICAL
            mid.addView(Ui.text(c, "Study Planner", 15f, Ui.color(c, R.color.text_main), true))
            mid.addView(Ui.text(c, "plan tasks · set priorities · track done", 12f, Ui.color(c, R.color.text_sub)))
            row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 12)
            })
            row.addView(Ui.text(c, "›", 18f, Ui.color(c, R.color.primary)))
            setOnClickListener { host.startPlain(PlannerActivity::class.java) }
            Fx.press(this)
        }
        return sv
    }

    /** Focus card: today's study minutes, goal progress, timer + quick log chips. */
    private fun focusCard(host: MainActivity, col: LinearLayout) {
        val c = host
        col.card(c) {
            val head = Ui.row(c)
            addView(head)
            head.addView(
                Ui.text(c, "FOCUS TIME", 11f, Ui.color(c, R.color.primary), true),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(Ui.text(c, "${Store.minutesToday(c)} min today", 20f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 8))
            Ui.addProgressRow(this, c, "Daily goal", Store.dailyTargetFraction(c))
            addView(Ui.space(c, 10))
            bigButton(c, "Start Study Timer →", true) { host.startPlain(TimerActivity::class.java) }

            val rr = Ui.row(c)
            addView(rr)
            val history = Ui.text(c, "Session history", 13f, Ui.color(c, R.color.primary), true)
            history.setOnClickListener { host.startPlain(HistoryActivity::class.java) }
            history.gravity = Gravity.CENTER
            history.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
            history.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
            rr.addView(history, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val revision = Ui.text(c, "+1 Revision", 13f, Ui.color(c, R.color.primary), true)
            revision.setOnClickListener {
                Store.bumpLog(c, Store.todayKey(), "r", 1)
                host.toast("Revision logged ✓")
                host.refresh()
            }
            revision.gravity = Gravity.CENTER
            revision.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
            revision.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
            rr.addView(revision, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 8)
            })
        }
    }

    /**
     * One premium subject tile (spec §10-11): monogram chip, tagline, live chapter
     * progress. v9.8 adds two at-a-glance signals — the subject's real accuracy on
     * answered questions, and the chapter to open next.
     */
    private fun subjectTile(
        host: MainActivity,
        col: LinearLayout,
        s: Subject,
        acc: Int,
        nextIdx: Int?,
        delayMs: Long
    ) {
        val c = host
        val total = s.chapters.size
        val done = Store.doneCount(c, s.key)
        val frac = if (total == 0) 0f else done.toFloat() / total
        val accent = subjectAccent(c, s.key)

        val tile = Ui.column(c)
        tile.background = Ui.cardBg(c, subjectFill(s.key), 16)
        tile.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12))
        col.addView(tile, Ui.margins(0, 0, 0, 10, c))

        val top = Ui.row(c)
        tile.addView(top)
        val chip = Ui.text(c, subjectLetter(s.key), 15f, accent, true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(c, Color.WHITE, 18)
        top.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))
        val mid = Ui.column(c)
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(Ui.text(c, s.name, 16f, Ui.color(c, R.color.text_main), true))
        val sub = Ui.text(c, subjectTag(s.key), 11f, Ui.color(c, R.color.text_sub))
        sub.setSingleLine(true)
        sub.ellipsize = android.text.TextUtils.TruncateAt.END
        mid.addView(sub)
        top.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 12)
        })

        // v9.8: live accuracy on this subject's answered questions (blank until he starts)
        if (acc >= 0) {
            val pill = Ui.text(c, "$acc%", 12.5f, Theme.onAccent(c), true)
            pill.gravity = Gravity.CENTER
            pill.setPadding(Ui.dp(c, 9), Ui.dp(c, 4), Ui.dp(c, 9), Ui.dp(c, 4))
            pill.background = Ui.cardBg(c, accInk(c, acc), 11)
            top.addView(pill)
        }
        top.addView(Ui.text(c, "›", 20f, accent).apply {
            setPadding(Ui.dp(c, 6), 0, 0, 0)
        })

        // live progress line: "done of total" + percent + coloured bar
        val prow = Ui.row(c)
        tile.addView(prow, Ui.margins(0, Ui.dp(c, 8), 0, 0, c))
        prow.addView(
            Ui.text(c, "$done of $total chapters", 12f, Ui.color(c, R.color.text_sub)),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        prow.addView(Ui.text(c, "${(frac * 100).toInt()}%", 12f, accent, true))

        val track = LinearLayout(c)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f // single weighted child must render at [frac], not fill the whole track
        track.background = Ui.cardBg(c, 0xFFE4EBE7.toInt(), 6)
        tile.addView(track, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 6)).apply { topMargin = Ui.dp(c, 4) })
        val fillV = View(c)
        fillV.background = Ui.cardBg(c, accent, 6)
        track.addView(fillV, LinearLayout.LayoutParams(0, Ui.dp(c, 6), frac.coerceIn(0f, 1f)))
        // v6.1 motion language: bar grows left-to-right
        fillV.pivotX = 0f
        fillV.scaleX = 0f
        fillV.animate().scaleX(1f).setInterpolator(DecelerateInterpolator(1.4f))
            .setDuration(550).setStartDelay(delayMs + 140).start()

        // v9.8: name the chapter to open, so tapping the tile is never a blind guess
        if (nextIdx != null) {
            val nrow = Ui.row(c)
            nrow.gravity = Gravity.CENTER_VERTICAL
            tile.addView(nrow, Ui.margins(0, Ui.dp(c, 10), 0, 0, c))
            nrow.addView(Ui.text(c, "NEXT", 10f, accent, true).apply { letterSpacing = 0.08f })
            val nxt = Ui.text(c, s.chapters[nextIdx], 12f, Ui.color(c, R.color.text_main))
            nxt.setSingleLine(true)
            nxt.ellipsize = android.text.TextUtils.TruncateAt.END
            nrow.addView(nxt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 8)
            })
        }

        tile.setOnClickListener { host.startSub(SubjectActivity::class.java, "key", s.key) }
        Fx.press(tile)
        if (animateIn) {
            tile.alpha = 0f
            tile.animate().alpha(1f).setDuration(220).setStartDelay(delayMs).start()
        }
    }

    /** Accuracy pill colour — green when solid, amber mid, red when it needs work. */
    private fun accInk(c: MainActivity, acc: Int): Int = when {
        acc >= 70 -> Ui.color(c, R.color.primary)
        acc >= 50 -> Theme.ink(c, 0xFFB26A00.toInt())
        else -> Theme.ink(c, 0xFFE0524D.toInt())
    }

    private fun subjectFill(key: String): Int = when (key) {
        "PHY" -> 0xFFEAF1F8.toInt()
        "CHEM" -> 0xFFFFF3E0.toInt()
        else -> 0xFFE7F3EC.toInt() // Botany & Zoology keep the bio-green family
    }

    private fun subjectAccent(c: MainActivity, key: String): Int = when (key) {
        "PHY" -> 0xFF2F6FB2.toInt()
        "CHEM" -> 0xFFC77B1F.toInt()
        else -> Ui.color(c, R.color.primary)
    }

    private fun subjectLetter(key: String): String = when (key) {
        "PHY" -> "P"
        "CHEM" -> "C"
        "BOT" -> "B"
        else -> "Z"
    }

    private fun subjectTag(key: String): String = when (key) {
        "PHY" -> "Mechanics • Electrodynamics • Modern Physics"
        "CHEM" -> "Physical • Organic • Inorganic"
        "BOT" -> "Plant Kingdom • Physiology"
        else -> "Human Physiology • Genetics"
    }
}
