package com.ayush.neetcracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.widget.EditText
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * v8.20 shell (UI design spec §5): a slim top bar (TITLE · NOTIFICATION), a
 * five-key bottom nav — HOME · STUDY · PRACTICE · PROGRESS · PROFILE — and a
 * floating NEET AI button. Every zone is a first-class tab. The v8.18 tab-jump
 * ☰ menu was removed in v8.20: the bottom bar covers every tab, and Home's
 * top-right app logo opens "About the Developer".
 */
class MainActivity : Activity() {

    private val navKeys = arrayOf("home", "study", "practice", "progress", "profile")
    private val allZones = arrayOf("home", "study", "practice", "progress", "profile")
    private val zoneTitles = mapOf(
        "home" to "Home", "study" to "Study", "practice" to "Practice",
        "progress" to "Progress", "profile" to "Profile"
    )
    private val navIcons = mapOf(
        "home" to "🏠", "study" to "📚", "practice" to "🎯", "progress" to "📊", "profile" to "👤"
    )
    private val NAV_H = 64 // bottom bar height (dp) — also spaces the floating AI button

    private var current = "home"
    private lateinit var content: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var topTitle: TextView
    private lateinit var fab: TextView
    private lateinit var aiScrim: FrameLayout
    private val reqImport = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) current = savedInstanceState.getString("tab") ?: "home"

        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        val column = Ui.column(this)
        column.addView(buildTopBar(), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 50)))
        content = FrameLayout(this)
        column.addView(content, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        bar = buildNavBar()
        column.addView(bar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, NAV_H)))
        root.addView(column, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Floating NEET AI — sits just above the bottom bar, off to the right.
        fab = TextView(this)
        fab.text = "AI"
        fab.setTextColor(Color.WHITE)
        fab.textSize = 15f
        fab.setTypeface(null, android.graphics.Typeface.BOLD)
        fab.gravity = Gravity.CENTER
        fab.background = circleGradient()
        val fabLp = FrameLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56))
        fabLp.gravity = Gravity.BOTTOM or Gravity.END
        fabLp.setMargins(0, 0, Ui.dp(this, 16), Ui.dp(this, NAV_H + 12))
        fab.setOnClickListener { toggleAI() }
        root.addView(fab, fabLp)

        // Scrim + AI coach panel (hidden until the button is tapped).
        aiScrim = FrameLayout(this)
        aiScrim.setBackgroundColor(0x66000000.toInt())
        aiScrim.visibility = View.GONE
        aiScrim.setOnClickListener { toggleAI() }
        root.addView(aiScrim, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        setContentView(root)

        requestNotifPermission()
        Alarms.scheduleAll(this)

        if (savedInstanceState == null) switchTab("home") else refresh() // refresh() draws the restored tab
    }

    /** Keep the active tab across recreate() (theme toggle) and rotation. */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", current)
    }

    // ---------------- top bar ----------------
    private fun buildTopBar(): LinearLayout {
        val tb = Ui.row(this)
        tb.setBackgroundColor(Ui.color(this, R.color.card))
        tb.gravity = Gravity.CENTER_VERTICAL
        val h = Ui.dp(this, 50)
        tb.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h)

        // v8.25: the top-left slot carries the round profile photo (Ayush asked to
        // lift it out of the Home header into the very top bar). Tapping it opens
        // "About the Developer". The 50dp slot keeps the title centred against the
        // bell on the right.
        val avSlot = android.widget.FrameLayout(this)
        val av = android.widget.ImageView(this)
        av.setImageResource(R.mipmap.user_pic)
        av.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        av.background = Ui.cardBg(this, 0xFFFFFFFF.toInt(), 22)
        av.setOnClickListener { startPlain(AboutActivity::class.java) }
        Fx.press(av)
        avSlot.addView(av, android.widget.FrameLayout.LayoutParams(
            Ui.dp(this, 44), Ui.dp(this, 44), Gravity.CENTER))
        tb.addView(avSlot, LinearLayout.LayoutParams(Ui.dp(this, 50), h))

        topTitle = Ui.text(this, "Home", 17f, Ui.color(this, R.color.text_main), true)
        topTitle.gravity = Gravity.CENTER
        tb.addView(topTitle, LinearLayout.LayoutParams(0, h, 1f))

        val bell = Ui.text(this, "🔔", 20f, Ui.color(this, R.color.text_main))
        bell.gravity = Gravity.CENTER
        bell.setOnClickListener { openTodaySheet() }
        Fx.press(bell)
        tb.addView(bell, LinearLayout.LayoutParams(Ui.dp(this, 50), h))
        return tb
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    fun refresh() {
        if (!this::content.isInitialized) return
        // v10.3: keep the page exactly where it was. Rebuilding a tab used to snap
        // the user back to the top — maddening right after tapping "Mark as done"
        // on a block halfway down the day's plan.
        val keepY = findScrollView()?.scrollY ?: 0
        render(current, animate = false)
        if (keepY > 0) {
            val fresh = findScrollView() ?: return
            fresh.viewTreeObserver.addOnPreDrawListener(
                object : android.view.ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        // restore once, after the rebuilt content has been measured
                        fresh.viewTreeObserver.removeOnPreDrawListener(this)
                        fresh.scrollTo(0, keepY)
                        return true
                    }
                })
        }
    }

    /** Depth-first hunt for the tab's ScrollView — the tab is wrapped in a FrameLayout. */
    private fun findScrollView(): ScrollView? {
        fun dig(v: android.view.View): ScrollView? {
            if (v is ScrollView) return v
            if (v is android.view.ViewGroup) {
                for (i in 0 until v.childCount) dig(v.getChildAt(i))?.let { return it }
            }
            return null
        }
        for (i in 0 until content.childCount) dig(content.getChildAt(i))?.let { return it }
        return null
    }

    fun toast(msg: String) = Ui.toast(this, msg)

    fun startSub(clazz: Class<*>, key: String, value: String) {
        val i = android.content.Intent(this, clazz)
        i.putExtra(key, value)
        startActivity(i) // slide transition comes from Theme windowAnimationStyle
    }

    /** Extra-pairs overload (e.g. ids + subject label for a labelled quick drill). */
    fun startSub(clazz: Class<*>, vararg kv: Pair<String, String>) {
        val i = android.content.Intent(this, clazz)
        for ((k, v) in kv) i.putExtra(k, v)
        startActivity(i)
    }

    fun startPlain(clazz: Class<*>) {
        startActivity(android.content.Intent(this, clazz)) // slide transition from theme
    }

    private fun zoneIndex(tab: String): Int = allZones.indexOf(tab).let { if (it < 0) 0 else it }

    private fun buildTab(tab: String, animateIn: Boolean = true): View = when (tab) {
        "home" -> TabHome.build(this, animateIn)
        "study" -> TabStudy.build(this, animateIn)
        "practice" -> TabPractice.build(this)
        "progress" -> TabProgress.build(this)
        else -> TabSettings.build(this)
    }

    // ---- branded page background: motivational slogans behind every tab ----
    // The brand tagline leads, then the backdrop slowly rotates through quotes
    // relevant to the screen you're on (faint enough not to fight the content).
    private fun decorateTab(tab: String, v: View): View {
        if (v !is ScrollView) return v // any future non-scroll tab skips the wrap
        v.setBackgroundColor(Color.TRANSPARENT) // let the watermark show through gaps
        val wrap = FrameLayout(this)
        wrap.setBackgroundColor(Ui.color(this, R.color.bg))

        val pool = sloganPool(tab)
        val wm = TextView(this)
        wm.text = pool[0]
        wm.gravity = Gravity.CENTER
        wm.textSize = 21f
        wm.setLineSpacing(0f, 1.12f)
        wm.setTextColor(Theme.watermark()) // brand green whisper on light, faint mint on dark
        wm.setTypeface(null, Typeface.BOLD)
        wm.rotation = -14f
        wrap.addView(wm, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // slow crossfade between the pool's slogans; stops itself once the tab detaches
        var idx = 0
        val tick = object : Runnable {
            override fun run() {
                if (!wm.isAttachedToWindow) return
                wm.animate().alpha(0f).setDuration(240).withEndAction {
                    if (!wm.isAttachedToWindow) return@withEndAction
                    idx = (idx + 1) % pool.size
                    wm.text = pool[idx]
                    wm.animate().alpha(1f).setDuration(340).start()
                }.start()
                wm.postDelayed(this, 8000)
            }
        }
        wm.postDelayed(tick, 7000)

        wrap.addView(v, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        return wrap
    }

    /** Motivational slogans for the page backdrop — first entry always the brand tagline. */
    private fun sloganPool(tab: String): Array<String> = when (tab) {
        "home" -> arrayOf(
            "STUDY SMART.\nPRACTICE HARD.\nCRACK NEET.",
            "One chapter a day\nkeeps the panic away.",
            "Your future self\nis watching.\nStudy for them."
        )
        "study" -> arrayOf(
            "STUDY SMART.\nPRACTICE HARD.\nCRACK NEET.",
            "Discipline beats\nmotivation — every day.",
            "Small daily efforts,\nbig results."
        )
        "practice" -> arrayOf(
            "STUDY SMART.\nPRACTICE HARD.\nCRACK NEET.",
            "Every question you solve\nis a mark you protect.",
            "Mistakes are data —\nlearn and move on."
        )
        "progress" -> arrayOf(
            "STUDY SMART.\nPRACTICE HARD.\nCRACK NEET.",
            "What gets measured\ngets improved.",
            "Keep the trend\npointing up."
        )
        else -> arrayOf( // profile
            "STUDY SMART.\nPRACTICE HARD.\nCRACK NEET.",
            "Consistency is\nthe real superpower.",
            "Dream it. Plan it.\nCrack it."
        )
    }

    /** v6.1: tabs slide in from the direction the finger moves, the old tab
     *  glides out the other way — a cross-slide instead of a hard swap. */
    fun switchTab(tab: String) {
        if (tab == current) { render(tab); highlight(tab); return }
        // drop any leftovers from a still-animating switch (keeps ≤2 children)
        while (content.childCount > 1) content.removeViewAt(0)
        val dir = if (zoneIndex(tab) >= zoneIndex(current)) 1 else -1

        if (content.childCount > 0) {
            val old = content.getChildAt(0)
            old.animate().alpha(0f).translationX((-dir * Ui.dp(this, 20)).toFloat())
                .setDuration(150)
                .withEndAction { if (old.parent === content) content.removeView(old) }
                .start()
        }
        current = tab
        topTitle.text = zoneTitles[tab] ?: "Home"
        val v = decorateTab(tab, buildTab(tab))
        content.addView(v, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        v.alpha = 0f
        v.translationX = (dir * Ui.dp(this, 34)).toFloat()
        v.scaleX = 0.99f
        v.scaleY = 0.99f
        v.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setInterpolator(DecelerateInterpolator(1.6f)).setDuration(230).start()
        highlight(tab)
    }

    private fun render(tab: String, animate: Boolean = true) {
        content.removeAllViews()
        topTitle.text = zoneTitles[tab] ?: "Home"
        val v = decorateTab(tab, buildTab(tab, animate))
        content.addView(v, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        // v10.3: a refresh updates data in place — skipping the slide keeps it from
        // reading as a flicker when the user just tapped a checkbox.
        if (animate) Fx.fadeSlide(v)
        highlight(tab)
    }

    // ---------------- bottom bar (4 keys, spec §59) ----------------
    private fun buildNavBar(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER
        b.setBackgroundColor(Ui.color(this, R.color.card))
        for (k in navKeys) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.tag = k

            val icon = TextView(this)
            icon.text = navIcons[k]
            icon.textSize = 18f
            icon.gravity = Gravity.CENTER
            item.addView(icon, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 22)))

            val tv = TextView(this)
            tv.text = when (k) {
                "home" -> "HOME"; "study" -> "STUDY"; "practice" -> "PRACTICE"
                "progress" -> "PROGRESS"; else -> "PROFILE"
            }
            tv.textSize = 9f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(null, android.graphics.Typeface.BOLD)
            tv.tag = k
            item.addView(tv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

            val dot = View(this)
            dot.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 2)
            val dotLp = LinearLayout.LayoutParams(Ui.dp(this, 5), Ui.dp(this, 5))
            dotLp.topMargin = Ui.dp(this, 3)
            item.addView(dot, dotLp)

            item.setOnClickListener { switchTab(k) }
            Fx.press(item)
            b.addView(item, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }
        return b
    }

    private fun highlight(tab: String) {
        for (i in 0 until bar.childCount) {
            val item = bar.getChildAt(i) as LinearLayout
            val active = item.tag == tab
            // children: icon(0), label(1), indicator dot(2)
            val label = item.getChildAt(1) as TextView
            val dot = item.getChildAt(2)
            val icon = item.getChildAt(0) as TextView
            label.setTextColor(if (active) Ui.color(this, R.color.primary) else Ui.color(this, R.color.text_sub))
            label.textSize = if (active) 10f else 9f
            dot.visibility = if (active) View.VISIBLE else View.INVISIBLE
            icon.setTextColor(if (active) Ui.color(this, R.color.primary) else Ui.color(this, R.color.text_main))
            if (active) {
                icon.animate().cancel()
                icon.scaleX = 1f
                icon.scaleY = 1f
                icon.animate().scaleX(1.18f).scaleY(1.18f).setDuration(120)
                    .withEndAction {
                        icon.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
                    }.start()
            }
        }
    }

    // ---------------- floating NEET AI (offline coach) ----------------
    private fun circleGradient(): android.graphics.drawable.GradientDrawable {
        val g = android.graphics.drawable.GradientDrawable()
        g.orientation = android.graphics.drawable.GradientDrawable.Orientation.TL_BR
        g.colors = intArrayOf(0xFF3D2B9F.toInt(), 0xFF7B2FF7.toInt())
        g.cornerRadius = Ui.dp(this, 28).toFloat()
        return g
    }

    private fun closeAI() {
        aiScrim.removeAllViews()
        aiScrim.visibility = View.GONE
        fab.visibility = View.VISIBLE
        Fx.pop(fab)
    }

    private fun toggleAI() {
        if (aiScrim.visibility == View.VISIBLE) { closeAI(); return }
        fab.visibility = View.GONE
        aiScrim.removeAllViews()
        aiScrim.visibility = View.VISIBLE

        val card = Ui.column(this)
        card.background = Ui.cardBg(this, Color.WHITE, 20)
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 14))
        card.setOnClickListener { /* swallow — don't close when tapping the card body */ }

        val head = Ui.row(this)
        head.addView(Ui.text(this, "✦", 20f, 0xFF7B2FF7.toInt()), LinearLayout.LayoutParams(
            Ui.dp(this, 30), LinearLayout.LayoutParams.WRAP_CONTENT))
        head.addView(Ui.text(this, "NEET AI", 17f, 0xFF3D2B9F.toInt(), true), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = Ui.dp(this@MainActivity, 4)
        })
        card.addView(head)
        card.addView(Ui.text(this, "offline coach · reads your real practice data", 12f, Ui.color(this, R.color.text_sub)))
        card.addView(Ui.space(this, 12))

        val p = Coach.priority(this)
        if (p == null) {
            card.addView(Ui.text(this, "Answer a few questions and I'll find your weak spots.", 15f, Ui.color(this, R.color.text_main), true))
            card.addView(Ui.space(this, 12))
            val go = pill("🎯  Open Practice centre", 0xFF7B2FF7.toInt()) {
                closeAI()
                startPlain(ExamActivity::class.java)
            }
            card.addView(go)
        } else {
            card.addView(Ui.text(this, "TODAY'S PRIORITY", 11f, Ui.color(this, R.color.text_sub), true))
            card.addView(Ui.space(this, 4))
            card.addView(Ui.text(this, p.chapter, 18f, 0xFF3D2B9F.toInt(), true))
            card.addView(Ui.space(this, 2))
            val band = Coach.bandLabel(p.acc)
            card.addView(Ui.text(this,
                "${Coach.subjectName(p.subject)} · ${p.answered} answered · $band ${p.acc}%",
                13f, bandColor(band), true))
            card.addView(Ui.space(this, 6))
            card.addView(Ui.text(this, Coach.recommend(p.acc), 13f, Ui.color(this, R.color.text_sub)))
            card.addView(Ui.space(this, 12))
            val ids = Coach.drillIds(this, p.subject, p.chapter)
            if (ids.isNotEmpty()) {
                val go = pill("▶  Drill this chapter", 0xFF7B2FF7.toInt()) {
                    closeAI()
                    startSub(QuizActivity::class.java, "ids", ids.joinToString(","))
                }
                card.addView(go)
            } else {
                val go = pill("🎯  Open Practice centre", 0xFF7B2FF7.toInt()) {
                    closeAI()
                    startPlain(ExamActivity::class.java)
                }
                card.addView(go)
            }
        }

        val lp = FrameLayout.LayoutParams(
            (Ui.dp(this, 320)).coerceAtMost((resources.displayMetrics.widthPixels - Ui.dp(this, 28))),
            LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.setMargins(Ui.dp(this, 14), 0, Ui.dp(this, 16), Ui.dp(this, NAV_H + 82))
        aiScrim.addView(card, lp)
        Fx.reveal(card, 10)
    }

    private fun pill(label: String, fill: Int, onClick: () -> Unit): TextView {
        val tv = Ui.text(this, label, 14f, Color.WHITE, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11))
        tv.background = Ui.cardBg(this, fill, 12)
        tv.setOnClickListener { onClick() }
        Fx.press(tv)
        return tv
    }

    private fun bandColor(band: String): Int = when (band) {
        "WEAK" -> 0xFFE53935.toInt()
        "AVERAGE" -> 0xFFE08A00.toInt()
        "GOOD" -> 0xFF2F6FB2.toInt()
        else -> 0xFF2E7D32.toInt()
    }

    // ---------------- notification bell: a real "today" briefing ----------------
    private fun openTodaySheet() {
        val c = this
        val lines = ArrayList<String>()
        val streak = Store.streak(c)
        lines.add(if (streak > 0) "🔥  $streak-day study streak" else "🔥  Start today to begin your streak")
        val min = Store.minutesToday(c)
        val q = Store.questionsToday(c)
        lines.add(if (min > 0 || q > 0) "🎯  $min min focused · $q questions today"
        else "🎯  Nothing logged yet today")
        Coach.weakList(c).firstOrNull()?.let {
            lines.add("⚠️  Weak spot — ${Coach.subjectName(it.subject)} · ${it.chapter} (${it.acc}%)")
        }
        nextTestLine(c)?.let { lines.add("🗓  $it") }
        AlertDialog.Builder(c)
            .setTitle("Today at a glance")
            .setMessage(lines.joinToString("\n\n"))
            .setPositiveButton("Got it", null)
            .setNegativeButton("View progress") { _, _ -> switchTab("progress") }
            .show()
    }

    private fun nextTestLine(c: android.content.Context): String? {
        val cand = ArrayList<Pair<String, String>>()
        EliteSeries.next(c)?.let { cand.add(it.date to EliteSeries.label(it)) }
        MomentumPlan.nextTests(c, 1).firstOrNull()?.let { cand.add(it.date to it.label) }
        AyanSeries.next(c)?.let { cand.add(it.date to AyanSeries.label(it)) }
        val soon = cand.filter { it.first >= Store.todayKey() }.minByOrNull { it.first } ?: return null
        val cal = Store.parse(soon.first)
        val pretty = if (cal != null) SimpleDateFormat("d MMM", Locale.US).format(cal.time) else soon.first
        val diff = ((Store.parse(soon.first)?.timeInMillis
            ?: 0) - (Calendar.getInstance().run { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); timeInMillis })) / 86400000L
        return when {
            diff < 0 -> "${soon.second} — $pretty"
            diff == 0L -> "${soon.second} — today"
            diff == 1L -> "${soon.second} — tomorrow"
            else -> "${soon.second} — in $diff days ($pretty)"
        }
    }

    // ---------------- notification permission (API 33+) ----------------
    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    @Deprecated("Deprecated in platform")
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    // ---------------- import question packs (v3) ----------------
    /** Opens the system file picker for a question-pack JSON (Profile → Import). */
    fun openQuestionPackPicker() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, reqImport)
    }

    @Deprecated("Deprecated in platform")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImport || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val text = try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) {
            ""
        }
        if (text.isBlank()) {
            toast("Could not read that file")
            return
        }
        val added = Store.addImportedJson(this, text)
        if (added > 0) {
            toast("$added new questions imported ✓")
            switchTab("practice")
        } else {
            toast("No new questions found — wrong format?")
        }
    }

    // ============================== v10.6: edit the plan ==============================
    // The timetable is his, so every block can be retimed, renamed, hidden, and new
    // blocks added. Edits are an overlay (Store.plan*) on the generated plan, so the
    // study intelligence inside a block — bio sprint, live chapter, chips — survives
    // being moved, and every alarm re-arms off the edited plan.

    private fun hm(min: Int) = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

    /** The dialog body shared by edit + add: a name field over two tappable clock rows. */
    private class PlanForm(val box: LinearLayout, val name: EditText)

    private fun planEditBox(name: String, start: Int, end: Int, onStart: (Int) -> Unit, onEnd: (Int) -> Unit): PlanForm {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 20)
        box.setPadding(pad, Ui.dp(this, 6), pad, 0)
        val field = EditText(this)
        field.setText(name)
        field.setHint("Block name")
        field.setSingleLine()
        box.addView(field)
        box.addView(timeRow("Starts", start, onStart))
        box.addView(timeRow("Ends", end, onEnd))
        return PlanForm(box, field)
    }

    /** One "Starts 06:00" row — tap it and the clock opens. */
    private fun timeRow(label: String, min: Int, onPick: (Int) -> Unit): TextView {
        val v = Ui.text(this, "$label  ${hm(min)}", 15f, Ui.color(this, R.color.primary), true)
        v.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14))
        v.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                val picked = (h * 60 + m).coerceIn(0, 24 * 60)
                v.text = "$label  ${hm(picked)}"
                onPick(picked)
            }, (min / 60).coerceIn(0, 23), min % 60, true).show()
        }
        Ui.clickable(this, v)
        return v
    }

    fun editPlanBlock(b: MyDay.Block) {
        var s = b.startMin
        var e = b.endMin
        val form = planEditBox(b.title, s, e, { s = it }, { e = it })
        val custom = b.id.startsWith("cx")
        val dlg = AlertDialog.Builder(this)
            .setTitle("Edit block")
            .setView(form.box)
            .setPositiveButton("Save") { _, _ ->
                val title = form.name.text.toString().trim().ifEmpty { b.title }
                Store.setPlanBlock(this, b.id, s, if (e <= s) s + 30 else e, title)
                afterPlanChange("Block updated")
            }
            .setNegativeButton("Cancel", null)
        if (custom) {
            dlg.setNeutralButton("Delete") { _, _ ->
                Store.removePlanCustom(this, b.id)
                afterPlanChange("Block removed")
            }
        } else {
            dlg.setNeutralButton("Hide") { _, _ ->
                Store.hidePlanBlock(this, b.id, b.title)
                afterPlanChange("Hidden — restore it under Edit plan")
            }
        }
        dlg.show()
    }

    fun addPlanBlock() {
        var s = 21 * 60
        var e = 22 * 60
        val form = planEditBox("", s, e, { s = it }, { e = it })
        AlertDialog.Builder(this)
            .setTitle("Add a block")
            .setView(form.box)
            .setPositiveButton("Add") { _, _ ->
                val title = form.name.text.toString().trim()
                if (title.isEmpty()) {
                    toast("Give the block a name first")
                } else {
                    Store.addPlanCustom(this, s, if (e <= s) s + 30 else e, title, "")
                    afterPlanChange("Added to your plan")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun restoreHiddenPlanBlocks() {
        val hidden = Store.hiddenPlanBlocks(this)
        if (hidden.isEmpty()) {
            toast("Nothing is hidden")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Put back a block")
            .setItems(hidden.map { it.second }.toTypedArray()) { _, i ->
                Store.restorePlanBlock(this, hidden[i].first)
                afterPlanChange("${hidden[i].second} is back")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    fun resetPlan() {
        AlertDialog.Builder(this)
            .setTitle("Reset the plan?")
            .setMessage("Every retime, rename and added block goes back to the timetable you wrote out.")
            .setPositiveButton("Reset") { _, _ ->
                Store.resetPlanLayout(this)
                afterPlanChange("Plan reset to your timetable")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun afterPlanChange(msg: String) {
        Alarms.reschedule(this) // the plan moved, so the block alerts must follow it
        refresh()
        toast(msg)
    }
}
