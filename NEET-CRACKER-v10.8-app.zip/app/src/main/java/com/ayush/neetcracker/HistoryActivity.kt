package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Study history (§12, upgraded v9.3).
 *
 * Same data as before (Store.getSessions + the range filter) but the screen now
 * carries more: a stats hero (total time · sessions · average session · streak),
 * a time-by-subject split with bars, and richer session rows (subject chip,
 * clock time, duration pill). Pure UI — no logic or storage change.
 */
class HistoryActivity : Activity() {

    private var filter = "All"
    private val clock = SimpleDateFormat("HH:mm", Locale.US)

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(this, "Study History", 20f, Ui.color(this, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@HistoryActivity, 6)
        })
        root.addView(header)

        // filter chips
        val chips = Ui.row(this)
        chips.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 8))
        for (f in arrayOf("Today", "This Week", "This Month", "All")) {
            val chip = chip(f == filter, f)
            chip.setOnClickListener { filter = f; render() }
            chips.addView(chip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            chips.addView(android.view.View(this), LinearLayout.LayoutParams(Ui.dp(this, 6), 1))
        }
        root.addView(chips)

        val sessions = Store.getSessions(this).filter { inRange(it) }
        val total = sessions.sumBy { it.durMin }
        val count = sessions.size
        val avg = if (count > 0) total / count else 0
        val activeDays = sessions.map { it.date }.distinct().size

        val sv = ScrollView(this)
        val list = Ui.column(this)
        val pad = Ui.dp(this, 16)
        list.setPadding(pad, Ui.dp(this, 2), pad, Ui.dp(this, 24))
        sv.addView(list, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- stats hero ----
        val hero = Ui.column(this)
        hero.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 18)
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16))
        hero.addView(Ui.text(this, fmt(total), 34f, Color.WHITE, true))
        hero.addView(Ui.text(this, "total study time in this range", 13f, 0xCCFFFFFF.toInt()))
        hero.addView(Ui.space(this, 14))

        val stats = Ui.row(this)
        statCell(stats, "$count", "sessions")
        statCell(stats, fmt(avg), "avg session")
        statCell(stats, "${Store.streak(this)}", "day streak")
        hero.addView(stats)
        list.addView(hero)
        list.addView(Ui.space(this, 12))

        // ---- time by subject ----
        if (total > 0) {
            val bySubj = sessions.groupBy { it.subjectKey }
                .mapValues { it.value.sumBy { s -> s.durMin } }
                .toList()
                .sortedByDescending { it.second }
            val split = Ui.column(this)
            split.background = Ui.cardBg(this)
            split.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14))
            split.addView(sectionLabel("TIME BY SUBJECT"))
            split.addView(Ui.space(this, 4))
            for ((key, min) in bySubj) {
                split.addView(splitRow(key, min, total))
                split.addView(Ui.space(this, 8))
            }
            list.addView(split)
            list.addView(Ui.space(this, 14))
        }

        // ---- session list ----
        if (sessions.isEmpty()) {
            list.addView(Ui.text(this, "No study sessions in this range yet.", 15f, Ui.color(this, R.color.text_sub)).apply {
                setPadding(Ui.dp(this@HistoryActivity, 8), Ui.dp(this@HistoryActivity, 30), 0, 0)
            })
        } else {
            list.addView(sectionLabel("SESSIONS · $activeDays ACTIVE ${if (activeDays == 1) "DAY" else "DAYS"}"))
            var lastDate: String? = null
            for (s in sessions) {
                if (s.date != lastDate) {
                    lastDate = s.date
                    val gh = Ui.text(this, Store.humanDate(s.date), 14f, Ui.color(this, R.color.primary), true)
                    gh.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 2))
                    list.addView(gh)
                }
                list.addView(sessionRow(s))
                list.addView(Ui.space(this, 6))
            }
        }
        setContentView(root)
    }

    private fun sectionLabel(s: String): TextView =
        Ui.text(this, s, 11.5f, Ui.color(this, R.color.primary), true).apply {
            setTypeface(null, Typeface.BOLD)
            letterSpacing = 0.06f
        }

    /** One mini-stat cell inside the hero (value over label), equal weight. */
    private fun statCell(row: LinearLayout, value: String, label: String) {
        val col = Ui.column(this)
        col.addView(Ui.text(this, value, 20f, Color.WHITE, true))
        col.addView(Ui.text(this, label, 11f, 0xB3FFFFFF.toInt()))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    /** Subject time split: chip · name · share bar · "12m · 34%". */
    private fun splitRow(key: String, min: Int, total: Int): LinearLayout {
        val row = Ui.row(this)
        row.gravity = Gravity.CENTER_VERTICAL

        val chip = Ui.text(this, letter(key), 13f, Color.WHITE, true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(this, accent(key), 14)
        row.addView(chip, LinearLayout.LayoutParams(Ui.dp(this, 28), Ui.dp(this, 28)))

        val mid = Ui.column(this)
        mid.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0)
        mid.addView(Ui.text(this, Subjects.byKey(key)?.name ?: "General", 13.5f, Ui.color(this, R.color.text_main), true))
        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 4)
        val fill = android.view.View(this)
        fill.background = Ui.cardBg(this, accent(key), 4)
        val frac = if (total > 0) min.toFloat() / total else 0f
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(this, 6), frac.coerceIn(0.02f, 1f)))
        val tlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 6))
        tlp.topMargin = Ui.dp(this, 5)
        mid.addView(track, tlp)
        row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val right = Ui.text(this, "${fmt(min)} · ${if (total > 0) min * 100 / total else 0}%", 12.5f, Ui.color(this, R.color.primary), true)
        right.gravity = Gravity.END
        row.addView(right)
        return row
    }

    private fun inRange(s: Store.Session): Boolean {
        val cal = Store.parse(s.date) ?: return true
        val now = Calendar.getInstance()
        return when (filter) {
            "Today" -> s.date == Store.todayKey()
            "This Week" -> {
                val diff = daysAgo(cal, now)
                diff in 0..6
            }
            "This Month" -> {
                cal.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                    cal.get(Calendar.MONTH) == now.get(Calendar.MONTH)
            }
            else -> true
        }
    }

    private fun daysAgo(d: Calendar, now: Calendar): Int {
        val a = Calendar.getInstance().apply {
            timeInMillis = d.timeInMillis
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val b = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return ((b.timeInMillis - a.timeInMillis) / 86400000L).toInt()
    }

    private fun sessionRow(s: Store.Session): LinearLayout {
        val row = Ui.row(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.cardBg(this)
        row.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10))

        val chip = Ui.text(this, letter(s.subjectKey), 13f, Color.WHITE, true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(this, accent(s.subjectKey), 15)
        row.addView(chip, LinearLayout.LayoutParams(Ui.dp(this, 32), Ui.dp(this, 32)))

        val info = Ui.column(this)
        info.setPadding(Ui.dp(this, 12), 0, 0, 0)
        val subject = Subjects.byKey(s.subjectKey)?.name ?: "General"
        info.addView(Ui.text(this, subject + (if (s.chapter.isEmpty()) "" else " — " + s.chapter), 15f, Ui.color(this, R.color.text_main), true))
        val when_ = if (s.ts > 0) "${clock.format(Date(s.ts))} · ${s.date}" else s.date
        info.addView(Ui.text(this, when_, 12f, Ui.color(this, R.color.text_sub)))
        row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val dur = Ui.text(this, "${s.durMin}m", 14f, Ui.color(this, R.color.primary), true)
        dur.gravity = Gravity.CENTER
        dur.background = Ui.cardBg(this, 0xFFE7F3EC.toInt(), 12)
        dur.setPadding(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5))
        row.addView(dur)
        return row
    }

    private fun fmt(min: Int): String = if (min < 60) "${min}m" else "${min / 60}h ${min % 60}m"

    private fun letter(key: String): String = when (key) {
        "PHY" -> "P"
        "CHEM" -> "C"
        "BOT" -> "B"
        "ZOO" -> "Z"
        else -> "•"
    }

    private fun accent(key: String): Int = when (key) {
        "PHY" -> 0xFF2F6FB2.toInt()
        "CHEM" -> 0xFFC77B1F.toInt()
        "BOT" -> 0xFF2E7D4F.toInt()
        "ZOO" -> 0xFF1F8A6A.toInt()
        else -> Ui.color(this, R.color.primary)
    }

    private fun chip(active: Boolean, label: String): TextView {
        val tv = Ui.text(
            this, label, 12f,
            if (active) android.graphics.Color.WHITE else Ui.color(this, R.color.text_main), true
        )
        tv.gravity = Gravity.CENTER
        tv.setPadding(Ui.dp(this, 4), Ui.dp(this, 9), Ui.dp(this, 4), Ui.dp(this, 9))
        tv.background = Ui.cardBg(this, if (active) Ui.color(this, R.color.primary) else 0xFFEAF1EC.toInt(), 10)
        return tv
    }
}
