package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Revision centre (design spec §2 — "revision center"): the one place that
 * gathers everything worth going over again — every question whose latest
 * attempt was wrong, plus every question you starred — and turns it into a
 * revision loop.
 *
 * The loop is honest and offline: Store.mistakes() keys off each question's
 * LATEST attempt, so once you beat a question in a revision round its newest
 * attempt is correct and it drops out of the list on its own; miss it and it
 * stays. Pure UI over existing Store data — no new storage, no engine change.
 */
class RevisionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val c = this
        val mistakes = Store.mistakes(c)
        val starred = Store.bookmarks(c).filter { Store.questionById(c, it) != null }
        // v9.8: the queue lives in Store so the Study-tab due chip can't drift from it.
        val due = Store.revisionDue(c)

        val root = Ui.column(c)
        root.setBackgroundColor(Ui.color(c, R.color.bg))
        root.addView(header())

        val sv = ScrollView(c)
        val col = Ui.column(c)
        col.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 28))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(Ui.text(c, "Your weak spots, in one place.", 14f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 12))

        // ---- hero: how many are waiting + the one action ----
        val hero = Ui.column(c)
        hero.background = Ui.cardBg(c, 0xFFF3EEFF.toInt(), 18)
        hero.setPadding(Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18))
        hero.addView(Ui.text(c, "TO REVISE", 11f, Ui.color(c, R.color.primary), true))
        val big = Ui.text(c, "${due.size}", 46f, Ui.color(c, R.color.primary), true)
        big.setTypeface(null, Typeface.BOLD)
        hero.addView(big)
        hero.addView(Ui.text(c, "${mistakes.size} from mistakes · ${starred.size} starred", 13.5f, Ui.color(c, R.color.text_sub)))
        hero.addView(Ui.space(c, 14))
        val go = Ui.button(c, if (due.isEmpty()) "Nothing to revise" else "▶   Revise now", due.isNotEmpty())
        go.gravity = Gravity.CENTER
        go.setOnClickListener {
            if (due.isEmpty()) {
                Ui.toast(c, "All clear — nothing to revise")
                return@setOnClickListener
            }
            val i = Intent(c, QuizActivity::class.java)
            i.putExtra("ids", due.joinToString(","))
            startActivity(i)
        }
        hero.addView(go, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 52)))
        col.addView(hero)
        col.addView(Ui.space(c, 10))
        col.addView(Ui.text(c, "Beat a question and it leaves this list; miss it and it stays.", 12.5f, Ui.color(c, R.color.text_sub)))

        if (due.isEmpty()) {
            col.addView(Ui.space(c, 22))
            col.addView(emptyCard())
            setContentView(root)
            return
        }

        // ---- drill one subject at a time ----
        col.addView(Ui.space(c, 22))
        col.addView(sectionLabel("REVISE BY SUBJECT"))
        col.addView(Ui.space(c, 8))
        val bySubject = LinkedHashMap<String, MutableList<String>>()
        for (id in due) {
            val q = Store.questionById(c, id) ?: continue
            bySubject.getOrPut(q.subject) { ArrayList() }.add(id)
        }
        for ((key, ids) in bySubject) {
            col.addView(subjectRow(key, ids))
            col.addView(Ui.space(c, 8))
        }

        // ---- read the full list, neatly ----
        col.addView(Ui.space(c, 14))
        col.addView(sectionLabel("READ THEM IN FULL"))
        col.addView(Ui.space(c, 8))
        col.addView(linkRow("Mistake book", "${mistakes.size} questions you got wrong") {
            startActivity(Intent(c, ReviewActivity::class.java).putExtra("mode", "mistakes"))
        })
        col.addView(Ui.space(c, 8))
        col.addView(linkRow("Bookmarks", "${starred.size} questions you saved") {
            startActivity(Intent(c, ReviewActivity::class.java).putExtra("mode", "bookmarks"))
        })
        setContentView(root)
    }

    // ---------------- pieces ----------------

    private fun header(): LinearLayout {
        val c = this
        val h = Ui.row(c)
        h.setPadding(Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 4))
        val back = Ui.text(c, "‹", 30f, Ui.color(c, R.color.primary), true)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        Fx.press(back)
        h.addView(back, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        val title = Ui.text(c, "Revision centre", 20f, Ui.color(c, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        h.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 6)
        })
        return h
    }

    private fun sectionLabel(t: String): TextView =
        Ui.text(this, t, 11f, Ui.color(this, R.color.text_sub), true)

    private fun subjectRow(key: String, ids: List<String>): LinearLayout {
        val c = this
        val s = Subjects.byKey(key)
        val card = Ui.row(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12))
        card.gravity = Gravity.CENTER_VERTICAL

        val chip = Ui.text(c, (s?.key ?: key).take(1).uppercase(), 16f, Ui.color(c, R.color.primary), true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 14)
        card.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))

        val col = Ui.column(c)
        col.setPadding(Ui.dp(c, 12), 0, 0, 0)
        col.addView(Ui.text(c, s?.name ?: key, 15.5f, Ui.color(c, R.color.text_main), true))
        col.addView(Ui.text(c, "${ids.size} to revise", 12.5f, Ui.color(c, R.color.text_sub)))
        card.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val drill = Ui.button(c, "Drill", true)
        drill.gravity = Gravity.CENTER
        drill.setOnClickListener {
            val i = Intent(c, QuizActivity::class.java)
            i.putExtra("ids", ids.joinToString(","))
            i.putExtra("subject", key)
            startActivity(i)
        }
        card.addView(drill, LinearLayout.LayoutParams(Ui.dp(c, 84), Ui.dp(c, 42)))
        Fx.press(card)
        return card
    }

    private fun linkRow(title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val c = this
        val card = Ui.row(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 13), Ui.dp(c, 14), Ui.dp(c, 13))
        card.gravity = Gravity.CENTER_VERTICAL
        val col = Ui.column(c)
        col.addView(Ui.text(c, title, 15f, Ui.color(c, R.color.text_main), true))
        col.addView(Ui.text(c, sub, 12.5f, Ui.color(c, R.color.text_sub)))
        card.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(Ui.text(c, "›", 22f, Ui.color(c, R.color.primary)))
        card.setOnClickListener { onClick() }
        Fx.press(card)
        return card
    }

    private fun emptyCard(): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFE7F3EC.toInt(), 16)
        card.setPadding(Ui.dp(c, 18), Ui.dp(c, 20), Ui.dp(c, 18), Ui.dp(c, 20))
        card.addView(Ui.text(c, "All clear 🎯", 18f, Ui.color(c, R.color.primary), true))
        card.addView(Ui.space(c, 6))
        card.addView(Ui.text(c, "No mistakes waiting, nothing starred. Practice a chapter — anything you get wrong lands here for revision.", 14f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 14))
        val p = Ui.button(c, "Go practice", false)
        p.gravity = Gravity.CENTER
        p.setOnClickListener { finish() }
        card.addView(p, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 48)))
        return card
    }
}
