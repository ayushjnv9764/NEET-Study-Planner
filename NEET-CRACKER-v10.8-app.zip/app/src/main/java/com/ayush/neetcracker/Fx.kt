package com.ayush.neetcracker

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator

/**
 * v5 motion + gradient helpers. Pure platform animations (no AndroidX), so they
 * work everywhere the code-built UI is used.
 */
object Fx {

    /** Subtle "squish" on touch-down, spring back on release. Safe alongside OnClick. */
    fun press(v: View) {
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.965f).scaleY(0.965f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
            }
            false // don't consume — let the click listener fire
        }
    }

    /** Fade + rise-in used when a screen (or tab) is (re)rendered. */
    fun fadeSlide(v: View) {
        val ctx = v.context
        v.alpha = 0f
        v.translationY = Ui.dp(ctx, 12).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(240).start()
    }

    /** Quick spring "pop" — great for confirming a tap/selection. */
    fun pop(v: View, peak: Float = 1.07f) {
        v.animate().cancel()
        v.scaleX = peak
        v.scaleY = peak
        v.animate().scaleX(1f).scaleY(1f)
            .setInterpolator(OvershootInterpolator(1.8f))
            .setDuration(230).start()
    }

    /** Horizontal jiggle for a wrong answer. */
    fun shake(v: View) {
        v.animate().cancel()
        val steps = listOf(-10f, 10f, -7f, 7f, -3f, 0f)
        var i = 0
        fun run() {
            if (i >= steps.size) return
            val x = steps[i++]
            v.animate().translationX(x).setDuration(44).withEndAction { run() }.start()
        }
        run()
    }

    /** Slide+fade a view in (e.g. an explanation card appearing after an answer). */
    fun reveal(v: View, riseDp: Int = 8) {
        v.alpha = 0f
        v.translationY = Ui.dp(v.context, riseDp).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(210).start()
    }

    /** Diagonal gradient background. Colors are packed ARGB ints (e.g. 0xFF6C5CE7). */
    fun gradient(vararg colors: Int): GradientDrawable {
        val g = GradientDrawable()
        g.orientation = GradientDrawable.Orientation.TL_BR
        g.colors = colors
        return g
    }

    /** For when only the type-safe resource ids are available. */
    fun gradientRes(c: Context, vararg resIds: Int): GradientDrawable {
        val cols = resIds.map { Ui.color(c, it) }.toIntArray()
        return gradient(*cols)
    }
}
