package com.ayush.neetcracker

import android.content.Context
import org.json.JSONArray

/**
 * v8.3 — Ayan's NRTS Real-Test 2027 series (Ayush's friend). 21 Sunday tests,
 * 26-Jul-2026 → 11-Apr-2027. Kept strictly separate from Ayush's own plans:
 * Ayan is a different person, so his series shows its per-subject syllabus and
 * dates as a reference calendar — never Ayush's prep ticks.
 *
 * scope: "part" = per-subject chapter lists; "xi" = 11th full syllabus;
 * "full" = whole NEET syllabus.
 */
object AyanSeries {

    data class Item(
        val n: Int,
        val date: String,          // yyyy-MM-dd (a Sunday)
        val scope: String,         // part | xi | full
        val phy: List<String>, val chem: List<String>,
        val bot: List<String>, val zoo: List<String>
    ) {
        fun chapters(slot: String): List<String> = when (slot) {
            "PHY" -> phy
            "CHEM" -> chem
            "BOT" -> bot
            else -> zoo
        }
    }

    private var cached: List<Item>? = null

    fun rows(c: Context): List<Item> {
        cached?.let { return it }
        val out = ArrayList<Item>()
        try {
            val text = c.assets.open("ayan_nrts.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                fun list(key: String): List<String> {
                    val a = o.optJSONArray(key) ?: return emptyList()
                    return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
                }
                out.add(
                    Item(
                        o.optInt("n", 0),
                        o.optString("date", ""),
                        o.optString("scope", "part"),
                        list("phy"), list("chem"), list("bot"), list("zoo")
                    )
                )
            }
            out.sortBy { it.date }
        } catch (e: Exception) {
            // asset missing or malformed -> surface simply doesn't render
        }
        cached = out
        return out
    }

    fun has(c: Context): Boolean = rows(c).isNotEmpty()

    fun next(c: Context): Item? =
        rows(c).filter { it.date >= Store.todayKey() }.minByOrNull { it.date }

    /** "NRTS 04" — the series' own short name. */
    fun label(t: Item): String = "NRTS " + t.n.toString().padStart(2, '0')

    fun scopeLabel(t: Item): String = when (t.scope) {
        "xi" -> "Class 11 · full syllabus"
        "full" -> "Full NEET syllabus"
        else -> "syllabus below"
    }

    /** Tests at/after today, chronological. */
    fun upcoming(c: Context): List<Item> = rows(c).filter { it.date >= Store.todayKey() }
}
