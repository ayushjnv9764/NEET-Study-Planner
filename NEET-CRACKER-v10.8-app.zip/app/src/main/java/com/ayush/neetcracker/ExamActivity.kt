package com.ayush.neetcracker

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/**
 * v5 NEET Mock Test — exam-mode practice that feels like the real thing:
 * +4 correct / −1 wrong / 0 skipped, no instant feedback, a live countdown,
 * and a full result card at the end. Wrong answers still land in the mistake
 * book so they come back for revision.
 */
class ExamActivity : Activity() {

    private val NAVY_TOP = 0xFF0A0F2E.toInt()
    private val NAVY_BOT = 0xFF131B52.toInt()
    private val PANEL = 0x1FFFFFFF.toInt()
    private val SOFT = 0xFFC3CDFF.toInt()
    private val FAINT = 0xFF7E8BC7.toInt()
    private val CYAN = 0xFF22D3EE.toInt()
    private val CYAN_BG = 0x3322D3EE.toInt()
    private val CYAN_DARK = 0xFF0A1B3A.toInt()
    private val GOLD = 0xFFFFC24B.toInt()
    private val RED = 0xFFFF7B7B.toInt()
    private val GREEN = 0xFF4BE1A0.toInt()

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() = tick()
    }

    private var mode = "start" // start | test | result
    private var scope = "ALL"
    private var scopeTag: String? = null // chapter name for chapter-scoped tests (header/result label)
    private var qs = listOf<Store.Question>()
    private var picks = IntArray(0)
    private var marked = BooleanArray(0)   // v7: "mark for review" per question
    private var isSectioned = false        // v7: full mock runs in NEET subject order
    private var sectionOf = IntArray(0)    // v7: subject position (0..3) per question
    private var idx = 0
    private var assignedSec = 0
    private var remainingSec = 0
    private var lastTickMs = 0L
    private var submitted = false

    // live view handles
    private lateinit var timerTv: TextView
    private lateinit var counterTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var qBody: LinearLayout
    private lateinit var qScroll: ScrollView
    private val squares = ArrayList<TextView>()
    private val options = ArrayList<OptCard>()
    private var markBtn: TextView? = null   // v7: mark-for-review toggle
    private var paletteDlg: AlertDialog? = null   // §10 palette grid dialog

    /** An option rendered as a letter-badge card (UI spec §10: large option cards). */
    private class OptCard(val card: LinearLayout, val badge: TextView, val body: TextView)

    // result accumulators (filled at submit time)
    private var resultScore = 0
    private var resultCorrect = 0
    private var resultWrong = 0
    private var resultSkipped = 0
    private var resultUseSec = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // §11: the PYQ hub can open a specific paper straight away.
        val py = intent.getIntExtra("paperYear", 0)
        val paper = if (py != 0) Store.PAPERS.firstOrNull { it.year == py } else null
        if (paper != null) startPaper(paper) else render()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    @Deprecated("Deprecated in platform")
    override fun onBackPressed() {
        if (mode == "test" && !submitted) quitTest() else super.onBackPressed()
    }

    private fun render() {
        when (mode) {
            "test" -> {
                buildTest()
                showQ()
                lastTickMs = System.currentTimeMillis()
                handler.removeCallbacks(ticker)
                handler.postDelayed(ticker, 1000)
            }
            "result" -> buildResult()
            else -> buildStart()
        }
    }

    private fun fmt(sec: Int): String = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)

    private fun scoreText(n: Int): String = if (n > 0) "+$n" else "$n"

    // ============================== start screen ==============================
    // v7: a proper Test center — Full NEET mock (subject-wise, NEET order),
    // Subject tests, and Chapter tests that light up as question packs arrive.
    private fun buildStart() {
        val bank = Store.questionBank(this)
        val sv = ScrollView(this)
        sv.setBackgroundColor(NAVY_TOP)
        val col = Ui.column(this)
        val pad = Ui.dp(this, 20)
        col.setPadding(pad, Ui.dp(this, 26), pad, Ui.dp(this, 28))
        sv.addView(col)
        setContentView(sv)

        col.addView(Ui.text(this, "TEST CENTER", 13f, GOLD, true))
        col.addView(Ui.space(this, 4))
        col.addView(Ui.text(this, "NEET Mock Test", 28f, Color.WHITE, true))
        col.addView(Ui.space(this, 6))
        col.addView(
            Ui.text(
                this,
                "Real exam feel. +4 correct · −1 wrong · 0 skip · countdown running.\nThe Full mock runs subject-wise in NEET order — Physics → Chemistry → Botany → Zoology.",
                15f, SOFT
            )
        )
        col.addView(Ui.space(this, 22))

        if (bank.isEmpty()) {
            col.addView(Ui.text(this, "No questions yet — import a question pack in Settings.", 14f, SOFT))
        } else {
            // ---- Full NEET mock (up to 45 per subject, real NEET attempt shape) ----
            var totalN = 0
            val parts = ArrayList<String>()
            for (s in Subjects.ALL) {
                val n = minOf(bank.count { it.subject == s.key }, PER_SUBJECT)
                totalN += n
                parts += "${s.name} $n"
            }
            val nTxt = parts.joinToString("   ·   ")
            startCard(
                col, "Full NEET Mock — all subjects",
                "$nTxt\n$totalN questions · ${secLabel(totalN)} · NEET subject order",
                { startTest(null) }
            )
            col.addView(Ui.space(this, 8))

            // ---- Subject tests ----
            val subjectRows = Subjects.ALL.map { s -> s to bank.count { it.subject == s.key } }
                .filter { it.second > 0 }
            if (subjectRows.isNotEmpty()) {
                sectionLabel(col, "SUBJECT TESTS")
                for ((s, n) in subjectRows) {
                    val sub = if (n > 100) "100-question random sample · ${secLabel(100)}"
                    else "$n questions · ${secLabel(n)}"
                    startCard(col, "${s.name} test", sub) { startTest(s.key) }
                }
            }

            // ---- Past Year Papers: the real thing in official order (v8.4) ----
            val papers = Store.PAPERS.filter { Store.paperQuestions(this, it).isNotEmpty() }
            if (papers.isNotEmpty()) {
                sectionLabel(col, "PAST YEAR PAPERS")
                col.addView(
                    Ui.text(
                        this,
                        "Real NEET papers, original question order, no shuffle. Text edition: formula/figure questions are left out until an image feature exists.",
                        13f, SOFT
                    )
                )
                col.addView(Ui.space(this, 12))
                for (p in papers) {
                    val pq = Store.paperQuestions(this, p)
                    val parts = Subjects.ALL.mapNotNull { s ->
                        val n = pq.count { it.subject == s.key }
                        if (n > 0) "${s.name} $n" else null
                    }
                    startCard(
                        col, p.label,
                        "${parts.joinToString("   ·   ")}\n${pq.size} questions · ${secLabel(pq.size)} · real paper order",
                        { startPaper(p) }
                    )
                }
                col.addView(Ui.space(this, 8))
            }

            // ---- Chapter tests — only chapters with enough questions to drill.
            // Grows automatically the day a bigger pack for that chapter lands.
            val counts = HashMap<Pair<String, String>, Int>()
            for (q in bank) counts.merge(q.subject to q.chapter, 1, Int::plus)
            val bySubject = LinkedHashMap<String, MutableList<Pair<String, Int>>>()
            for ((key, n) in counts) {
                if (n >= MIN_CHAPTER) bySubject.getOrPut(key.first) { ArrayList() }.add(key.second to n)
            }
            if (bySubject.isNotEmpty()) {
                sectionLabel(col, "CHAPTER TESTS")
                col.addView(
                    Ui.text(
                        this,
                        "Chapter drills with ${MIN_CHAPTER}+ questions show here automatically as packs arrive.",
                        13f, SOFT
                    )
                )
                col.addView(Ui.space(this, 12))
                for ((sKey, chs) in bySubject) {
                    val sname = Subjects.byKey(sKey)?.name ?: sKey
                    col.addView(Ui.text(this, sname, 12f, GOLD, true))
                    col.addView(Ui.space(this, 6))
                    for ((ch, n) in chs) {
                        val sub = if (n > 100) "100-question sample · ${secLabel(100)}"
                        else "$n questions · ${secLabel(n)}"
                        startCard(col, ch, sub) { startTest(sKey, ch, ch) }
                    }
                    col.addView(Ui.space(this, 6))
                }
            }
        }

        col.addView(Ui.space(this, 10))
        col.addView(Ui.text(this, "Answers count toward accuracy & your mistake book.", 12f, FAINT))
        col.addView(Ui.text(this, "NEET CRACKER · BY AYUSH · v10.8", 12f, FAINT))
    }

    private fun sectionLabel(col: LinearLayout, label: String) {
        col.addView(Ui.space(this, 10))
        col.addView(Ui.text(this, label, 12f, GOLD, true))
        col.addView(Ui.space(this, 8))
    }

    private fun secLabel(n: Int): String {
        val sec = (n * SEC_PER_Q).coerceAtMost(7200)
        return if (sec >= 3600)
            String.format(Locale.US, "%d h %02d min", sec / 3600, (sec % 3600) / 60)
        else "${sec / 60} min"
    }

    private fun startCard(col: LinearLayout, title: String, sub: String, onClick: () -> Unit) {
        val card = Ui.column(this)
        card.background = Ui.cardBg(this, PANEL, 18, 0xFF8B9CFF.toInt())
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14))
        val row = Ui.row(this)
        card.addView(row)
        val left = Ui.column(this)
        left.addView(Ui.text(this, title, 16f, Color.WHITE, true))
        left.addView(Ui.text(this, sub, 13f, SOFT))
        row.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(this, "▶", 20f, CYAN, true))
        card.setOnClickListener { onClick() }
        Fx.press(card)
        col.addView(card, Ui.margins(0, 0, 0, 12, this))
    }

    private fun startTest(subKey: String?, chapter: String? = null, tag: String? = null) {
        val bank = Store.questionBank(this)
        // v7: the Full mock is assembled in NEET subject order — Physics →
        // Chemistry → Botany → Zoology, up to 45 sampled per subject (the real
        // NEET attempt shape). It grows fuller automatically as packs arrive.
        val list: List<Store.Question> = if (subKey == null) {
            buildList {
                for (s in Subjects.ALL) {
                    val pool = bank.filter { it.subject == s.key }.shuffled()
                    addAll(pool.take(PER_SUBJECT))
                }
            }
        } else {
            val filtered = if (chapter == null) bank.filter { it.subject == subKey }
            else bank.filter { it.subject == subKey && it.chapter == chapter }
            val sh = filtered.shuffled()
            // Cap at 100 so a big subject/chapter stays a drill, not a marathon.
            if (sh.size > 100) sh.take(100) else sh
        }
        if (list.isEmpty()) {
            Ui.toast(this, "No questions ready for that yet")
            return
        }
        scope = subKey ?: "ALL"
        scopeTag = tag
        isSectioned = subKey == null
        qs = list
        sectionOf = IntArray(qs.size) { i ->
            Subjects.ALL.indexOfFirst { it.key == qs[i].subject }.coerceAtLeast(0)
        }
        marked = BooleanArray(qs.size)
        picks = IntArray(qs.size) { -1 }
        idx = 0
        submitted = false
        assignedSec = (qs.size * SEC_PER_Q).coerceAtMost(7200)
        remainingSec = assignedSec
        mode = "test"
        render()
    }

    /** v8.4 — launches a Past Year Paper in its official order (never shuffled).
     * Section banners appear only at the three real paper seams — Physics →
     * Chemistry → Biology — because NEET prints Botany/Zoology questions in one
     * continuous Biology block; the per-question tag still names the discipline. */
    private fun startPaper(p: Store.Paper) {
        val list = Store.paperQuestions(this, p)
        if (list.isEmpty()) {
            Ui.toast(this, "No questions ready for that yet")
            return
        }
        scope = "PYQ:${p.year}"
        scopeTag = p.label
        isSectioned = true
        qs = list
        sectionOf = IntArray(qs.size) { i ->
            when (qs[i].subject) { "PHY" -> 0; "CHEM" -> 1; else -> 2 }
        }
        marked = BooleanArray(qs.size)
        picks = IntArray(qs.size) { -1 }
        idx = 0
        submitted = false
        assignedSec = (qs.size * SEC_PER_Q).coerceAtMost(7200)
        remainingSec = assignedSec
        mode = "test"
        render()
    }

    // ============================== test screen ==============================
    private fun buildTest() {
        val root = Ui.column(this)
        root.setBackgroundColor(NAVY_TOP)
        root.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 6))

        val isPaper = scope.startsWith("PYQ:")
        val name = if (isPaper) (scopeTag ?: "PAST YEAR PAPER") else scopeLabel()

        // row 1 — quit · test name · submit
        val head = Ui.row(this)
        val quit = Ui.text(this, "✕", 20f, SOFT, true)
        quit.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        quit.setOnClickListener { quitTest() }
        Fx.press(quit)
        head.addView(quit, LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 40)))
        val nm = Ui.text(this, name, 11f, GOLD, true)
        nm.gravity = Gravity.CENTER
        nm.setSingleLine(true)
        nm.setEllipsize(android.text.TextUtils.TruncateAt.END)
        head.addView(nm, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val submit = pill("Submit", Color.WHITE) { confirmSubmit() }
        head.addView(submit)
        root.addView(head)

        // row 2 — question counter · mark for review · countdown
        val strip = Ui.row(this)
        strip.setPadding(Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2), 0)
        counterTv = Ui.text(this, "", 17f, Color.WHITE, true)
        strip.addView(counterTv)
        val gap = android.view.View(this)
        strip.addView(gap, LinearLayout.LayoutParams(0, 1, 1f))
        markBtn = pill("◈ Mark", SOFT) { toggleMark() }
        strip.addView(markBtn)
        timerTv = Ui.text(this, fmt(remainingSec), 18f, Color.WHITE, true)
        timerTv.gravity = Gravity.CENTER
        val tlp = LinearLayout.LayoutParams(Ui.dp(this, 92), Ui.dp(this, 36))
        tlp.setMargins(Ui.dp(this, 8), 0, 0, 0)
        strip.addView(timerTv, tlp)
        root.addView(strip)

        infoTv = Ui.text(this, "", 11.5f, FAINT)
        infoTv.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), 0)
        root.addView(infoTv)

        qScroll = ScrollView(this)
        qBody = Ui.column(this)
        qBody.setPadding(Ui.dp(this, 2), 0, Ui.dp(this, 2), Ui.dp(this, 6))
        qScroll.addView(qBody)
        root.addView(qScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // bottom — previous · palette grid · next
        val nav = Ui.row(this)
        val prev = pill("‹ Prev", SOFT) { if (idx > 0) { idx--; showQ() } }
        nav.addView(prev, LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f))
        val pal = pill("▦ Grid", Color.WHITE) { openPalette() }
        pal.background = Ui.cardBg(this, 0x338B9CFF.toInt(), 14)
        nav.addView(pal, LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f).apply {
            setMargins(Ui.dp(this@ExamActivity, 8), 0, Ui.dp(this@ExamActivity, 8), 0)
        })
        val next = pill("Next ›", CYAN_DARK, CYAN_BG_FILLED) { if (idx < qs.size - 1) { idx++; showQ() } }
        nav.addView(next, LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f))
        root.addView(nav)

        setContentView(root)
        Fx.fadeSlide(root)
    }

    /** §10 palette — a compact grid of question cells behind the bottom Grid button. */
    private fun openPalette() {
        if (qs.isEmpty()) return
        squares.clear()
        val pad = Ui.dp(this, 10)
        val wrap = Ui.column(this)
        wrap.setBackgroundColor(NAVY_TOP)
        wrap.setPadding(pad, pad, pad, pad)
        val grid = Ui.column(this)
        var row: LinearLayout? = null
        for (i in qs.indices) {
            if (i % PALETTE_PER_ROW == 0) { row = Ui.row(this); grid.addView(row) }
            val sq = TextView(this)
            sq.text = (i + 1).toString()
            sq.textSize = 12f
            sq.gravity = Gravity.CENTER
            val side = Ui.dp(this, 3)
            val lp = LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34))
            lp.setMargins(side, side, side, side)
            row!!.addView(sq, lp)
            val j = i
            sq.setOnClickListener {
                jumpTo(j)
                paletteDlg?.dismiss()
            }
            squares.add(sq)
        }
        paintPalette()
        val sc = ScrollView(this)
        sc.addView(grid)
        val rows = (qs.size + PALETTE_PER_ROW - 1) / PALETTE_PER_ROW
        val h = (rows * Ui.dp(this, 40) + pad).coerceAtMost(Ui.dp(this, 360))
        wrap.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h))
        val a = answeredCount()
        val legend = Ui.text(this, "$a answered · ${qs.size - a} remaining · amber ring = marked · bright = current", 11f, SOFT)
        legend.setPadding(Ui.dp(this, 2), Ui.dp(this, 8), 0, 0)
        wrap.addView(legend)
        paletteDlg = AlertDialog.Builder(this)
            .setTitle("Questions · Q ${idx + 1} / ${qs.size}")
            .setView(wrap)
            .setNegativeButton("Close", null)
            .create()
        paletteDlg?.show()
    }

    private fun scopeLabel(): String {
        scopeTag?.let { return it }
        return if (scope == "ALL") "FULL SYLLABUS"
        else (Subjects.byKey(scope)?.name ?: scope).uppercase(Locale.US)
    }

    private fun showQ() {
        if (qs.isEmpty() || idx !in qs.indices) return
        val q = qs[idx]
        qBody.removeAllViews()
        options.clear()

        // v7: the Full mock is sectioned — a banner marks the top of each NEET
        // subject section (Physics → Chemistry → Botany → Zoology).
        if (isSectioned) {
            val here = sectionOf[idx]
            val prevSec = if (idx > 0) sectionOf[idx - 1] else -1
            if (here != prevSec) {
                val sname = (Subjects.byKey(q.subject)?.name ?: q.subject).uppercase(Locale.US)
                val banner = Ui.text(this, "SECTION · $sname", 12f, GOLD, true)
                banner.gravity = Gravity.CENTER
                banner.background = Ui.cardBg(this, CYAN_DARK, 12, 0x66FFC24B.toInt())
                banner.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8))
                qBody.addView(banner)
                qBody.addView(Ui.space(this, 8))
            }
        }

        // Paper questions carry no chapter — name the discipline instead.
        val tagText = if (isSectioned) {
            if (q.chapter.isBlank())
                (Subjects.byKey(q.subject)?.name ?: q.subject).uppercase(Locale.US)
            else q.chapter
        } else {
            "${Subjects.byKey(q.subject)?.name ?: q.subject} · ${q.chapter}"
        }
        val tag = Ui.text(this, tagText, 13f, CYAN, true)
        qBody.addView(tag)
        qBody.addView(Ui.space(this, 6))
        val body = Ui.text(this, q.text, 18f, Color.WHITE, true)
        body.setLineSpacing(Ui.dp(this, 4).toFloat(), 1f)
        body.setPadding(0, 0, 0, Ui.dp(this, 12))
        qBody.addView(body)

        if (::counterTv.isInitialized) counterTv.text = "Q ${idx + 1} / ${qs.size}"

        for ((i, opt) in q.options.withIndex()) {
            val card = buildOpt(i, opt)
            options.add(card)
            val m = Ui.margins(0, 0, 0, 0, this)
            m.setMargins(0, 0, 0, Ui.dp(this, 8))
            qBody.addView(card.card, m)
        }
        paintOptions()
        paintPalette()
        infoTv.text = statusLine()
        refreshMark()
        qScroll.post { qScroll.fullScroll(View.FOCUS_UP) }
        // v6.1: each question settles in with a quick fade
        qBody.alpha = 0f
        qBody.animate().alpha(1f).setDuration(150).start()
    }

    /** §10 option = a large badge card; the badge letter turns dark when selected. */
    private fun buildOpt(i: Int, text: String): OptCard {
        val card = Ui.row(this)
        card.background = Ui.cardBg(this, PANEL, 16, 0xFF8B9CFF.toInt())
        card.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10))
        val badge = Ui.text(this, ('A' + i).toString(), 15f, Color.WHITE, true)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.cardBg(this, 0x26FFFFFF.toInt(), 16)
        val bs = Ui.dp(this, 32)
        card.addView(badge, LinearLayout.LayoutParams(bs, bs))
        val body = Ui.text(this, text, 16f, Color.WHITE, true)
        body.setLineSpacing(0f, 1.08f)
        body.setPadding(Ui.dp(this, 12), 0, 0, 0)
        card.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.setOnClickListener { onPick(i) }
        Fx.press(card)
        return OptCard(card, badge, body)
    }

    private fun statusLine(): String {
        val mark = if (idx in marked.indices && marked[idx]) "  ·  marked for review" else ""
        return "${qs.size - answeredCount()} of ${qs.size} unanswered$mark"
    }

    private fun toggleMark() {
        if (qs.isEmpty() || idx !in qs.indices) return
        marked[idx] = !marked[idx]
        paintPalette()
        refreshMark()
        infoTv.text = statusLine()
    }

    private fun refreshMark() {
        markBtn?.let { b ->
            val isMarked = idx in marked.indices && marked[idx]
            b.text = if (isMarked) "✓ Marked" else "◈ Mark"
            b.setTextColor(if (isMarked) GOLD else SOFT)
        }
    }

    private fun answeredCount(): Int = picks.count { it >= 0 }

    private fun onPick(i: Int) {
        val selecting = picks[idx] != i
        picks[idx] = if (picks[idx] == i) -1 else i // tap again to clear
        paintOptions()
        paintPalette()
        infoTv.text = statusLine()
        if (selecting) Fx.pop(options[i].card, 1.04f)
    }

    private fun paintOptions() {
        for ((j, o) in options.withIndex()) {
            val selected = picks[idx] == j
            if (selected) {
                o.card.background = Ui.cardBg(this, CYAN_BG, 16, CYAN)
                o.badge.background = Ui.cardBg(this, CYAN, 16)
                o.badge.setTextColor(CYAN_DARK)
                o.body.setTextColor(CYAN_DARK)
            } else {
                o.card.background = Ui.cardBg(this, PANEL, 16, 0xFF8B9CFF.toInt())
                o.badge.background = Ui.cardBg(this, 0x26FFFFFF.toInt(), 16)
                o.badge.setTextColor(Color.WHITE)
                o.body.setTextColor(Color.WHITE)
            }
            val tf = if (selected) Typeface.BOLD else Typeface.NORMAL
            o.badge.setTypeface(null, tf)
            o.body.setTypeface(null, tf)
        }
    }

    private fun paintPalette() {
        for ((i, sq) in squares.withIndex()) {
            val answered = picks[i] >= 0
            val markedQ = i < marked.size && marked[i]
            sq.background = when {
                i == idx -> Ui.cardBg(this, CYAN, 15)
                answered && markedQ -> Ui.cardBg(this, CYAN_BG, 15, 0xFFFFC24B.toInt())
                answered -> Ui.cardBg(this, CYAN_BG, 15)
                markedQ -> Ui.cardBg(this, PANEL, 15, 0xFFFFC24B.toInt())
                else -> Ui.cardBg(this, PANEL, 15, 0xFF8B9CFF.toInt())
            }
            sq.setTextColor(if (i == idx) CYAN_DARK else Color.WHITE)
            sq.setTypeface(null, if (i == idx) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun jumpTo(i: Int) {
        if (i in qs.indices) {
            idx = i
            showQ()
        }
    }

    private fun quitTest() {
        if (submitted) { finish(); return }
        AlertDialog.Builder(this)
            .setTitle("Leave the test?")
            .setMessage("Your answers so far will be lost.")
            .setPositiveButton("Keep going", null)
            .setNegativeButton("Quit") { _, _ -> finish() }
            .show()
    }

    private fun confirmSubmit() {
        if (submitted) return
        val left = qs.size - answeredCount()
        if (left > 0) {
            AlertDialog.Builder(this)
                .setTitle("Submit test?")
                .setMessage("$left question${if (left == 1) "" else "s"} still unanswered — skipped ones score 0.")
                .setPositiveButton("Submit anyway") { _, _ -> doSubmit() }
                .setNegativeButton("Keep going", null)
                .show()
        } else {
            doSubmit()
        }
    }

    // ============================== scoring ==============================
    private fun tick() {
        if (mode != "test" || submitted) return
        val now = System.currentTimeMillis()
        val elapsed = ((now - lastTickMs) / 1000).toInt().coerceAtLeast(0)
        lastTickMs = now
        remainingSec = (remainingSec - elapsed).coerceAtLeast(0)
        if (::timerTv.isInitialized) timerTv.text = fmt(remainingSec)
        if (remainingSec <= 0) {
            doSubmit() // time's up — auto submit
            return
        }
        handler.postDelayed(ticker, 1000)
    }

    private fun doSubmit() {
        if (submitted) return
        submitted = true
        handler.removeCallbacks(ticker)

        var c = 0
        var w = 0
        for (i in qs.indices) {
            val p = picks[i]
            if (p < 0) continue
            val q = qs[i]
            val ok = p == q.answer
            if (ok) c++ else w++
            Store.addAttempt(this, q.id, q.subject, q.chapter, ok) // feeds accuracy + mistake book
        }
        resultCorrect = c
        resultWrong = w
        resultSkipped = qs.size - c - w
        resultScore = 4 * c - w
        resultUseSec = (assignedSec - remainingSec).coerceAtLeast(0)
        Store.recordMock(this, scope, qs.size, c, w, resultSkipped, resultScore)
        mode = "result"
        buildResult()
    }

    private fun buildResult() {
        val sv = ScrollView(this)
        sv.setBackgroundColor(NAVY_TOP)
        val col = Ui.column(this)
        val pad = Ui.dp(this, 20)
        col.setPadding(pad, Ui.dp(this, 22), pad, Ui.dp(this, 24))
        sv.addView(col)
        setContentView(sv)
        Fx.fadeSlide(sv)

        col.addView(Ui.text(this, "TEST COMPLETE", 13f, GOLD, true))
        col.addView(Ui.space(this, 4))
        col.addView(Ui.text(this, scopeLabel(), 14f, FAINT, true))
        col.addView(Ui.space(this, 16))

        // score hero — the score counts up to the real marks as it lands
        val hero = Ui.column(this)
        hero.background = Fx.gradient(0xFF1B2480.toInt(), 0xFF0E9FD8.toInt())
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18))
        val scoreTv = Ui.text(this, scoreText(0), 52f, Color.WHITE, true)
        scoreTv.gravity = Gravity.CENTER
        hero.addView(scoreTv)
        hero.addView(Ui.text(this, "marks (NEET scoring)", 13f, Color.WHITE).apply { gravity = Gravity.CENTER })
        hero.addView(Ui.space(this, 10))
        val acc = if (resultCorrect + resultWrong == 0) "—" else "${(resultCorrect * 100 / (resultCorrect + resultWrong))}%"
        hero.addView(Ui.text(this, "$acc accuracy  ·  ${fmt(resultUseSec)} used", 14f, Color.WHITE).apply { gravity = Gravity.CENTER })
        col.addView(hero, Ui.margins(0, 0, 0, 14, this))
        if (resultScore != 0) {
            val anim = ValueAnimator.ofInt(0, resultScore)
            anim.duration = 800
            anim.interpolator = DecelerateInterpolator(2f)
            anim.addUpdateListener { scoreTv.text = scoreText(anim.animatedValue as Int) }
            anim.start()
        }
        hero.alpha = 0f
        hero.scaleX = 0.93f
        hero.scaleY = 0.93f
        hero.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setInterpolator(OvershootInterpolator(1.4f)).setDuration(360).start()

        // counts
        statRow(col, "Correct", "${resultCorrect}", GREEN)
        statRow(col, "Wrong", "${resultWrong}", RED)
        statRow(col, "Skipped", "${resultSkipped}", SOFT)

        // per-subject split
        val split = LinkedHashMap<String, IntArray>() // name -> [answered, correct]
        for (i in qs.indices) {
            if (picks[i] < 0) continue
            val name = Subjects.byKey(qs[i].subject)?.name ?: qs[i].subject
            val a = split.getOrPut(name) { IntArray(2) }
            a[0]++; if (picks[i] == qs[i].answer) a[1]++
        }
        if (split.size > 1 || scope == "ALL") {
            col.addView(Ui.space(this, 6))
            col.addView(Ui.text(this, "Subject split", 15f, Color.WHITE, true))
            col.addView(Ui.space(this, 4))
            for ((name, a) in split) {
                val r = Ui.row(this)
                r.addView(Ui.text(this, name, 14f, SOFT))
                val v = Ui.text(this, "${a[1]}/${a[0]} correct", 14f, Color.WHITE, true)
                v.gravity = Gravity.END
                r.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = Ui.dp(this@ExamActivity, 12)
                })
                col.addView(r)
            }
        }

        val mocks = Store.mockHistory(this)
        if (mocks.isNotEmpty()) {
            col.addView(Ui.space(this, 6))
            col.addView(Ui.text(this, "Mocks taken: ${mocks.size}  ·  Best score: +${Store.bestMock(this)}", 13f, FAINT))
        }
        col.addView(Ui.space(this, 18))

        val msg = verdict()
        col.addView(Ui.text(this, msg, 14f, SOFT))
        col.addView(Ui.space(this, 14))

        if (resultWrong > 0) {
            val rev = Ui.button(this, "Review my mistakes", true)
            rev.setTextColor(Color.WHITE)
            rev.setOnClickListener {
                startActivity(Intent(this, ReviewActivity::class.java).putExtra("mode", "mistakes"))
            }
            Fx.press(rev)
            col.addView(rev, Ui.margins(0, 0, 0, 10, this))
        }
        val again = Ui.button(this, "Take another mock", false)
        again.setOnClickListener { mode = "start"; render() }
        Fx.press(again)
        col.addView(again, Ui.margins(0, 0, 0, 10, this))
        val done = Ui.button(this, "Done", false)
        done.setOnClickListener { finish() }
        Fx.press(done)
        col.addView(done)
    }

    private fun statRow(col: LinearLayout, label: String, value: String, color: Int) {
        val card = Ui.column(this)
        card.background = Ui.cardBg(this, PANEL, 16, 0xFF8B9CFF.toInt())
        card.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10))
        val r = Ui.row(this)
        r.addView(Ui.text(this, label, 15f, SOFT))
        val v = Ui.text(this, value, 18f, color, true)
        v.gravity = Gravity.END
        r.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(r)
        col.addView(card, Ui.margins(0, 0, 0, 8, this))
    }

    private fun verdict(): String {
        val answered = resultCorrect + resultWrong
        val acc = if (answered == 0) 0 else resultCorrect * 100 / answered
        val pctOfMax = if (qs.isEmpty()) 0 else resultScore * 100 / (4 * qs.size)
        return when {
            pctOfMax >= 60 -> "🔥 That's a serious score — keep this form up for the real NEET."
            acc >= 75 && resultWrong <= 3 -> "Almost there — a few silly misses cost you. Review them."
            acc >= 60 -> "Solid base. The mistakes you review now are marks you save in May."
            answered == 0 -> "You skipped everything — even a guess is worth a try next time."
            resultWrong == 0 -> "Perfect accuracy! Now speed and stamina."
            else -> "This is exactly why you practice. Review each wrong answer once, then take another."
        }
    }

    private fun pill(label: String, textColor: Int, bg: Int = 0, onClick: () -> Unit): TextView {
        val fill = if (bg == 0) PANEL else bg
        val tv = Ui.text(this, label, 14f, textColor, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8))
        tv.background = Ui.cardBg(this, fill, 14, if (fill == PANEL) 0xFF8B9CFF.toInt() else 0)
        tv.setOnClickListener { onClick() }
        Fx.press(tv)
        return tv
    }

    companion object {
        private const val SEC_PER_Q = 54
        private const val PER_SUBJECT = 45      // v7: full-mock attempt cap per subject (real NEET shape)
        private const val MIN_CHAPTER = 8       // v7: a chapter needs this many Qs before a drill card shows
        private const val PALETTE_PER_ROW = 8   // v8.21: §10 palette grid columns
        private const val CYAN_BG_FILLED = 0xFF22D3EE.toInt()
    }
}
