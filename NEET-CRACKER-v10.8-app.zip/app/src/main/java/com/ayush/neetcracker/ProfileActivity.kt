package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * v8.7 offline profile setup — the finish line of onboarding. There is no
 * account system and no internet in the app, so this just captures name,
 * NEET target year and the daily study-goal hours locally. Existing users who
 * pass onboarding are never shown this again (Store.onboarded).
 */
class ProfileActivity : Activity() {

    private val NAVY = 0xFF0B1233.toInt()
    private val SUB = 0xFF5A6480.toInt()
    private val VIOLET = 0xFF6C5CE7.toInt()

    private lateinit var nameBox: EditText
    private lateinit var yearBox: EditText
    private lateinit var hourBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        root.setPadding(Ui.dp(this, 24), Ui.dp(this, 34), Ui.dp(this, 24), Ui.dp(this, 24))
        setContentView(root)

        val kicker = Ui.text(this, "LAST STEP — YOUR PROFILE", 12f, VIOLET, true)
        kicker.setAllCaps(true)
        kicker.letterSpacing = 0.2f
        root.addView(kicker)

        val greeting = greetingLine()
        val gt = Ui.text(this, greeting, 26f, NAVY, true)
        gt.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        val glp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        glp.topMargin = Ui.dp(this, 8)
        root.addView(gt, glp)

        val sub = Ui.text(this, "Set this once and every screen adapts to you. All offline.", 14f, SUB)
        val slp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        slp.topMargin = Ui.dp(this, 6)
        root.addView(sub, slp)

        root.addView(Ui.space(this, 28))

        nameBox = field(root, "YOUR NAME", "Ayush", false)
        root.addView(Ui.space(this, 14))
        yearBox = field(root, "NEET TARGET YEAR", "2027", true)
        root.addView(Ui.space(this, 14))
        hourBox = field(root, "DAILY STUDY GOAL (HOURS)", "8", true)

        root.addView(Ui.space(this, 26))

        val go = Ui.text(this, "START STUDYING", 16f, Color.WHITE, true)
        go.setAllCaps(true)
        go.letterSpacing = 0.14f
        go.gravity = Gravity.CENTER
        go.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16))
        go.background = roundGradient(Ui.dp(this, 16), 0xFF6C5CE7.toInt(), 0xFF3B2F8F.toInt())
        Ui.clickable(this, go)
        Fx.press(go)
        go.setOnClickListener { save() }
        root.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val note = Ui.text(this, "You can change all of this later in Settings.", 12f, SUB)
        note.gravity = Gravity.CENTER
        val nlp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        nlp.topMargin = Ui.dp(this, 14)
        root.addView(note, nlp)
    }

    private fun greetingLine(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val n = Store.name(this)
        return when {
            h < 12 -> "Good morning, $n."
            h < 17 -> "Good afternoon, $n."
            else -> "Good evening, $n."
        }
    }

    private fun field(container: LinearLayout, label: String, value: String, numeric: Boolean): EditText {
        val card = Ui.column(this)
        card.background = Ui.cardBg(this, Color.WHITE, 16)
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 10), Ui.dp(this, 18), Ui.dp(this, 10))

        val lab = Ui.text(this, label, 11f, SUB, true)
        lab.setAllCaps(true)
        lab.letterSpacing = 0.14f
        card.addView(lab)

        val et = EditText(this)
        et.setText(value)
        et.setTextSize(20f)
        et.setTextColor(Theme.ink(this, NAVY))
        et.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        et.setSingleLine(true)
        et.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4))
        et.setBackgroundColor(Color.TRANSPARENT)
        if (numeric) et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setSelectAllOnFocus(true)
        card.addView(et)

        container.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return et
    }

    private fun roundGradient(r: Int, a: Int, b: Int): GradientDrawable {
        val g = GradientDrawable()
        g.orientation = GradientDrawable.Orientation.TL_BR
        g.cornerRadius = r.toFloat()
        g.colors = intArrayOf(a, b)
        return g
    }

    private fun save() {
        val n = nameBox.text.toString().trim().ifEmpty { "Ayush" }
        val yRaw = yearBox.text.toString().trim()
        val hRaw = hourBox.text.toString().trim()

        var year = 2027
        if (yRaw.isNotEmpty()) {
            val y = yRaw.toIntOrNull()
            if (y == null || y !in 2025..2036) {
                Ui.toast(this, "Enter a valid NEET year (e.g. 2027)")
                return
            }
            year = y
        }
        val hours = hRaw.toIntOrNull()?.coerceIn(1, 16) ?: 8

        Store.setName(this, n)
        Store.setExamDate(this, "$year-05-02")
        val g = Store.goals(this)
        Store.setGoals(this, hours, g.q, g.r, g.ch, g.lec)
        Store.setOnboarded(this)

        Ui.toast(this, "Welcome, $n — let's crack NEET 💪")
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
