package com.ayush.neetcracker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Small helpers for building the UI in code (no XML layouts). */
object Ui {

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    fun color(c: Context, resId: Int): Int = Theme.color(c, resId)

    fun toast(c: Context, msg: String) =
        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show()

    fun column(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun row(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    fun text(c: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(c)
        tv.text = s
        tv.setTextSize(sp * Theme.textScaleOf(c)) // v10.8: one dial resizes every label
        tv.setTextColor(Theme.ink(c, color)) // dark mode brightens dark accent ink
        tv.setTypeface(null, if (bold) Typeface.BOLD else Typeface.NORMAL)
        return tv
    }

    fun heading(c: Context, s: String): TextView = text(c, s, 20f, color(c, R.color.text_main), true)

    fun subHeading(c: Context, s: String): TextView = text(c, s, 14f, color(c, R.color.text_sub))

    fun space(c: Context, dpV: Int): View {
        val v = View(c)
        v.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(c, dpV))
        return v
    }

    /** Rounded filled card background. Fill maps to its dark surface in dark mode. */
    fun cardBg(c: Context, fill: Int = Color.WHITE, radiusDp: Int = 14, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(Theme.surface(c, fill))
        // v10.8: the shape dial, but only on real cards — a radius of 20 or more is a
        // pill or a dot, and squaring those off would stop them reading as circles.
        val r = if (radiusDp <= 16) (radiusDp * Theme.radiusScaleOf(c)).toInt() else radiusDp
        g.cornerRadius = dp(c, r).toFloat()
        if (strokeColor != 0) g.setStroke(dp(c, 1), strokeColor)
        return g
    }

    /**
     * Appends a labelled progress row into [container].
     * @param label short text (e.g. "Physics"), [fraction] 0..1.
     */
    fun addProgressRow(container: LinearLayout, c: Context, label: String, fraction: Float) {
        val top = row(c)
        top.addView(text(c, label, 14f, color(c, R.color.text_main), true))
        val pct = text(c, "${(fraction.coerceIn(0f, 1f) * 100).toInt()}%", 14f, color(c, R.color.primary), true)
        pct.gravity = Gravity.END
        top.addView(pct, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        container.addView(top)
        container.addView(space(c, 3))

        val track = LinearLayout(c)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f // so a single weighted fill renders at [fraction], not full width
        track.background = cardBg(c, 0xFFE4EBE7.toInt(), 6)
        val fill = View(c)
        fill.background = cardBg(c, color(c, R.color.primary), 6)
        track.addView(fill, LinearLayout.LayoutParams(0, dp(c, 10), fraction.coerceIn(0f, 1f)))
        container.addView(track, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(c, 10)))
        // v6.1: the bar grows left-to-right instead of popping in fully formed
        fill.pivotX = 0f
        fill.scaleX = 0f
        fill.animate().scaleX(1f).setInterpolator(DecelerateInterpolator(1.4f))
            .setDuration(550).setStartDelay(80).start()
    }

    /** Wraps a view in a white rounded card (padding included). */
    fun wrapCard(c: Context, child: View): LinearLayout {
        val card = column(c)
        card.background = cardBg(c)
        val lp = margins(0, 0, 0, 0, c)
        card.addView(child)
        // add padding via padding on a wrapper
        card.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        card.layoutParams = lp
        return card
    }

    /** Adds clickable ripple background. */
    fun clickable(c: Context, v: View) {
        val outValue = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
        v.setBackgroundResource(outValue.resourceId)
    }

    fun margins(dpL: Int, dpT: Int, dpR: Int, dpB: Int, c: Context): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            val d = c.resources.displayMetrics.density
            setMargins((dpL * d).toInt(), (dpT * d).toInt(), (dpR * d).toInt(), (dpB * d).toInt())
        }

    /** Standard primary action button. */
    fun button(c: Context, label: String, filled: Boolean = true): TextView {
        val tv = text(c, label, 16f, if (filled) Color.WHITE else color(c, R.color.primary), true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(c, 14), dp(c, 13), dp(c, 14), dp(c, 13))
        tv.letterSpacing = 0.02f
        tv.background = buttonBg(c, filled)
        return tv
    }

    /**
     * v9.1 button graphics: filled = a soft emerald top→bottom gradient with a
     * light 1dp inner highlight ring; outline = a 1.5dp brand ring on a
     * transparent fill. One shared look across the whole app.
     */
    fun buttonBg(c: Context, filled: Boolean): GradientDrawable {
        return if (filled) {
            val base = color(c, R.color.primary)
            val g = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(lighten(base, 1.12f), shade(base, 0.82f))
            )
            g.shape = GradientDrawable.RECTANGLE
            g.cornerRadius = dp(c, 12).toFloat()
            g.setStroke(dp(c, 1), lighten(base, 1.35f)) // subtle top-lit edge
            g
        } else {
            cardBg(c, Color.TRANSPARENT, 12, color(c, R.color.primary)).apply {
                setStroke(dp(c, 2), color(c, R.color.primary))
            }
        }
    }

    /** Scales an ARGB colour's RGB toward black. */
    private fun shade(argb: Int, f: Float): Int = Color.argb(
        Color.alpha(argb),
        (Color.red(argb) * f).toInt().coerceIn(0, 255),
        (Color.green(argb) * f).toInt().coerceIn(0, 255),
        (Color.blue(argb) * f).toInt().coerceIn(0, 255)
    )

    /** Blends an ARGB colour's RGB toward white. */
    private fun lighten(argb: Int, f: Float): Int = Color.argb(
        Color.alpha(argb),
        (Color.red(argb) * f).toInt().coerceIn(0, 255),
        (Color.green(argb) * f).toInt().coerceIn(0, 255),
        (Color.blue(argb) * f).toInt().coerceIn(0, 255)
    )
}
