package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * §11 Past Year Papers hub — a dedicated home for real NEET papers.
 *
 * Two ways in:
 *  - YEAR-WISE: each paper card runs the whole paper in official order through
 *    the exam engine (ExamActivity "paperYear" extra) — timed, +4/−1, paletted.
 *  - CHAPTER-WISE: the past-year questions that were folded into the subject
 *    banks, grouped by chapter, drilled through the normal quiz engine.
 *
 * Pure UI over data that already exists — no new storage, no engine change.
 */
class PyqActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        // top row: back · title
        val h = Ui.row(this)
        h.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 10), 0)
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        Fx.press(back)
        h.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        val title = Ui.text(this, "Past Year Papers", 20f, Ui.color(this, R.color.text_main), true)
        title.gravity = Gravity.CENTER
        h.addView(title, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f))
        h.addView(android.view.View(this), LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        root.addView(h)

        val sc = ScrollView(this)
        val col = Ui.column(this)
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 24))
        sc.addView(col)
        root.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(
            Ui.text(
                this,
                "Real NEET papers to attempt in exam order, plus past questions grouped by chapter for quick revision.",
                13f, Ui.color(this, R.color.text_sub)
            )
        )
        col.addView(Ui.space(this, 14))

        // ---------------- year-wise ----------------
        val papers = Store.PAPERS.filter { Store.paperQuestions(this, it).isNotEmpty() }
        if (papers.isNotEmpty()) {
            col.addView(sectionLabel("FULL PAPERS · YEAR-WISE"))
            for (p in papers) paperCard(col, p)
            col.addView(Ui.space(this, 8))
        }

        // ---------------- chapter-wise ----------------
        val byChapter = chapterWise()
        if (byChapter.isNotEmpty()) {
            col.addView(sectionLabel("CHAPTER-WISE · PAST QUESTIONS"))
            col.addView(
                Ui.text(
                    this,
                    "Past-year questions already sitting in your chapter banks — drill one chapter at a time.",
                    13f, Ui.color(this, R.color.text_sub)
                )
            )
            col.addView(Ui.space(this, 10))
            for ((subjKey, chapter, ids) in byChapter) chapterRow(col, subjKey, chapter, ids)
        }

        setContentView(root)
    }

    private fun sectionLabel(s: String): TextView =
        Ui.text(this, s, 12.5f, Ui.color(this, R.color.primary), true).apply {
            setTypeface(null, Typeface.BOLD)
            letterSpacing = 0.06f
            setPadding(0, Ui.dp(this@PyqActivity, 6), 0, Ui.dp(this@PyqActivity, 8))
        }

    private fun paperCard(col: LinearLayout, p: Store.Paper) {
        val pq = Store.paperQuestions(this, p)
        val card = Ui.column(this)
        card.background = Ui.cardBg(this, 0xFFFFFFFF.toInt(), 16, Ui.color(this, R.color.primary))
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14))

        val top = Ui.row(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val year = Ui.text(this, "${p.year}", 30f, Ui.color(this, R.color.primary), true)
        year.setTypeface(null, Typeface.BOLD)
        top.addView(year)

        val lbl = Ui.column(this)
        lbl.setPadding(Ui.dp(this, 12), 0, 0, 0)
        lbl.addView(Ui.text(this, p.label, 16f, Ui.color(this, R.color.text_main), true))
        lbl.addView(Ui.text(this, "${pq.size} questions · ${timeLabel(pq.size)} · real paper order", 12.5f, Ui.color(this, R.color.text_sub)))
        top.addView(lbl, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(top)

        card.addView(Ui.space(this, 10))
        val parts = Subjects.ALL.mapNotNull { s ->
            val n = pq.count { it.subject == s.key }
            if (n > 0) "${s.name} $n" else null
        }
        card.addView(Ui.text(this, parts.joinToString("   ·   "), 13f, Ui.color(this, R.color.text_sub)))
        card.addView(Ui.space(this, 12))

        val start = Ui.button(this, "Start paper", true)
        start.gravity = Gravity.CENTER
        start.setOnClickListener {
            startActivity(Intent(this, ExamActivity::class.java).putExtra("paperYear", p.year))
        }
        card.addView(start)

        col.addView(card, Ui.margins(0, 0, 0, 12, this))
    }

    private fun chapterRow(col: LinearLayout, subjKey: String, chapter: String, ids: List<String>) {
        val subj = Subjects.byKey(subjKey)
        val row = Ui.row(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.cardBg(this, Ui.color(this, R.color.card), 14)
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10))

        val chip = Ui.text(this, subj?.name?.firstOrNull()?.toString() ?: "•", 14f, 0xFFFFFFFF.toInt(), true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 15)
        row.addView(chip, LinearLayout.LayoutParams(Ui.dp(this, 30), Ui.dp(this, 30)))

        val mid = Ui.column(this)
        mid.setPadding(Ui.dp(this, 12), 0, 0, 0)
        mid.addView(Ui.text(this, chapter, 14.5f, Ui.color(this, R.color.text_main), true))
        mid.addView(
            Ui.text(
                this,
                "${ids.size} past question${if (ids.size == 1) "" else "s"} · ${subj?.name ?: subjKey}",
                12f, Ui.color(this, R.color.text_sub)
            )
        )
        row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val drill = Ui.button(this, "Drill", false)
        drill.gravity = Gravity.CENTER
        drill.setOnClickListener {
            startActivity(
                Intent(this, QuizActivity::class.java)
                    .putExtra("ids", ids.joinToString(","))
                    .putExtra("subject", subjKey)
            )
        }
        row.addView(drill, LinearLayout.LayoutParams(Ui.dp(this, 86), Ui.dp(this, 44)))

        col.addView(row, Ui.margins(0, 0, 0, 10, this))
    }

    /** Past-year questions folded into the banks (ids N23_/N24_/N25_), grouped by chapter. */
    private fun chapterWise(): List<Triple<String, String, List<String>>> {
        val bank = Store.questionBank(this)
        val map = LinkedHashMap<Pair<String, String>, MutableList<String>>()
        for (q in bank) {
            val pyq = q.id.startsWith("N23_") || q.id.startsWith("N24_") || q.id.startsWith("N25_")
            if (!pyq || q.chapter.isBlank()) continue
            map.getOrPut(q.subject to q.chapter) { ArrayList() }.add(q.id)
        }
        val order = Subjects.ALL.map { it.key }
        return map.entries
            .sortedWith(compareBy({ order.indexOf(it.key.first) }, { it.key.second }))
            .map { Triple(it.key.first, it.key.second, it.value) }
    }

    /** NEET allots 54 seconds per question; show the paper's total time. */
    private fun timeLabel(n: Int): String {
        val sec = n * 54
        val hh = sec / 3600
        val mm = (sec % 3600) / 60
        return if (hh > 0) "${hh}h ${mm}m" else "${mm}m"
    }
}
