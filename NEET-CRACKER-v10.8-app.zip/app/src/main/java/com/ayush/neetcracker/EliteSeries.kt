package com.ayush.neetcracker

import android.content.Context
import org.json.JSONArray

/**
 * v8.2 — Ayush's ELITE 28-Test Series (NEET-2027), his own Sunday test
 * calendar, shipped as an asset. Every Sunday one test: Part Tests 1-18
 * (per-subject chapter syllabus for the week), Cumulative tests 4/8/12/16
 * (which repeat the syllabus of the parts before them), Mocks 19-28 (full
 * NEET syllabus). The first three sat on 23-Aug, 6-Sep, 20-Sep — so the next
 * test after today (9-Sep) is Part Test 3 on 20-Sep.
 *
 * The chapter lists use NCERT topic names. The app tracks "done" per its own
 * chapter taxonomy (Subjects.kt), and Momentum sometimes files a bio topic
 * under a different bucket (Biological Classification / Biomolecules / Ecology
 * live in Botany here but the series lists them under Zoology, etc.), so prep
 * status is resolved by chapter NAME across buckets, not by position.
 */
object EliteSeries {

    /** Each test as parsed from elite_series.json. */
    data class Item(
        val n: Int,                 // test number in the series
        val date: String,           // yyyy-MM-dd (a Sunday)
        val kind: String,           // "Part Test" | "Cumulative test" | "Mock test"
        val full: Boolean,          // mock = whole NEET syllabus
        val covers: List<Int>,      // cumulative = the part tests it repeats
        val phy: List<String>, val chem: List<String>,
        val bot: List<String>, val zoo: List<String>
    ) {
        fun chapters(slot: String): List<String> = when (slot) {
            "PHY" -> phy
            "CHEM" -> chem
            "BOT" -> bot
            else -> zoo
        }
    }

    /** One chapter of a test's syllabus with its real prep state. */
    data class Prep(val name: String, val done: Boolean, val tracked: Boolean)

    /** A test's syllabus grouped by subject, with progress counts. */
    data class SlotPrep(val slot: String, val preps: List<Prep>, val done: Int, val total: Int)

    private var cached: List<Item>? = null

    fun rows(c: Context): List<Item> {
        cached?.let { return it }
        val out = ArrayList<Item>()
        try {
            val text = c.assets.open("elite_series.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                fun list(key: String): List<String> {
                    val a = o.optJSONArray(key) ?: return emptyList()
                    return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
                }
                val covers = ArrayList<Int>()
                val ca = o.optJSONArray("covers")
                if (ca != null) for (j in 0 until ca.length()) covers.add(ca.optInt(j))
                out.add(
                    Item(
                        o.optInt("n", 0),
                        o.optString("date", ""),
                        o.optString("kind", ""),
                        o.optBoolean("full", false),
                        covers,
                        list("phy"), list("chem"), list("bot"), list("zoo")
                    )
                )
            }
            out.sortBy { it.date }
        } catch (e: Exception) {
            // asset missing or malformed -> series surfaces simply don't render
        }
        cached = out
        return out
    }

    fun has(c: Context): Boolean = rows(c).isNotEmpty()

    /** The next test at/after today, or null when the series has finished. */
    fun next(c: Context): Item? =
        rows(c).filter { it.date >= Store.todayKey() }.minByOrNull { it.date }

    fun label(t: Item): String = when {
        t.kind.startsWith("Part") -> "Part Test ${t.n}"
        t.kind.startsWith("Cum") -> "Cumulative ${t.n}"
        else -> "Mock ${t.n}"
    }

    /** The sub-label under a test's name (what it actually covers). */
    fun sub(t: Item): String = when {
        t.full -> "full NEET syllabus"
        t.covers.isNotEmpty() ->
            "covers " + t.covers.sorted().joinToString(", ") { "Part ${it}" }
        else -> "syllabus below"
    }

    /** Tests at/after today, chronological (for the coming-up list). */
    fun upcoming(c: Context): List<Item> = rows(c).filter { it.date >= Store.todayKey() }

    /**
     * The syllabus of a test mapped to the app's chapters with prep state:
     * a mock expands to the whole app syllabus (all 4 subjects, by done-count);
     * a cumulative test expands to the union of the part tests it covers;
     * a part test uses its own per-subject chapter lists. Unlisted slots are
     * dropped so the UI only shows what the test actually asks.
     */
    fun prepFor(c: Context, t: Item): List<SlotPrep> {
        val out = ArrayList<SlotPrep>()
        if (t.full) {
            for (s in Subjects.ALL) {
                val done = Store.doneCount(c, s.key)
                out.add(SlotPrep(s.key, emptyList(), done, s.chapters.size))
            }
            return out
        }
        for (slot in MomentumPlan.SLOTS) {
            val names: List<String> = if (t.covers.isNotEmpty()) {
                val byN = rows(c).associateBy { it.n }
                t.covers.filter { byN.containsKey(it) }
                    .flatMap { byN[it]!!.chapters(slot) }
                    .distinct()
            } else t.chapters(slot)
            if (names.isEmpty()) continue
            val preps = names.map { name ->
                val loc = resolveChapter(slot, name)
                if (loc == null) Prep(name, done = false, tracked = false)
                else Prep(name, done = Store.isDone(c, loc.first, loc.second), tracked = true)
            }
            out.add(SlotPrep(slot, preps, preps.count { it.done && it.tracked }, preps.count { it.tracked }))
        }
        return out
    }

    /** Normalize a chapter title for comparison (case/spacing/&). */
    private fun norm(s: String): String =
        s.lowercase().replace("&", "and").replace(Regex("[^a-z0-9 ]"), " ")
            .trim().replace(Regex("\\s+"), " ")

    /**
     * Resolve a series chapter name to (subjectKey, chapterIndex) in the app's
     * taxonomy. Tries the exact title inside the listed subject first, then —
     * because the series buckets some Class-11/12 bio topics differently than
     * the app (Ecology & Microbes under Botany here, Biomolecules & Evolution
     * under Zoology there, etc.) — the exact title inside the other biology
     * subject. Unmatched names stay untracked rather than guessing.
     */
    private fun resolveChapter(slot: String, name: String): Pair<String, Int>? {
        val n = norm(name)
        fun find(key: String): Pair<String, Int>? {
            val s = Subjects.byKey(key) ?: return null
            val i = s.chapters.indexOfFirst { norm(it) == n }
            return if (i >= 0) key to i else null
        }
        find(slot)?.let { return it }
        if (slot == "BOT" || slot == "ZOO") {
            find(if (slot == "BOT") "ZOO" else "BOT")?.let { return it }
        }
        return null
    }
}
