package com.ayush.neetcracker

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class PlannerActivity : Activity() {

    private var filter = "Pending"
    private var selectedSubjectKey = Subjects.ALL[0].key
    private var selectedChapter = Subjects.ALL[0].chapters[0]
    private var selectedPriority = Store.P_MED
    private var selectedDate = Store.todayKey()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        // header
        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(this, "Study Planner", 20f, Ui.color(this, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@PlannerActivity, 6)
        })
        root.addView(header)

        // v9.4: today's plan at a glance
        val allTasks = Store.getTasks(this)
        val todayList = allTasks.filter { it.date == Store.todayKey() }
        val doneToday = todayList.count { it.done }
        val overdue = allTasks.count { !it.done && it.date < Store.todayKey() }
        val pendingAll = allTasks.count { !it.done }

        val statWrap = Ui.column(this)
        statWrap.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), 0)
        val statCard = Ui.column(this)
        statCard.background = Ui.cardBg(this)
        statCard.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14))

        val stTop = Ui.row(this)
        stTop.gravity = Gravity.CENTER_VERTICAL
        stTop.addView(Ui.text(this, "Today's plan", 15f, Ui.color(this, R.color.text_main), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        stTop.addView(
            Ui.text(this, "$doneToday of ${todayList.size} done", 13.5f, Ui.color(this, R.color.primary), true),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        statCard.addView(stTop)
        statCard.addView(Ui.space(this, 8))

        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 6)
        val frac = if (todayList.isEmpty()) 0f else doneToday.toFloat() / todayList.size
        val fill = View(this)
        fill.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 6)
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(this, 10), frac))
        statCard.addView(track, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 10)))

        val stMeta = mutableListOf("$pendingAll pending")
        if (overdue > 0) stMeta.add("$overdue overdue")
        statCard.addView(Ui.text(this, stMeta.joinToString("  ·  "), 12.5f, Ui.color(this, R.color.text_sub)).apply {
            setPadding(0, Ui.dp(this@PlannerActivity, 8), 0, 0)
        })
        statWrap.addView(statCard)
        root.addView(statWrap)

        // add + filter row
        val controls = Ui.row(this)
        controls.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), 0)
        val filters = Ui.row(this)
        for (f in arrayOf("Pending", "Today", "Completed")) {
            val chip = chip(f == filter, f)
            chip.setOnClickListener { filter = f; render() }
            filters.addView(chip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val spacing = View(this)
            filters.addView(spacing, LinearLayout.LayoutParams(Ui.dp(this, 8), 1))
        }
        controls.addView(filters, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val add = Ui.button(this, "＋ Task", true)
        add.setOnClickListener { showAddEdit(null) }
        controls.addView(add)
        root.addView(controls)

        // list
        val sv = ScrollView(this)
        val list = Ui.column(this)
        val pad = Ui.dp(this, 16)
        list.setPadding(pad, Ui.dp(this, 6), pad, Ui.dp(this, 24))
        sv.addView(list, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val all = allTasks
        var tasks = when (filter) {
            "Pending" -> all.filter { !it.done }
            "Today" -> all.filter { it.date == Store.todayKey() }
            else -> all.filter { it.done }
        }
        tasks = tasks.sortedWith(compareBy({ it.done }, { it.date }))

        if (tasks.isEmpty()) {
            list.addView(Ui.text(this, "No ${filter.lowercase()} tasks yet.", 15f, Ui.color(this, R.color.text_sub)).apply {
                setPadding(Ui.dp(this@PlannerActivity, 8), Ui.dp(this@PlannerActivity, 30), 0, 0)
            })
            list.addView(Ui.text(this, "Tap ＋ Task to plan your first one.", 13f, Ui.color(this, R.color.text_sub)).apply {
                setPadding(Ui.dp(this@PlannerActivity, 8), Ui.dp(this@PlannerActivity, 6), 0, 0)
            })
        } else {
            // v9.4: group headers carry a live count
            val groups = tasks.map { t ->
                if (t.date == Store.todayKey()) "Today"
                else if (t.date == Store.dateForOffset(1)) "Tomorrow"
                else Store.humanDate(t.date)
            }
            var lastGroup: String? = null
            for ((i, t) in tasks.withIndex()) {
                val group = groups[i]
                if (group != lastGroup) {
                    lastGroup = group
                    val n = groups.count { it == group }
                    val gh = Ui.row(this)
                    gh.gravity = Gravity.CENTER_VERTICAL
                    gh.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 2))
                    gh.addView(Ui.text(this, group, 15f, Ui.color(this, R.color.primary), true),
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    gh.addView(Ui.text(this, "$n", 12.5f, Ui.color(this, R.color.text_sub), true))
                    list.addView(gh)
                }
                list.addView(taskRow(t))
                list.addView(Ui.space(this, 8))
            }
        }

        setContentView(root)
    }

    private fun taskRow(t: Store.Task): LinearLayout {
        val row = Ui.row(this)
        row.background = Ui.cardBg(this)
        row.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10))
        row.gravity = Gravity.CENTER_VERTICAL

        // v9.4: priority accent bar
        val bar = View(this)
        bar.background = Ui.cardBg(this, prioColor(t.priority), 2)
        row.addView(bar, LinearLayout.LayoutParams(Ui.dp(this, 4), Ui.dp(this, 42)))

        // check circle
        val check = Ui.text(
            this, if (t.done) "✓" else "○", 20f,
            if (t.done) Ui.color(this, R.color.primary) else Ui.color(this, R.color.text_sub), true
        )
        check.gravity = Gravity.CENTER
        check.setOnClickListener { Store.setTaskDone(this, t.id, !t.done); render() }
        row.addView(check, LinearLayout.LayoutParams(Ui.dp(this, 34), LinearLayout.LayoutParams.WRAP_CONTENT))

        val info = Ui.column(this)
        val title = Ui.text(this, t.title, 15f, Ui.color(this, R.color.text_main), true)
        if (t.done) title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        info.addView(title)
        val meta = Subjects.byKey(t.subjectKey)?.name + (if (t.chapter.isEmpty()) "" else " · " + t.chapter)
        info.addView(Ui.text(this, meta, 12f, Ui.color(this, R.color.text_sub)))
        val extra = mutableListOf<String>()
        extra.add(t.priority)
        if (t.durMin > 0) extra.add("${t.durMin} min")
        if (t.notes.isNotEmpty()) extra.add(t.notes)
        if (!t.done && t.date < Store.todayKey()) info.addView(
            Ui.text(this, "Overdue · ${Store.humanDate(t.date)}", 12f, 0xFFE0524D.toInt(), true)
        )
        row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@PlannerActivity, 10)
        })

        row.setOnClickListener {
            val opts = arrayOf(if (t.done) "Mark as pending" else "Mark as done", "Edit", "Delete")
            AlertDialog.Builder(this)
                .setTitle(t.title)
                .setItems(opts) { _, which ->
                    when (which) {
                        0 -> { Store.setTaskDone(this, t.id, !t.done); render() }
                        1 -> showAddEdit(t)
                        2 -> AlertDialog.Builder(this)
                            .setTitle("Delete task?")
                            .setPositiveButton("Delete") { _, _ -> Store.deleteTask(this, t.id); render() }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
                .show()
        }
        Ui.clickable(this, row)
        return row
    }

    /** v9.4: priority → accent colour (dark-safe: red/amber use literals, Low falls back to primary). */
    private fun prioColor(p: String): Int = when (p) {
        Store.P_HIGH -> 0xFFE0524D.toInt()
        Store.P_MED -> 0xFFB26A00.toInt()
        else -> Ui.color(this, R.color.primary)
    }

    private fun chip(active: Boolean, label: String): TextView {
        val tv = Ui.text(
            this, label, 13f,
            if (active) android.graphics.Color.WHITE else Ui.color(this, R.color.text_main), true
        )
        tv.gravity = Gravity.CENTER
        tv.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 8))
        tv.background = Ui.cardBg(
            this,
            if (active) Ui.color(this, R.color.primary) else 0xFFEAF1EC.toInt(), 10
        )
        return tv
    }

    private fun showAddEdit(existing: Store.Task?) {
        val c = this
        selectedSubjectKey = existing?.subjectKey ?: selectedSubjectKey
        selectedChapter = existing?.chapter ?: selectedChapter
        selectedPriority = existing?.priority ?: Store.P_MED
        selectedDate = existing?.date ?: selectedDate

        val col = Ui.column(c)
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 10), Ui.dp(c, 24), 0)

        val title = EditText(c)
        title.hint = "Task title (e.g. Revise Gravitation)"
        title.setText(existing?.title ?: "")
        col.addView(title, Ui.margins(0, 0, 0, 8, c))

        val notes = EditText(c)
        notes.hint = "Notes (optional)"
        notes.setText(existing?.notes ?: "")
        col.addView(notes, Ui.margins(0, 0, 0, 8, c))

        val dur = EditText(c)
        dur.hint = "Duration in minutes (optional)"
        dur.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        dur.setText(if (existing != null && existing.durMin > 0) "${existing.durMin}" else "")
        col.addView(dur, Ui.margins(0, 0, 0, 4, c))

        fun pickerRow(initial: String, onClick: () -> Unit): TextView {
            val tv = Ui.text(c, initial, 15f, Ui.color(c, R.color.text_main), true)
            tv.setPadding(Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12))
            tv.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
            tv.setOnClickListener { onClick() }
            Ui.clickable(c, tv)
            col.addView(tv, Ui.margins(0, 0, 0, 8, c))
            return tv
        }

        lateinit var subjPicker: TextView
        lateinit var chPicker: TextView
        lateinit var prioPicker: TextView
        lateinit var datePicker: TextView

        fun renderPickerTexts() {
            subjPicker.text = "Subject: " + (Subjects.byKey(selectedSubjectKey)?.name ?: "")
            chPicker.text = "Chapter: $selectedChapter"
            prioPicker.text = "Priority: $selectedPriority"
            datePicker.text = "Date: ${Store.humanDate(selectedDate)}"
        }

        subjPicker = pickerRow("Subject: " + (Subjects.byKey(selectedSubjectKey)?.name ?: "")) {
            AlertDialog.Builder(c)
                .setTitle("Subject")
                .setItems(Subjects.ALL.map { it.name }.toTypedArray()) { _, i ->
                    selectedSubjectKey = Subjects.ALL[i].key
                    selectedChapter = Subjects.ALL[i].chapters[0]
                    renderPickerTexts()
                }.show()
        }
        chPicker = pickerRow("Chapter: $selectedChapter") {
            val sub = Subjects.byKey(selectedSubjectKey) ?: Subjects.ALL[0]
            AlertDialog.Builder(c)
                .setTitle("Chapter")
                .setItems(sub.chapters.toTypedArray()) { _, i ->
                    selectedChapter = sub.chapters[i]
                    renderPickerTexts()
                }.show()
        }
        prioPicker = pickerRow("Priority: $selectedPriority") {
            AlertDialog.Builder(c)
                .setTitle("Priority")
                .setItems(arrayOf(Store.P_HIGH, Store.P_MED, Store.P_LOW)) { _, i ->
                    selectedPriority = arrayOf(Store.P_HIGH, Store.P_MED, Store.P_LOW)[i]
                    renderPickerTexts()
                }.show()
        }
        datePicker = pickerRow("Date: ${Store.humanDate(selectedDate)}") {
            val parts = selectedDate.split("-")
            DatePickerDialog(
                c, { _, y, m, d ->
                    val cal = Calendar.getInstance()
                    cal.set(y, m, d)
                    selectedDate = Store.fmt(cal.time)
                    renderPickerTexts()
                },
                parts.getOrNull(0)?.toIntOrNull() ?: 2026,
                (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1,
                parts.getOrNull(2)?.toIntOrNull() ?: 1
            ).show()
        }

        val sc = ScrollView(c)
        sc.addView(col)
        AlertDialog.Builder(c)
            .setTitle(if (existing == null) "Add task" else "Edit task")
            .setView(sc)
            .setPositiveButton("Save") { _, _ ->
                val t = title.text.toString().trim()
                if (t.isEmpty()) { Ui.toast(c, "Give the task a title"); return@setPositiveButton }
                val minutes = dur.text.toString().toIntOrNull() ?: 0
                if (existing == null) {
                    Store.addTask(
                        c, Store.Task(0, t, selectedSubjectKey, selectedChapter, selectedDate,
                            selectedPriority, minutes, notes.text.toString().trim(), false)
                    )
                    Ui.toast(c, "Task added ✓")
                } else {
                    Store.updateTask(
                        c, existing.copy(title = t, subjectKey = selectedSubjectKey, chapter = selectedChapter,
                            date = selectedDate, priority = selectedPriority, durMin = minutes,
                            notes = notes.text.toString().trim())
                    )
                    Ui.toast(c, "Task updated ✓")
                }
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
