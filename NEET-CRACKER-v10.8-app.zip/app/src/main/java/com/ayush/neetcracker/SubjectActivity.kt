package com.ayush.neetcracker

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/**
 * Subject chapter screen (v8.19 §7).
 * Top: back / subject name / overall progress %. Under it a slim overall bar.
 * Chapter rows are large numbered cards: two-digit number chip, chapter name,
 * a status pill (Completed = success · In Progress = progress · Not Started =
 * neutral), a progress bar and percent. Status is read-only UI derived from
 * existing data (planned chapter done flag + questions attempted in that
 * chapter); tapping a card still toggles the coaching-chapter "done" flag —
 * logic unchanged, look only.
 */
class SubjectActivity : Activity() {

    private var key: String = "PHY"
    private lateinit var headerPct: TextView
    private lateinit var headerFill: View
    private lateinit var caption: TextView
    private lateinit var pinValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = intent.getStringExtra("key") ?: "PHY"
        render()
    }

    /** "Plan starts at" line: the pinned coaching chapter, or auto = first unfinished. */
    private fun pinText(): String {
        val pin = Store.overrideChapter(this, key)
        return if (pin >= 0) (Subjects.byKey(key)?.chapters?.getOrNull(pin) ?: "Auto")
        else "Auto — first unfinished"
    }

    private fun openPinPicker() {
        val sub = Subjects.byKey(key) ?: return
        val labels = ArrayList<String>()
        for ((i, ch) in sub.chapters.withIndex()) labels.add("${i + 1}. $ch")
        labels.add("Auto — first unfinished")
        AlertDialog.Builder(this)
            .setTitle("Where are you in coaching?")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == labels.size - 1) {
                    Store.clearOverrideChapter(this, key)
                } else {
                    Store.setOverrideChapter(this, key, which)
                }
                pinValue.text = pinText()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- subject colour identity (mirrors TabMore's private helpers) ----
    private fun subjFill(): Int = when (key) {
        "PHY" -> 0xFFEAF1F8.toInt()
        "CHEM" -> 0xFFFFF3E0.toInt()
        else -> 0xFFE7F3EC.toInt() // Botany & Zoology keep the bio-green family
    }

    private fun subjAccent(): Int = when (key) {
        "PHY" -> 0xFF2F6FB2.toInt()
        "CHEM" -> 0xFFC77B1F.toInt()
        else -> Ui.color(this, R.color.primary)
    }

    // ---- status pill palette (success / progress / neutral, one accent family) ----
    private fun pill(label: String, fill: Int, ink: Int): TextView {
        val tv = Ui.text(this, label, 11f, ink, true)
        tv.setPadding(Ui.dp(this, 10), Ui.dp(this, 3), Ui.dp(this, 10), Ui.dp(this, 3))
        tv.background = Ui.cardBg(this, fill, 12)
        return tv
    }

    /** Accuracy ink: strong = primary, middling = amber, weak = red (dark-mode safe via Theme.ink). */
    private fun accInk(acc: Int): Int = when {
        acc >= 70 -> Ui.color(this, R.color.primary)
        acc >= 50 -> Theme.ink(this, 0xFFB26A00.toInt())
        else -> Theme.ink(this, 0xFFE0524D.toInt())
    }

    private fun completedPill() =
        pill("Completed", 0xFFDDF0E4.toInt(), Ui.color(this, R.color.primary))

    private fun inProgressPill() =
        pill("In Progress", 0xFFFFF6E3.toInt(), 0xFFB26A00.toInt())

    private fun notStartedPill() =
        pill("Not Started", 0xFFEEF0F2.toInt(), Ui.color(this, R.color.text_sub))

    private fun render() {
        val sub = Subjects.byKey(key) ?: return
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        // chapter practice + per-chapter attempt counts (read once)
        val bank = HashMap<String, Int>()
        for (q in Store.questionBank(this)) if (q.subject == key) bank[q.chapter] = (bank[q.chapter] ?: 0) + 1
        // tried[chapter] = IntArray(attempted, correct) — drives the live accuracy badge
        val tried = HashMap<String, IntArray>()
        for (a in Store.attempts(this)) if (a.subject == key) {
            val arr = tried.getOrPut(a.chapter) { IntArray(2) }
            arr[0]++
            if (a.correct) arr[1]++
        }
        val total = sub.chapters.size

        // header: back / subject name / progress %
        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 4))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.heading(this, sub.name)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@SubjectActivity, 6)
        })
        headerPct = Ui.text(this, "0%", 20f, Ui.color(this, R.color.primary), true)
        headerPct.gravity = Gravity.END
        header.addView(headerPct)
        root.addView(header)

        // slim overall progress bar + tiny count caption
        val headerTrack = LinearLayout(this)
        headerTrack.orientation = LinearLayout.HORIZONTAL
        headerTrack.weightSum = 1f
        headerTrack.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 6)
        headerFill = View(this)
        headerFill.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 6)
        headerTrack.addView(headerFill, LinearLayout.LayoutParams(0, Ui.dp(this, 7), 0f))
        root.addView(headerTrack, Ui.margins(16, 2, 16, 0, this))
        caption = Ui.text(this, "", 11f, Ui.color(this, R.color.text_sub))
        root.addView(caption, Ui.margins(18, 3, 16, 0, this))

        // "Plan starts at" pin — tells My Day which chapter you're on in coaching.
        val pinRow = Ui.row(this)
        pinRow.background = Ui.cardBg(this, 0xFFEAF1EC.toInt(), 12)
        pinRow.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
        val pinLabel = Ui.text(this, "Plan starts at", 15f, Ui.color(this, R.color.text_main), true)
        pinRow.addView(pinLabel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pinValue = Ui.text(this, pinText(), 14f, Ui.color(this, R.color.primary), true)
        pinValue.gravity = Gravity.END
        pinRow.addView(pinValue)
        pinRow.setOnClickListener { openPinPicker() }
        Ui.clickable(this, pinRow)
        root.addView(pinRow, Ui.margins(16, 10, 16, 4, this))

        val sv = ScrollView(this)
        val list = Ui.column(this)
        val pad = Ui.dp(this, 16)
        list.setPadding(pad, Ui.dp(this, 8), pad, Ui.dp(this, 24))
        sv.addView(list, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val numChipFill = subjFill()
        val numChipInk = subjAccent()

        fun updateHeader() {
            val done = Store.doneCount(this, key)
            val pct = if (total == 0) 0 else done * 100 / total
            headerPct.text = "$pct%"
            headerFill.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this, 7), if (total == 0) 0f else done.toFloat() / total)
            caption.text = "$done of $total chapters"
        }

        for (i in sub.chapters.indices) {
            val card = chapterCard(sub, i, bank, tried, numChipFill, numChipInk) {
                updateHeader()
            }
            list.addView(card)
            list.addView(Ui.space(this, 10))
        }

        setContentView(root)
        updateHeader()
    }

    /** Large numbered chapter card: number chip · name · status pill · progress bar · chevron. */
    private fun chapterCard(
        sub: Subject, index: Int,
        bank: Map<String, Int>, tried: Map<String, IntArray>,
        chipFill: Int, chipInk: Int,
        onToggle: () -> Unit
    ): LinearLayout {
        val card = Ui.column(this)
        card.background = Ui.cardBg(this)
        card.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14))

        val chName = sub.chapters[index]
        val isDone = Store.isDone(this, sub.key, index)
        val stat = tried[chName]
        val triedN = stat?.get(0) ?: 0
        val correctN = stat?.get(1) ?: 0
        val bankN = bank[chName] ?: 0

        // top row: number chip | name (weight 1) | chevron
        val top = Ui.row(this)
        val chip = Ui.column(this)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(this, chipFill, 12)
        chip.addView(Ui.text(this, String.format(Locale.US, "%02d", index + 1), 14f, chipInk, true))
        top.addView(chip, LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)))
        val name = Ui.text(this, chName, 16f, Ui.color(this, R.color.text_main), true)
        top.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@SubjectActivity, 12)
        })
        // live accuracy badge — how well, not just how far
        if (triedN > 0) {
            val acc = correctN * 100 / triedN
            val accTv = Ui.text(this, "$acc%", 12.5f, accInk(acc), true)
            accTv.gravity = Gravity.CENTER_VERTICAL
            top.addView(accTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 42)).apply {
                marginEnd = Ui.dp(this@SubjectActivity, 8)
            })
        }
        val chevron = Ui.text(this, "›", 22f, Ui.color(this, R.color.text_sub), true)
        chevron.gravity = Gravity.CENTER_VERTICAL
        top.addView(chevron, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 42)))
        card.addView(top)

        // bottom row: status pill | progress bar (weight 1) | percent
        val bottom = Ui.row(this)
        val pill = if (isDone) completedPill()
        else if (triedN > 0) inProgressPill()
        else notStartedPill()
        bottom.addView(pill)

        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 6)
        val fill = View(this)
        fill.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 6)
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(this, 7), 0f))
        bottom.addView(track, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@SubjectActivity, 10)
        })

        val pct = Ui.text(this, "", 13f, Ui.color(this, R.color.primary), true)
        pct.gravity = Gravity.END
        pct.minWidth = Ui.dp(this, 38)
        bottom.addView(pct, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = Ui.dp(this@SubjectActivity, 8)
        })
        card.addView(bottom, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(this@SubjectActivity, 10)
        })

        fun style() {
            val done = Store.isDone(this@SubjectActivity, sub.key, index)
            val tN = tried[chName]?.get(0) ?: 0
            val bN = bank[chName] ?: 0
            when {
                done -> {
                    pill.text = "Completed"
                    pill.setTextColor(Ui.color(this@SubjectActivity, R.color.primary))
                    pill.background = Ui.cardBg(this@SubjectActivity, 0xFFDDF0E4.toInt(), 12)
                    pct.text = "100%"
                    pct.setTextColor(Ui.color(this@SubjectActivity, R.color.primary))
                    fill.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this@SubjectActivity, 7), 1f)
                }
                tN > 0 -> {
                    pill.text = "In Progress"
                    pill.setTextColor(Theme.ink(this@SubjectActivity, 0xFFB26A00.toInt()))
                    pill.background = Ui.cardBg(this@SubjectActivity, 0xFFFFF6E3.toInt(), 12)
                    val frac = if (bN > 0) (tN.toFloat() / bN).coerceIn(0f, 1f) else 0.35f
                    val shown = if (bN > 0) "${(tN * 100 / bN).coerceAtMost(100)}%" else "—"
                    pct.text = shown
                    pct.setTextColor(Ui.color(this@SubjectActivity, R.color.primary))
                    fill.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this@SubjectActivity, 7), frac)
                }
                else -> {
                    pill.text = "Not Started"
                    pill.setTextColor(Ui.color(this@SubjectActivity, R.color.text_sub))
                    pill.background = Ui.cardBg(this@SubjectActivity, 0xFFEEF0F2.toInt(), 12)
                    pct.text = "0%"
                    pct.setTextColor(Ui.color(this@SubjectActivity, R.color.text_sub))
                    fill.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this@SubjectActivity, 7), 0f)
                }
            }
        }
        style()

        card.setOnClickListener {
            val newly = Store.setDone(this, sub.key, index, !Store.isDone(this, sub.key, index))
            style()
            onToggle()
            if (newly) {
                val todayDone = Store.dayLog(this, Store.todayKey()).ch
                val goal = Store.goals(this).ch
                if (todayDone >= goal) Ui.toast(this, "Chapter done! Daily chapter target met 🎯")
            }
        }
        Ui.clickable(this, card)
        return card
    }
}
