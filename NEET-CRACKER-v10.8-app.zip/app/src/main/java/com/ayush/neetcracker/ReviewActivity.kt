package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Read-only review list: the mistake book, or bookmarked questions. */
class ReviewActivity : Activity() {

    private var mode = "mistakes"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "mistakes"
        render()
    }

    private fun render() {
        val isMistakes = mode == "mistakes"
        val c = this

        // gather question ids in display order, de-duplicated
        val ids = LinkedHashSet<String>()
        if (isMistakes) {
            for (m in Store.mistakes(c)) ids.add(m.qid)
        } else {
            for (id in Store.bookmarks(c)) ids.add(id)
        }
        val questions = ids.mapNotNull { Store.questionById(c, it) }

        val root = Ui.column(c)
        root.setBackgroundColor(Ui.color(c, R.color.bg))

        val header = Ui.row(c)
        header.setPadding(Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 6))
        val back = Ui.text(c, "‹", 30f, Ui.color(c, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(c, if (isMistakes) "Mistake book" else "Bookmarks", 20f, Ui.color(c, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 6)
        })
        root.addView(header)

        if (questions.isNotEmpty()) {
            val sub = Ui.text(
                c,
                if (isMistakes) "${questions.size} question${if (questions.size == 1) "" else "s"} you got wrong — read the correct answer and explanation, then drill them."
                else "${questions.size} question${if (questions.size == 1) "" else "s"} you saved",
                14f, Ui.color(c, R.color.text_sub)
            )
            sub.setPadding(Ui.dp(c, 18), Ui.dp(c, 2), Ui.dp(c, 18), Ui.dp(c, 8))
            root.addView(sub)

            val drill = Ui.button(c, if (isMistakes) "Drill all mistakes" else "Practice all bookmarks", true)
            drill.setOnClickListener {
                val i = android.content.Intent(c, QuizActivity::class.java)
                i.putExtra("ids", questions.joinToString(",") { it.id })
                startActivity(i)
            }
            val dm = Ui.margins(0, 0, 0, 0, c)
            dm.setMargins(Ui.dp(c, 16), 0, Ui.dp(c, 16), Ui.dp(c, 10))
            root.addView(drill, dm)
        }

        val sv = ScrollView(c)
        val list = Ui.column(c)
        val pad = Ui.dp(c, 16)
        list.setPadding(pad, 0, pad, Ui.dp(c, 24))
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        if (questions.isEmpty()) {
            list.addView(Ui.text(c, if (isMistakes) "No mistakes yet — go practice a chapter and wrong answers land here." else "No bookmarks yet. Tap the ☆ on any question to save it.", 15f, Ui.color(c, R.color.text_sub)).apply {
                setPadding(Ui.dp(c, 6), Ui.dp(c, 20), 0, 0)
            })
        } else {
            for ((idx, q) in questions.withIndex()) {
                list.addView(questionCard(q, idx + 1))
                list.addView(Ui.space(c, 12))
            }
        }
        setContentView(root)
    }

    private fun questionCard(q: Store.Question, n: Int): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))

        val subjName = Subjects.byKey(q.subject)?.name ?: ""
        // Paper questions carry no chapter (real NEET papers have none per question).
        val label = if (q.chapter.isBlank()) "$n.  $subjName" else "$n.  $subjName — ${q.chapter}"
        val tag = Ui.text(c, label, 12f, Ui.color(c, R.color.accent), true)
        card.addView(tag)
        card.addView(Ui.space(c, 4))

        val body = Ui.text(c, q.text, 15f, Ui.color(c, R.color.text_main), true)
        body.setLineSpacing(Ui.dp(c, 2).toFloat(), 1f)
        card.addView(body)
        card.addView(Ui.space(c, 8))

        for ((i, opt) in q.options.withIndex()) {
            val tv = Ui.text(c, "${'A' + i}.  $opt", 14f, Ui.color(c, R.color.text_sub))
            tv.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
            if (i == q.answer) {
                tv.background = Ui.cardBg(c, 0xFFDDF0E4.toInt(), 10)
                tv.setTextColor(Ui.color(c, R.color.primary))
                tv.setTypeface(null, Typeface.BOLD)
            }
            card.addView(tv, Ui.margins(0, 0, 0, 4, c))
        }

        if (q.explain.isNotEmpty()) {
            card.addView(Ui.space(c, 4))
            val ex = Ui.text(c, "Why: ${q.explain}", 13f, Ui.color(c, R.color.text_sub))
            ex.setPadding(0, Ui.dp(c, 4), 0, 0)
            card.addView(ex)
        }
        return card
    }
}
