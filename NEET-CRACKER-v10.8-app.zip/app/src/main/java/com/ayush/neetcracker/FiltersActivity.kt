package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Question filters (design spec §2 — "question filters"): build a drill exactly
 * how you want it. Pick a subject, narrow to one chapter (or all of them), and
 * choose the length; the screen shows live how many questions match before you
 * start.
 *
 * Pure UI over the existing bank — it only reads Store.questionBank and hands a
 * comma-separated id list to QuizActivity, the same id-drill path the mistake
 * book and Quick rounds already use. No new storage, no engine change.
 */
class FiltersActivity : Activity() {

    private var subjIdx = 0
    private var chapIdx = 0                 // 0 = All chapters; 1..n -> chapters[i-1]
    private var countIdx = 0
    private val counts = intArrayOf(10, 25, 50, 0)   // 0 = All

    private var bank: List<Store.Question> = emptyList()
    private lateinit var subjRow: LinearLayout
    private lateinit var chapCol: LinearLayout
    private lateinit var countRow: LinearLayout
    private lateinit var preview: TextView
    private lateinit var startBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bank = Store.questionBank(this)
        render()
    }

    private fun curSubject() = Subjects.ALL[subjIdx]
    private fun curChapter(): String? =
        if (chapIdx == 0) null else curSubject().chapters.getOrNull(chapIdx - 1)

    private fun countIn(chapter: String?): Int {
        val key = curSubject().key
        return bank.count { it.subject == key && (chapter == null || it.chapter == chapter) }
    }

    private fun matching(): List<Store.Question> {
        val key = curSubject().key
        val ch = curChapter()
        return bank.filter { it.subject == key && (ch == null || it.chapter == ch) }
    }

    private fun render() {
        val c = this
        val root = Ui.column(c)
        root.setBackgroundColor(Ui.color(c, R.color.bg))
        root.addView(header())

        val sv = ScrollView(c)
        val col = Ui.column(c)
        col.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 28))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(Ui.text(c, "Build a drill exactly how you want it.", 14f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 16))

        col.addView(label("SUBJECT"))
        col.addView(Ui.space(c, 8))
        subjRow = Ui.row(c)
        col.addView(subjRow)

        col.addView(Ui.space(c, 16))
        col.addView(label("CHAPTER"))
        col.addView(Ui.space(c, 8))
        chapCol = Ui.column(c)
        col.addView(chapCol)

        col.addView(Ui.space(c, 16))
        col.addView(label("QUESTIONS"))
        col.addView(Ui.space(c, 8))
        countRow = Ui.row(c)
        col.addView(countRow)

        col.addView(Ui.space(c, 20))
        preview = Ui.text(c, "", 13.5f, Ui.color(c, R.color.text_sub))
        col.addView(preview)
        col.addView(Ui.space(c, 10))

        startBtn = Ui.button(c, "START PRACTICE", true)
        startBtn.gravity = Gravity.CENTER
        startBtn.setOnClickListener { start() }
        col.addView(startBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 54)))

        setContentView(root)
        refresh()
    }

    /** Rebuilds all three choosers + the live count. Called on every pick. */
    private fun refresh() {
        val c = this

        subjRow.removeAllViews()
        for ((i, s) in Subjects.ALL.withIndex()) {
            val tv = chip(s.name, i == subjIdx)
            tv.setOnClickListener { subjIdx = i; chapIdx = 0; refresh() }
            subjRow.addView(tv, chipLp())
        }

        chapCol.removeAllViews()
        chapCol.addView(chapterRow("All chapters", countIn(null), chapIdx == 0) {
            chapIdx = 0; refresh()
        })
        for ((i, ch) in curSubject().chapters.withIndex()) {
            chapCol.addView(chapterRow(ch, countIn(ch), chapIdx == i + 1) {
                chapIdx = i + 1; refresh()
            })
        }

        countRow.removeAllViews()
        for ((i, n) in counts.withIndex()) {
            val tv = chip(if (n == 0) "All" else "$n", i == countIdx)
            tv.setOnClickListener { countIdx = i; refresh() }
            countRow.addView(tv, chipLp())
        }

        val total = matching().size
        val want = counts[countIdx]
        val take = if (want == 0 || want > total) total else want
        preview.text =
            if (total == 0) "No questions in this selection yet."
            else "$take question${if (take == 1) "" else "s"} ready  ·  $total in this selection"
        startBtn.alpha = if (total == 0) 0.5f else 1f
    }

    private fun start() {
        val c = this
        val m = matching()
        if (m.isEmpty()) {
            Ui.toast(c, "No questions here yet — pick another chapter")
            Fx.shake(startBtn)
            return
        }
        val want = counts[countIdx]
        val take = if (want == 0 || want > m.size) m.size else want
        val ids = m.shuffled().take(take).joinToString(",") { it.id }
        val i = Intent(c, QuizActivity::class.java)
        i.putExtra("ids", ids)
        i.putExtra("subject", curSubject().key)
        startActivity(i)
    }

    // ---------------- pieces ----------------

    private fun header(): LinearLayout {
        val c = this
        val h = Ui.row(c)
        h.setPadding(Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 4))
        val back = Ui.text(c, "‹", 30f, Ui.color(c, R.color.primary), true)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        Fx.press(back)
        h.addView(back, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        val title = Ui.text(c, "Question filters", 20f, Ui.color(c, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        h.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 6)
        })
        return h
    }

    private fun label(t: String): TextView =
        Ui.text(this, t, 11f, Ui.color(this, R.color.text_sub), true)

    private fun chipLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = Ui.dp(this@FiltersActivity, 8); bottomMargin = Ui.dp(this@FiltersActivity, 0) }

    private fun chip(text: String, sel: Boolean): TextView {
        val c = this
        val tv = Ui.text(c, text, 13f, if (sel) Color.WHITE else Ui.color(c, R.color.text_main), true)
        tv.gravity = Gravity.CENTER
        tv.background = Ui.cardBg(
            c,
            if (sel) Ui.color(c, R.color.primary) else 0xFFEDF1EE.toInt(),
            20,
            if (sel) 0 else 0x22000000.toInt()
        )
        tv.setPadding(Ui.dp(c, 16), Ui.dp(c, 9), Ui.dp(c, 16), Ui.dp(c, 9))
        Fx.press(tv)
        return tv
    }

    /** A full-width chapter row — name on the left, live question count on the right. */
    private fun chapterRow(name: String, n: Int, sel: Boolean, onClick: () -> Unit): LinearLayout {
        val c = this
        val row = Ui.row(c)
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.cardBg(
            c,
            if (sel) 0xFFE7F3EC.toInt() else 0xFFFFFFFF.toInt(),
            14,
            if (sel) Ui.color(c, R.color.primary) else 0x1A000000.toInt()
        )
        row.setPadding(Ui.dp(c, 14), Ui.dp(c, 13), Ui.dp(c, 14), Ui.dp(c, 13))

        val tv = Ui.text(c, name, 15f, Ui.color(c, R.color.text_main), sel)
        tv.setLineSpacing(0f, 1.08f)
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val cnt = Ui.text(c, "$n Q", 13f, Ui.color(c, if (sel) R.color.primary else R.color.text_sub), true)
        cnt.gravity = Gravity.CENTER
        row.addView(cnt)

        row.setOnClickListener { onClick() }
        Fx.press(row)
        row.let {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = Ui.dp(c, 8)
            it.layoutParams = lp
        }
        return row
    }
}
