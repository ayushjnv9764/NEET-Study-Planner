package com.ayush.neetcracker

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class TimerActivity : Activity() {

    private var mode = "pomodoro"          // pomodoro | custom | stopwatch | break
    private var totalMs = 50L * 60 * 1000   // pomodoro default

    private var subjectKey = Subjects.ALL[0].key
    private var chapter = Subjects.ALL[0].chapters[0]

    private var running = false
    private var baseStart = 0L
    private var acc = 0L

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timeLabel: TextView
    private lateinit var startBtn: TextView
    private lateinit var pickerInfo: TextView

    // v9.4: live round progress + today's focus stats
    private lateinit var progTrack: LinearLayout
    private lateinit var progPct: TextView
    private lateinit var roundLabel: TextView
    private lateinit var todayTime: TextView
    private lateinit var todaySessions: TextView

    private val tick = object : Runnable {
        override fun run() {
            updateTime()
            handler.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        refreshToday() // v9.7: strip refreshed on entry, not on every tick
        if (running) {
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun elapsedMs(): Long =
        acc + if (running) (SystemClock.elapsedRealtime() - baseStart) else 0

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))

        // header
        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(this, "Study Timer", 20f, Ui.color(this, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@TimerActivity, 6)
        })
        root.addView(header)

        // mode chips
        val modes = Ui.row(this)
        modes.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 8))
        for ((m, name) in arrayOf("pomodoro" to "Pomodoro", "custom" to "Custom", "stopwatch" to "Stopwatch")) {
            val chip = chip2(m == mode, name)
            chip.setOnClickListener { pickMode(m) }
            modes.addView(chip, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            modes.addView(View(this), LinearLayout.LayoutParams(Ui.dp(this, 6), 1))
        }
        root.addView(modes)

        // timer face
        val card = Ui.column(this)
        card.background = Ui.cardBg(this)
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 20))
        card.gravity = Gravity.CENTER_HORIZONTAL

        timeLabel = Ui.text(this, "50:00", 64f, Ui.color(this, R.color.primary), true)
        timeLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        timeLabel.gravity = Gravity.CENTER
        card.addView(timeLabel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        roundLabel = Ui.text(this, roundCaption(), 12.5f, Ui.color(this, R.color.text_sub))
        roundLabel.gravity = Gravity.CENTER
        roundLabel.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 10))
        card.addView(roundLabel)

        // v9.4: live progress bar for the current round
        val progTop = Ui.row(this)
        progTop.addView(Ui.text(this, "Round progress", 12.5f, Ui.color(this, R.color.text_sub)))
        progPct = Ui.text(this, "0%", 12.5f, Ui.color(this, R.color.primary), true)
        progPct.gravity = Gravity.END
        progTop.addView(progPct, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(progTop)
        card.addView(Ui.space(this, 4))
        progTrack = LinearLayout(this)
        progTrack.orientation = LinearLayout.HORIZONTAL
        progTrack.weightSum = 1f
        progTrack.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 6)
        card.addView(progTrack, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 10)))

        card.addView(Ui.space(this, 14))
        pickerInfo = Ui.text(this, subjPickText(), 14f, Ui.color(this, R.color.text_main), true)
        pickerInfo.gravity = Gravity.CENTER
        card.addView(pickerInfo)
        val tapHint = Ui.text(this, "tap to change subject", 12f, Ui.color(this, R.color.accent), true)
        tapHint.gravity = Gravity.CENTER
        tapHint.setPadding(0, Ui.dp(this, 3), 0, 0)
        card.addView(tapHint)

        card.setOnClickListener { pickSubjectChapter() }

        val faceWrap = Ui.column(this)
        faceWrap.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 8))
        faceWrap.addView(card)
        root.addView(faceWrap)

        // controls
        val ctrl = Ui.row(this)
        ctrl.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 6))
        startBtn = Ui.button(this, "Start", true)
        startBtn.setOnClickListener { toggleStart() }
        ctrl.addView(startBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val reset = Ui.button(this, "Reset", false)
        reset.setOnClickListener { resetTimer() }
        ctrl.addView(reset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@TimerActivity, 10)
        })
        val save = Ui.button(this, "Save", false)
        save.setOnClickListener { saveSession() }
        ctrl.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@TimerActivity, 10)
        })
        root.addView(ctrl)

        // v9.4: today's focus at a glance
        val todayWrap = Ui.column(this)
        todayWrap.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), 0)
        val todayCard = Ui.row(this)
        todayCard.background = Ui.cardBg(this, Ui.color(this, R.color.card), 14)
        todayCard.setPadding(Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12))
        todayCard.gravity = Gravity.CENTER_VERTICAL

        val tCol = Ui.column(this)
        todayTime = Ui.text(this, "0m", 22f, Ui.color(this, R.color.primary), true)
        tCol.addView(todayTime)
        tCol.addView(Ui.text(this, "focused today", 11.5f, Ui.color(this, R.color.text_sub)))
        todayCard.addView(tCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val sCol = Ui.column(this)
        todaySessions = Ui.text(this, "0", 22f, Ui.color(this, R.color.text_main), true)
        sCol.addView(todaySessions)
        sCol.addView(Ui.text(this, "sessions", 11.5f, Ui.color(this, R.color.text_sub)))
        todayCard.addView(sCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        todayWrap.addView(todayCard)
        root.addView(todayWrap)

        val hint = Ui.text(this, "When a focus round ends, the session is saved automatically. Save anytime to record your time.", 12f, Ui.color(this, R.color.text_sub))
        hint.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), 0)
        root.addView(hint)

        updateTime()
        setContentView(root)
    }

    private fun roundCaption(): String = when (mode) {
        "stopwatch" -> "Stopwatch · counts up"
        "break" -> "Break time · relax"
        "custom" -> "Custom focus round"
        else -> "Pomodoro · 50 min focus"
    }

    private fun pickMode(m: String) {
        if (running) return
        acc = 0; baseStart = 0; running = false
        mode = m
        totalMs = when (m) {
            "pomodoro" -> 50L * 60 * 1000
            "stopwatch" -> 0
            else -> totalMs // custom keeps earlier value; default set in pickCustom
        }
        if (m == "custom") {
            val et = EditText(this)
            et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            et.setText("${totalMs / 60000}")
            AlertDialog.Builder(this)
                .setTitle("Focus minutes")
                .setView(et)
                .setPositiveButton("Go") { _, _ ->
                    val min = et.text.toString().toIntOrNull() ?: 25
                    totalMs = min.coerceAtLeast(1).toLong() * 60 * 1000
                    startBtn.text = "Start"
                    updateTime()
                    renderChips()
                }
                .setNegativeButton("Cancel") { _, _ -> mode = "pomodoro"; totalMs = 50L * 60 * 1000; updateTime(); renderChips() }
                .show()
        }
        startBtn.text = "Start"
        updateTime()
        renderChips()
    }

    private fun chip2(active: Boolean, label: String): TextView {
        val tv = Ui.text(
            this, label, 12f,
            if (active) Color.WHITE else Ui.color(this, R.color.text_main), true
        )
        tv.gravity = Gravity.CENTER
        tv.setPadding(Ui.dp(this, 4), Ui.dp(this, 9), Ui.dp(this, 4), Ui.dp(this, 9))
        tv.background = Ui.cardBg(this, if (active) Ui.color(this, R.color.primary) else 0xFFEAF1EC.toInt(), 10)
        return tv
    }

    private fun renderChips() {
        // simplest: re-render whole screen body by re-calling render is heavy; instead rebuild mode chips area only is complex.
        // Rely on full refresh at next data render; but we can cheaply setContentView(render())
        render()
    }

    private fun toggleStart() {
        if (mode == "stopwatch") {
            if (running) pause() else start()
        } else {
            val rem = totalMs - elapsedMs()
            if (rem <= 0) acc = 0
            if (running) pause() else start()
        }
        startBtn.text = if (running) "Pause" else "Start"
    }

    private fun start() {
        running = true
        baseStart = SystemClock.elapsedRealtime()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun pause() {
        if (running) {
            acc += SystemClock.elapsedRealtime() - baseStart
            running = false
            baseStart = 0
            handler.removeCallbacks(tick)
            updateTime()
        }
    }

    private fun resetTimer() {
        pause()
        acc = 0
        startBtn.text = "Start"
        updateTime()
    }

    private fun saveSession() {
        val ms = elapsedMs()
        if (ms < 60_000) {
            Ui.toast(this, "Nothing to save yet — study for at least a minute")
            return
        }
        val minutes = (ms / 60_000).toInt()
        Store.addSession(this, subjectKey, chapter, minutes)
        resetTimer()
        Ui.toast(this, "Saved $minutes min → ${Subjects.byKey(subjectKey)?.name}")
        refreshToday()
    }

    private fun handleDone() {
        running = false
        baseStart = 0
        acc = 0
        handler.removeCallbacks(tick)
        startBtn.text = "Start"
        if (mode == "pomodoro") {
            Store.addSession(this, subjectKey, chapter, 50)
            Ui.toast(this, "Pomodoro done! Take a 10-min break ☕")
            mode = "break"
            totalMs = 10L * 60 * 1000
            startBtn.text = "Start"
            updateTime()
        } else if (mode == "custom") {
            Store.addSession(this, subjectKey, chapter, (totalMs / 60_000).toInt())
            Ui.toast(this, "Focus session done ✓ Saved automatically")
            updateTime()
        }
        refreshToday()
    }

    /** v9.4: recompute the today strip from stored sessions. */
    private fun refreshToday() {
        val today = Store.getSessions(this).filter { it.date == Store.todayKey() }
        val mins = today.sumBy { it.durMin }
        val hh = mins / 60
        val mm = mins % 60
        todayTime.text = when {
            hh > 0 && mm > 0 -> "${hh}h ${mm}m"
            hh > 0 -> "${hh}h"
            else -> "${mm}m"
        }
        todaySessions.text = "${today.size}"
    }

    private fun updateTime() {
        val total = if (mode == "stopwatch") elapsedMs()
        else {
            val rem = totalMs - elapsedMs()
            if (rem <= 0 && mode != "break") { handleDone(); 0 }
            else rem
        }
        timeLabel.text = fmtMs(total)

        // v9.4: round progress
        if (mode == "stopwatch") {
            progPct.text = "—"
            setProgress(0f)
            roundLabel.text = roundCaption()
        } else {
            val frac = if (totalMs <= 0) 0f else (elapsedMs().toFloat() / totalMs).coerceIn(0f, 1f)
            progPct.text = "${(frac * 100).toInt()}%"
            setProgress(frac)
        }
        // v9.7: no refreshToday() here — it re-parsed the whole session list every
        // 200 ms tick. The strip only changes when a session is saved (handleDone)
        // or on return to the screen (onResume), both of which refresh it.
    }

    private fun setProgress(frac: Float) {
        // reuse the fill view — this runs on every 200 ms tick, don't churn allocations
        val fill = if (progTrack.childCount == 0) {
            View(this).also {
                it.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 6)
                progTrack.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0f))
            }
        } else progTrack.getChildAt(0)
        fill.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, frac)
    }

    private fun fmtMs(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun subjPickText(): String =
        (Subjects.byKey(subjectKey)?.name ?: "") + " — " + chapter

    private fun pickSubjectChapter() {
        val names = Subjects.ALL.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Subject")
            .setItems(names) { _, i ->
                subjectKey = Subjects.ALL[i].key
                chapter = Subjects.ALL[i].chapters[0]
                pickerInfo.text = subjPickText()
                AlertDialog.Builder(this@TimerActivity)
                    .setTitle("Chapter")
                    .setItems(Subjects.ALL[i].chapters.toTypedArray()) { _, j ->
                        chapter = Subjects.ALL[i].chapters[j]
                        pickerInfo.text = subjPickText()
                    }.show()
            }.show()
    }
}
