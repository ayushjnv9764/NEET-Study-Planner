package com.ayush.neetcracker

import android.content.Context
import android.graphics.Color

/**
 * v8.17 runtime light/dark palette. The whole UI is drawn in code with
 * hard-coded colours (no resource qualifiers), so dark mode is a switch, not a
 * values-night override: [dark] flips the handful of named colours plus the
 * light surfaces / dark ink tints the screens are built from onto a dark
 * equivalent. Ui.color / Ui.text / Ui.cardBg all route through Theme, so
 * flipping the flag re-themes every screen — that's the Settings toggle.
 *
 * Light mode is a strict identity pass (functions return the input unchanged),
 * so nothing here alters how the app already looks until the user turns dark on.
 */
object Theme {

    var dark = false
        private set
    private var loaded = false

    private const val PREFS = "nc_theme"
    private const val KEY = "dark"

    /** Named colours -> dark equivalents. Text goes light, surfaces sink, brand brightens. */
    private val darkColor = mapOf(
        R.color.bg to 0xFF0B1410.toInt(),        // page backdrop: deep green-black
        R.color.card to 0xFF1B2720.toInt(),      // raised surface
        R.color.text_main to 0xFFE7EEE9.toInt(), // near-white, green-tinted
        R.color.text_sub to 0xFF93A79C.toInt(),  // muted sage
        R.color.primary to 0xFF17A86F.toInt(),   // brand green, brightened for dark
        R.color.accent to 0xFFFFB84D.toInt()     // amber, brightened
    )

    /** Light surfaces (white cards + the pastel tiles) -> dark equivalents. */
    private val darkSurface = mapOf(
        0xFFFFFFFF.toInt() to 0xFF1B2720.toInt(),  // white cards / chips / strips
        0xFFE7F3EC.toInt() to 0xFF16251D.toInt(),  // bio-green tile
        0xFFEAF1EC.toInt() to 0xFF17241D.toInt(),
        0xFFEAF4EE.toInt() to 0xFF18271F.toInt(),
        0xFFDDF0E4.toInt() to 0xFF133522.toInt(),  // correct-answer highlight
        0xFFE4F2F0.toInt() to 0xFF152A24.toInt(),  // ayan teal tile
        0xFFEAF1F8.toInt() to 0xFF15222F.toInt(),  // physics blue tile
        0xFFE9EFF7.toInt() to 0xFF16212B.toInt(),
        0xFFFFF3E0.toInt() to 0xFF2B1F12.toInt(),  // chem amber tile
        0xFFFFF6E3.toInt() to 0xFF2B2114.toInt(),
        0xFFFFF3D9.toInt() to 0xFF2A1F13.toInt(),  // quiz explanation strip
        0xFFF3EFFF.toInt() to 0xFF1C2230.toInt(),  // lavender / neutral pastels
        0xFFF3EEFF.toInt() to 0xFF1C2230.toInt(),  // v10.1: the Revision/Weak-topic hero
        0xFFF4EFFD.toInt() to 0xFF1C2230.toInt(),
        0xFFF2EFFC.toInt() to 0xFF1C2230.toInt(),
        0xFFEDEAF7.toInt() to 0xFF1B202E.toInt(),
        0xFFF4F6FB.toInt() to 0xFF1B2420.toInt(),
        0xFFEEF0F2.toInt() to 0xFF1B211F.toInt(),
        0xFFEDF1EE.toInt() to 0xFF232C27.toInt(),  // v10.1: filter chip (was left light)
        0xFFFBEFF3.toInt() to 0xFF251D22.toInt(),  // rose-pink tint
        0xFFCBD3E1.toInt() to 0xFF3A4650.toInt(),  // inactive dot
        0xFFE4EBE7.toInt() to 0xFF24362D.toInt()   // progress track
    )

    /** Dark accent ink -> brighter equivalents that stay legible on a dark surface. */
    private val darkInk = mapOf(
        Color.BLACK to 0xFFE7EEE9.toInt(),
        0xFF0B1233.toInt() to 0xFFAAB9FF.toInt(),  // navy headline
        0xFF5A6480.toInt() to 0xFFA9B8C8.toInt(),  // slate subtitle
        0xFF6C5CE7.toInt() to 0xFFAEA2FF.toInt(),  // violet
        0xFF7B2FF7.toInt() to 0xFFC3B7FF.toInt(),
        0xFF3D2B9F.toInt() to 0xFFB4A7FF.toInt(),  // deep-violet text family
        0xFF3B2F8F.toInt() to 0xFFB4A7FF.toInt(),
        0xFF4C2BD9.toInt() to 0xFFB4A7FF.toInt(),
        0xFF4A2BA8.toInt() to 0xFFB4A7FF.toInt(),
        0xFF5B3FC4.toInt() to 0xFFB4A7FF.toInt(),
        0xFF2F6FB2.toInt() to 0xFF9CC7EC.toInt(),  // physics accent
        0xFFC77B1F.toInt() to 0xFFF2BB85.toInt(),  // chem accent
        0xFFB26A00.toInt() to 0xFFF2BD73.toInt(),  // momentum dark amber
        0xFF9A4A00.toInt() to 0xFFEFAA7C.toInt(),
        0xFF2E7D32.toInt() to 0xFF66D493.toInt(),
        0xFF1B8A3A.toInt() to 0xFF5BD48D.toInt(),
        0xFF00695C.toInt() to 0xFF6FE0D0.toInt(),  // ayan teal
        0xFFB03A5B.toInt() to 0xFFF0A0B8.toInt(),  // raspberry accent
        0xFF5C6B7A.toInt() to 0xFFA9BACB.toInt(),  // slate
        0xFFB8860B.toInt() to 0xFFF0C46A.toInt(),  // bus dark gold
        0xFFE53935.toInt() to 0xFFFF8A80.toInt(),  // WEAK / wrong red
        0xFFE08A00.toInt() to 0xFFFFC05C.toInt(),  // AVERAGE amber
        0xFFE0524D.toInt() to 0xFFFF8A80.toInt(),  // quiz wrong red
        0xFF9AA0AA.toInt() to 0xFF9AA8A2.toInt(),  // pending mark
        0xFFC9CED7.toInt() to 0xFF6E7C74.toInt()   // untracked mark (recedes)
    )

    // ============================== v10.7 god mode ==============================
    // Ayush can recolour the app himself. An override is applied LAST — after the
    // light/dark mapping — so a colour he picks is the colour he gets in either mode,
    // and clearing it drops the shipped palette straight back in. Slots are the five
    // named colours the whole UI is drawn from.

    private const val KEY_OVR = "col_override"

    var overrides: Map<String, Int> = emptyMap()
        private set

    /** Named colour -> the override slot it answers to. */
    private val ovrSlot = mapOf(
        R.color.primary to "primary",
        R.color.accent to "accent",
        R.color.bg to "bg",
        R.color.card to "card",
        R.color.text_main to "text_main",
        R.color.text_sub to "text_sub"
    )

    val OVR_SLOTS = listOf("primary", "accent", "bg", "card", "text_main", "text_sub")

    // ---- v10.8: size and shape, the two dials that aren't colours ----
    // Both are multipliers on the shipped numbers, so "Normal" (1f) is a strict
    // identity pass exactly like light mode is. Ui.text and Ui.cardBg read them, and
    // those two functions are the only place the app sets a font size or a corner
    // radius — so one value moves the whole app.

    private const val KEY_TEXT = "text_scale"
    private const val KEY_RADIUS = "radius_scale"

    var textScale = 1f
        private set
    var radiusScale = 1f
        private set

    fun textScaleOf(c: Context): Float {
        ensure(c)
        return textScale
    }

    fun radiusScaleOf(c: Context): Float {
        ensure(c)
        return radiusScale
    }

    fun setTextScale(c: Context, v: Float) {
        ensure(c)
        textScale = v
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_TEXT, v).apply()
    }

    fun setRadiusScale(c: Context, v: Float) {
        ensure(c)
        radiusScale = v
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_RADIUS, v).apply()
    }

    /** Text and corners back to the shipped sizes. */
    fun clearScale(c: Context) {
        textScale = 1f
        radiusScale = 1f
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_TEXT).remove(KEY_RADIUS).apply()
    }

    private fun parseOverrides(raw: String?): Map<String, Int> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val m = HashMap<String, Int>()
        for (part in raw.split(";")) {
            val kv = part.split("=")
            if (kv.size == 2) kv[1].toIntOrNull()?.let { m[kv[0]] = it }
        }
        return m
    }

    private fun persistOverrides(c: Context, m: Map<String, Int>) {
        val raw = m.entries.joinToString(";") { "${it.key}=${it.value}" }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_OVR, raw).apply()
    }

    fun overrideOf(c: Context, slot: String): Int? {
        ensure(c)
        return overrides[slot]
    }

    fun setOverride(c: Context, slot: String, color: Int) {
        ensure(c)
        val m = HashMap(overrides)
        m[slot] = color
        overrides = m
        persistOverrides(c, m)
    }

    fun clearOverride(c: Context, slot: String) {
        ensure(c)
        val m = HashMap(overrides)
        m.remove(slot)
        overrides = m
        persistOverrides(c, m)
    }

    /** Back to the shipped palette — every colour override gone. */
    fun clearOverrides(c: Context) {
        overrides = emptyMap()
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_OVR).apply()
    }

    fun ensure(c: Context) {
        if (loaded) return
        loaded = true
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        dark = p.getBoolean(KEY, false)
        overrides = parseOverrides(p.getString(KEY_OVR, ""))
        textScale = p.getFloat(KEY_TEXT, 1f)
        radiusScale = p.getFloat(KEY_RADIUS, 1f)
    }

    fun isDark(c: Context): Boolean {
        ensure(c)
        return dark
    }

    fun setDark(c: Context, on: Boolean) {
        dark = on
        loaded = true
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply()
    }

    /** Resolve a named resource colour (identity in light mode). */
    fun color(c: Context, resId: Int): Int {
        ensure(c)
        ovrSlot[resId]?.let { slot -> overrides[slot]?.let { return it } }
        if (!dark) return c.resources.getColor(resId)
        return darkColor[resId] ?: c.resources.getColor(resId)
    }

    /** Map a light surface colour (white/pastel fill) to its dark surface. */
    fun surface(c: Context?, v: Int): Int {
        if (c != null) ensure(c)
        // A plain white card is the "card" slot, so one override restyles every
        // default surface; explicit pastel tiles keep their own identity.
        if (v == Color.WHITE) overrides["card"]?.let { return it }
        if (!dark) return v
        return darkSurface[v] ?: v
    }

    /** Map a dark ink colour (text accent) to a bright one for dark surfaces. */
    fun ink(c: Context?, v: Int): Int {
        if (c != null) ensure(c)
        if (!dark) return v
        return darkInk[v] ?: v
    }

    /** Background slogan watermark: faint brand green on light, faint mint on dark. */
    fun watermark(): Int = if (dark) 0x2B5FE8B0.toInt() else 0x140E7A4C

    /**
     * v10.1: ink for text sitting ON a [ink]-derived fill (an accuracy pill, a
     * subject chip, a ✓/✕ badge). Those fills are dark in light mode but go
     * BRIGHT in dark mode, so white label text ends up white-on-pastel and
     * unreadable. Flip the label instead: white on the dark fill, near-black on
     * the bright one.
     */
    fun onAccent(c: Context?): Int {
        if (c != null) ensure(c)
        return if (dark) 0xFF101A15.toInt() else Color.WHITE
    }
}
