package com.ayush.neetcracker

import android.content.Context
import org.json.JSONArray

/**
 * v8.1 Momentum sync — Ayush's own coaching timetable (Momentum CNR-1,
 * "Ambition (NEET)-260", Gorakhpur) shipped inside the app as an asset.
 *
 * The asset is one row per day of the course flow (Day 1 = 10 Jul 2026 →
 * Day 194 = 19 Mar 2027), with the topic Momentum teaches that day in each
 * of the four NEET subjects, plus the labelled events Momentum embeds in the
 * flow (PT/MT tests, holidays). Sundays are off and are not rows.
 *
 * Dates use "yyyy-MM-dd" keys so a row is looked up by Store.todayKey().
 */
object MomentumPlan {

    /** Display order across a coaching day = NEET paper order. */
    val SLOTS = listOf("PHY", "CHEM", "BOT", "ZOO")

    val SLOT_NAME = mapOf(
        "PHY" to "Physics", "CHEM" to "Chemistry", "BOT" to "Botany", "ZOO" to "Zoology"
    )

    val SLOT_TINT = mapOf(
        "PHY" to 0xFF1565C0.toInt(), "CHEM" to 0xFF2E7D32.toInt(),
        "BOT" to 0xFF6A1B9A.toInt(), "ZOO" to 0xFFB03A5B.toInt()
    )

    /** One row of the course flow. kind: class | test | holiday. */
    data class Row(
        val day: Int,
        val date: String,          // yyyy-MM-dd
        val dow: String,
        val kind: String,
        val label: String,
        val phy: String, val chem: String, val bot: String, val zoo: String
    ) {
        fun topic(slot: String): String = when (slot) {
            "PHY" -> phy
            "CHEM" -> chem
            "BOT" -> bot
            else -> zoo
        }
    }

    private var cached: List<Row>? = null

    fun rows(c: Context): List<Row> {
        cached?.let { return it }
        val out = ArrayList<Row>()
        try {
            val text = c.assets.open("momentum_plan.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Row(
                        o.optInt("d", -1),
                        o.optString("date", ""),
                        o.optString("dow", ""),
                        o.optString("kind", "class"),
                        o.optString("label", ""),
                        o.optString("phy", "-"), o.optString("chem", "-"),
                        o.optString("bot", "-"), o.optString("zoo", "-")
                    )
                )
            }
            out.sortBy { it.date }
        } catch (e: Exception) {
            // asset missing or malformed -> plan surfaces simply don't render
        }
        cached = out
        return out
    }

    fun has(c: Context): Boolean = rows(c).isNotEmpty()

    fun classRows(c: Context): List<Row> = rows(c).filter { it.kind == "class" }

    /** The row dated exactly today, whatever kind it is (class/test/holiday). */
    fun today(c: Context): Row? = rows(c).firstOrNull { it.date == Store.todayKey() }

    /**
     * The class row that rules right now: today when it is a class day,
     * otherwise the most recent class day before today (so a Sunday still
     * shows where the course stands), otherwise the first day of the plan.
     */
    fun anchor(c: Context): Row? {
        val cls = classRows(c)
        if (cls.isEmpty()) return null
        val tk = Store.todayKey()
        cls.firstOrNull { it.date == tk }?.let { return it }
        cls.filter { it.date < tk }.maxByOrNull { it.date }?.let { return it }
        return cls.first()
    }

    /** 1-based position in the course (today's row d), or -1 outside the plan. */
    fun dayNo(c: Context): Int = anchor(c)?.day ?: -1

    fun planDays(c: Context): Int = classRows(c).size

    /** Tests still scheduled on the plan at/after today, nearest first. */
    fun nextTests(c: Context, n: Int = 3): List<Row> =
        rows(c).filter { it.kind == "test" && it.date >= Store.todayKey() }.take(n)

    /** The next n class days at/after today, chronological. */
    fun nextClassDays(c: Context, n: Int = 14): List<Row> =
        classRows(c).filter { it.date >= Store.todayKey() }.take(n)
}
