package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * v4 checklists: tonight's before-bed list, and the two bus-trip lists.
 * Mode passed via intent extra "mode": "bed" | "bus_out" | "bus_in".
 * Ticks persist per date; fully ticking the bed list closes the day (streak).
 */
class ChecklistActivity : Activity() {

    private lateinit var set: String
    private var items = emptyList<String>()
    private lateinit var title: String
    private lateinit var subtitle: String

    private val rows = ArrayList<LinearLayout>()
    private lateinit var progress: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra("mode") ?: "bed"
        when (mode) {
            "bus_out" -> {
                set = MyDay.BUS_SET_OUT; title = "Bus to Momentum"; subtitle = "Light work — the ride is study time too"
                items = MyDay.busItems(this, true)
            }
            "bus_in" -> {
                set = MyDay.BUS_SET_IN; title = "Bus home"; subtitle = "Catch up anything you missed today"
                items = MyDay.busItems(this, false)
            }
            else -> {
                set = MyDay.BED_SET; title = "Tonight checklist"; subtitle = "Close the day properly — 5 quick ticks"
                items = MyDay.BED_ITEMS
            }
        }
        render()
    }

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        addHeader(root, title)

        val pad = Ui.dp(this, 16)
        val sc = ScrollView(this)
        val col = Ui.column(this)
        col.setPadding(pad, 0, pad, Ui.dp(this, 24))
        sc.addView(col)
        root.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(Ui.text(this, subtitle, 14f, Ui.color(this, R.color.text_sub)))
        col.addView(Ui.space(this, 12))

        val ticks = Store.ticks(this, Store.todayKey(), set)
        for ((i, item) in items.withIndex()) {
            val r = Ui.row(this)
            r.background = Ui.cardBg(this, if (item in ticks) 0xFFE7F3EC.toInt() else Color.WHITE)
            r.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
            val mark = Ui.text(this, if (item in ticks) "✓" else "○", 18f,
                if (item in ticks) Ui.color(this, R.color.primary) else Ui.color(this, R.color.text_sub), true)
            r.addView(mark)
            val label = Ui.text(this, item, 15f, Ui.color(this, R.color.text_main),
                if (item in ticks) true else false)
            r.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(this@ChecklistActivity, 10)
            })
            r.setOnClickListener { toggle(i, item, r, mark, label) }
            Ui.clickable(this, r)
            col.addView(r, Ui.margins(0, 0, 0, 8, this))
            rows.add(r)
        }

        progress = Ui.text(this, progressText(ticks.size), 13f, Ui.color(this, R.color.text_sub))
        progress.gravity = Gravity.CENTER
        col.addView(progress)
        col.addView(Ui.space(this, 12))

        val done = Ui.button(this, if (set == MyDay.BED_SET) "Done — I'm off to sleep" else "Done", true)
        done.setOnClickListener { finish() }
        col.addView(done)
        setContentView(root)
    }

    private fun toggle(index: Int, item: String, row: LinearLayout, mark: TextView, label: TextView) {
        val ticks = Store.ticks(this, Store.todayKey(), set).toMutableSet()
        val on = if (item in ticks) { ticks.remove(item); false } else { ticks.add(item); true }
        Store.setTick(this, Store.todayKey(), set, item, on)
        mark.text = if (on) "✓" else "○"
        mark.setTextColor(if (on) Ui.color(this, R.color.primary) else Ui.color(this, R.color.text_sub))
        label.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        row.background = Ui.cardBg(this, if (on) 0xFFE7F3EC.toInt() else Color.WHITE)
        progress.text = progressText(ticks.size)
        if (set == MyDay.BED_SET && on && ticks.size == items.size) closeDay()
    }

    private fun progressText(n: Int) = "$n / ${items.size} ticked"
        .let { if (set == MyDay.BED_SET) "$it · close the day by ticking all five" else it }

    /** All five bed items ticked → the day counts as closed even without a timer session. */
    private fun closeDay() {
        if (!Store.studiedToday(this)) {
            Store.markStudiedToday(this)
            Ui.toast(this, "Day closed — streak ${Store.streak(this)} 🔥 Sleep well!")
        } else {
            Ui.toast(this, "Day closed 🌙 Great work today!")
        }
    }

    /** Shared back bar used by checklist & friends. */
    private fun addHeader(root: LinearLayout, titleText: String) {
        val h = Ui.row(this)
        h.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val b = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        b.setOnClickListener { finish() }
        h.addView(b)
        val t = Ui.text(this, titleText, 20f, Ui.color(this, R.color.text_main), true)
        t.setTypeface(null, Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = Ui.dp(this, 6)
        h.addView(t, lp)
        root.addView(h)
    }
}
