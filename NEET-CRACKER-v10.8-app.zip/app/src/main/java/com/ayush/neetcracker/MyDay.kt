package com.ayush.neetcracker

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.util.Calendar

/**
 * v4 "My Day": turns Ayush's real routine + Momentum coaching day into a list of
 * time-blocked cards. Pure generator over Store; rendering lives in the UI layer.
 */
object MyDay {

    // Lecture playlists (full-syllabus one-shots Ayush picked) — Botany & Zoology.
    const val BOT_URL = "https://youtube.com/playlist?list=PL8_1l_iSLgyTZzDdX7sv73a3NH_u9isuK"
    const val ZOO_URL = "https://youtube.com/playlist?list=PL3m-p7hatfDpPSrmydYTXU2io4USf2Ce-"

    const val KIND_MISC = "misc"
    const val KIND_BUS = "bus"
    const val KIND_CLASS = "class"
    const val KIND_BED = "bed"
    const val KIND_SLEEP = "sleep"
    const val KIND_LECTURE = "lecture" // a bio playlist deep-link chip rides on a study block

    data class Block(
        val id: String,          // stable per slot ("bio_am", "bus_out", "bed", ...)
        val startMin: Int,
        val endMin: Int,
        val kind: String,
        val subj: String,        // subject key, "" when not subject-specific
        val chapter: String,
        val title: String,
        val sub: String,
        val chip: String = ""    // extra caption: "Watch lecture ▸", "Open checklist", ...
    )

    // ---- v10.6: Ayush's own edits, stored by Store and laid over the plan below ----
    /** Retime + rename of one generated block. */
    data class PlanEdit(val start: Int, val end: Int, val title: String)
    /** A block Ayush added himself; the id is stable so its done-tick sticks. */
    data class CustomBlock(val id: String, val start: Int, val end: Int, val title: String, val sub: String)

    // ============================== bio pacing ==============================
    /** Sprint length per chapter: 2 (short) / 3 (medium) / 4 (long). Default 3. */
    private val PACING = mapOf(
        "BOT:The Living World" to 2,
        "BOT:Biological Classification" to 3,
        "BOT:Plant Kingdom" to 3,
        "BOT:Morphology of Flowering Plants" to 4,
        "BOT:Anatomy of Flowering Plants" to 4,
        "BOT:Cell: The Unit of Life" to 4,
        "BOT:Cell Cycle & Cell Division" to 3,
        "BOT:Biomolecules" to 3,
        "BOT:Transport in Plants" to 3,
        "BOT:Mineral Nutrition" to 2,
        "BOT:Photosynthesis in Higher Plants" to 4,
        "BOT:Respiration in Plants" to 4,
        "BOT:Plant Growth & Development" to 3,
        "BOT:Sexual Reproduction in Flowering Plants" to 4,
        "BOT:Principles of Inheritance & Variation" to 4,
        "BOT:Molecular Basis of Inheritance" to 4,
        "BOT:Evolution" to 3,
        "ZOO:Animal Kingdom" to 4,
        "ZOO:Structural Organisation in Animals" to 3,
        "ZOO:Digestion & Absorption" to 3,
        "ZOO:Breathing & Exchange of Gases" to 3,
        "ZOO:Body Fluids & Circulation" to 3,
        "ZOO:Excretory Products & their Elimination" to 3,
        "ZOO:Locomotion & Movement" to 3,
        "ZOO:Neural Control & Coordination" to 3,
        "ZOO:Chemical Coordination & Integration" to 3,
        "ZOO:Human Reproduction" to 4,
        "ZOO:Reproductive Health" to 2,
        "ZOO:Human Health & Disease" to 4,
        "ZOO:Strategies for Enhancement in Food Production" to 3,
        "ZOO:Microbes in Human Welfare" to 3,
        "ZOO:Biotechnology: Principles & Processes" to 4,
        "ZOO:Biotechnology & its Applications" to 2,
        "ZOO:Organisms & Populations" to 3,
        "ZOO:Ecosystem" to 3,
        "ZOO:Biodiversity & Conservation" to 2,
        "ZOO:Environmental Issues" to 3
    )

    fun bioDays(c: Context, subjectKey: String, index: Int): Int {
        val sub = Subjects.byKey(subjectKey) ?: return 3
        val name = sub.chapters.getOrNull(index) ?: return 3
        return PACING["$subjectKey:$name"] ?: 3
    }

    /** First not-done chapter of a subject: (index, name) or null when subject finished. */
    fun activeChapter(c: Context, subjectKey: String): Pair<Int, String>? {
        val sub = Subjects.byKey(subjectKey) ?: return null
        for (i in sub.chapters.indices) if (!Store.isDone(c, subjectKey, i)) return i to sub.chapters[i]
        return null
    }

    /**
     * Chapter the plan actually works on: the manual pin (when the user says
     * "I'm at this chapter in coaching") if set and not yet done, else the first
     * unfinished chapter. Finishing the pinned chapter clears the pin, so the
     * plan advances by itself.
     */
    fun curChapter(c: Context, subjectKey: String): Pair<Int, String>? {
        val sub = Subjects.byKey(subjectKey) ?: return null
        val pin = Store.overrideChapter(c, subjectKey)
        if (pin in sub.chapters.indices && !Store.isDone(c, subjectKey, pin)) return pin to sub.chapters[pin]
        return activeChapter(c, subjectKey)
    }

    private val MONTHS = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    /** Upcoming Momentum test date for a subject+chapter, e.g. "Thu" is out; "Sep 12". */
    fun testDueLabel(c: Context, subjectKey: String, index: Int): String? {
        val today = Store.todayKey()
        for (t in Store.momentumTests(c)) {
            if (t.subject != subjectKey || t.chapter != index || t.date < today) continue
            val p = t.date.split("-")
            return if (p.size == 3) "${MONTHS.getOrElse((p[1].toIntOrNull() ?: 1) - 1) { "" }} ${p[2].toIntOrNull() ?: 1}" else t.date
        }
        return null
    }

    /** Sprint text for today's part of the chapter the plan is on. */
    fun sprintLabel(c: Context, subjectKey: String): String {
        val a = curChapter(c, subjectKey) ?: return "All ${Subjects.byKey(subjectKey)?.name ?: ""} chapters done 🎉"
        val total = bioDays(c, subjectKey, a.first)
        val done = Store.sprintDay(c, subjectKey, a.first).coerceIn(0, total)
        val today = (done + 1).coerceAtMost(total)
        val phase = when {
            total == 1 -> "Study the chapter"
            today == 1 -> "Watch lecture + read NCERT intro"
            today == total -> "Practice questions + DPP"
            else -> "NCERT read + notes"
        }
        val due = testDueLabel(c, subjectKey, a.first)
        val base = "${a.second} · day $today of $total — $phase"
        return if (due != null) "$base\n🏫 Momentum test: $due — finish before it" else base
    }

    /** Logs one sprint part for a subject (once per day). Marks chapter done when finished. */
    fun logBioPart(c: Context, subjectKey: String): String {
        val sub = Subjects.byKey(subjectKey) ?: return ""
        val a = curChapter(c, subjectKey) ?: return "Already finished ${sub.name} chapters! 🎉"
        if (Store.bioLoggedToday(c, subjectKey)) {
            return "${sub.name} already logged today — tap the card again to undo it."
        }
        val total = bioDays(c, subjectKey, a.first)
        val done = Store.sprintDay(c, subjectKey, a.first)
        val completing = (done + 1) >= total
        Store.setBioUndo(c, subjectKey, a.first, done, completing) // snapshot for undo
        val next = done + 1
        Store.setSprintDay(c, subjectKey, a.first, next.coerceAtMost(total))
        Store.setBioLoggedToday(c, subjectKey)
        if (completing) {
            Store.setDone(c, subjectKey, a.first, true)
            val rest = Subjects.totalChapters - Store.totalDone(c)
            return "${a.second} done! ${if (rest > 0) "$rest chapters left overall." else "Full syllabus complete — legend!"}"
        }
        return "${a.second} · part ${next + 1} of $total queued for tomorrow."
    }

    /** Reverts today's mistaken bio-part log. Safe no-op when nothing was logged today. */
    fun undoBioPart(c: Context, subjectKey: String): String {
        val sub = Subjects.byKey(subjectKey) ?: return ""
        if (!Store.bioLoggedToday(c, subjectKey)) {
            return "${sub.name} isn't logged today — nothing to undo."
        }
        val rec = Store.bioUndo(c, subjectKey)
        val idx = rec?.optInt("idx", -1) ?: -1
        if (rec != null && idx >= 0) {
            Store.setSprintDay(c, subjectKey, idx, rec.optInt("prev", 0))
            if (rec.optBoolean("done", false)) Store.setDone(c, subjectKey, idx, false)
        }
        Store.clearBioLoggedToday(c, subjectKey)
        val name = if (idx in sub.chapters.indices) sub.chapters[idx] else "chapter"
        return "Undid today's ${sub.name} log — $name is back to day ${Store.sprintDay(c, subjectKey, idx.coerceAtLeast(0)) + 1}."
    }

    // ============================== checklists ==============================
    val BED_ITEMS = listOf(
        "All planned chapters done today",
        "MCQ goal hit — mistakes saved",
        "Tomorrow's plan ready",
        "Bag packed & phone charging",
        "Lights out by midnight — 6h sleep"
    )
    val BUS_SET_OUT = "bus_out"
    val BUS_SET_IN = "bus_in"
    val BED_SET = "bed"

    /** One bus trip's 3-item light checklist, led by a rotating subject. */
    fun busItems(c: Context, outbound: Boolean): List<String> {
        val lead = busLead(c, outbound)
        return when (lead) {
            "PHY" -> listOf(
                "Formula sheet scan — Physics",
                "10 quick Physics MCQs (Practice tab)",
                "Revise yesterday's Physics mistakes"
            )
            "CHEM" -> listOf(
                "Notes / reactions scan — Chemistry",
                "10 quick Chemistry MCQs (Practice tab)",
                "Revise yesterday's Chemistry mistakes"
            )
            else -> listOf(
                "NCERT lines — Biology chapter on the go",
                "5 quick Biology MCQs (Practice tab)",
                "Revise yesterday's Biology mistakes"
            )
        }
    }

    /** Rotating lead subject so all three get bus time across the week. */
    fun busLead(c: Context, outbound: Boolean): String {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val n = day + (if (outbound) 0 else 1)
        return arrayOf("PHY", "CHEM", "BIO")[((n % 3) + 3) % 3]
    }

    fun playlistUrl(subjectKey: String): String = if (subjectKey == "BOT") BOT_URL else ZOO_URL

    fun openPlaylist(c: Context, subjectKey: String) {
        val uri = Uri.parse(playlistUrl(subjectKey))
        // Prefer the YouTube app when installed; fall back to any https handler (browser).
        try {
            val yt = Intent(Intent.ACTION_VIEW, uri)
            yt.setPackage("com.google.android.youtube")
            yt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(yt)
        } catch (e: Exception) {
            try {
                val web = Intent(Intent.ACTION_VIEW, uri)
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(web)
            } catch (e2: Exception) {
                Ui.toast(c, "No app found to open YouTube")
            }
        }
    }

    // ============================== day builder ==============================
    fun hh(h: Int, m: Int) = String.format(java.util.Locale.US, "%02d:%02d", h, m)

    /** True when today is a Momentum coaching day (Mon–Sat). */
    fun classToday(): Boolean {
        val d = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        return d in Calendar.MONDAY..Calendar.SATURDAY
    }

    /** Builds today's schedule as ordered blocks. Never throws. */
    fun build(c: Context): List<Block> {
        val out = ArrayList<Block>()
        try {
            if (classToday()) buildClassDay(c, out) else buildHomeDay(c, out)
        } catch (e: Exception) {
            out.clear()
            out.add(Block("err", 0, 0, KIND_MISC, "", "", "My Day", "Couldn't build today's plan — pull down and try again."))
        }
        // v10.6: his edits come last, so a retimed or added block lands in the right
        // place — and every consumer (Home, the alarm scheduler) sees the same plan.
        try {
            applyLayout(c, out)
        } catch (e: Exception) {
            // A broken overlay must never cost him the plan itself.
        }
        return out
    }

    /** Hide, retime, rename and add — the overlay Ayush builds by editing blocks. */
    private fun applyLayout(c: Context, out: MutableList<Block>) {
        val hidden = Store.hiddenPlanBlocks(c).map { it.first }.toSet()
        if (hidden.isNotEmpty()) out.removeAll { it.id in hidden }
        for (i in out.indices) {
            val e = Store.planEdit(c, out[i].id) ?: continue
            val b = out[i]
            out[i] = b.copy(
                startMin = e.start.coerceIn(0, 24 * 60),
                endMin = e.end.coerceIn(0, 24 * 60),
                title = e.title.ifBlank { b.title }
            )
        }
        for (cb in Store.planCustom(c)) {
            out.add(Block(cb.id, cb.start, cb.end, KIND_MISC, "", "", cb.title, cb.sub))
        }
        out.sortBy { it.startMin }
    }

    private fun add(out: MutableList<Block>, id: String, s: Int, e: Int, kind: String,
                   subj: String, chapter: String, title: String, sub: String, chip: String = "") {
        out.add(Block(id, s, e, kind, subj, chapter, title, sub, chip))
    }

    // The morning Bio block leads with the subject the user is actually on in
    // coaching (the one with a live pin); with no pin it alternates BOT/ZOO by day
    // parity. The other Bio subject becomes the evening block, so both stay moving.
    private fun hasLivePin(c: Context, subjectKey: String): Boolean {
        val pin = Store.overrideChapter(c, subjectKey)
        return pin >= 0 && !Store.isDone(c, subjectKey, pin)
    }

    private fun bioPair(c: Context): Pair<String, String> {
        val zooPinned = hasLivePin(c, "ZOO")
        val botPinned = hasLivePin(c, "BOT")
        val primary = when {
            zooPinned && !botPinned -> "ZOO"
            botPinned && !zooPinned -> "BOT"
            else -> if ((Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % 2) == 1) "ZOO" else "BOT"
        }
        return primary to if (primary == "ZOO") "BOT" else "ZOO"
    }

    /** Chemistry / Physics card subtitle: today's focus + the real (pin-aware) chapter. */
    private fun workText(c: Context, subjectKey: String, evenDay: String, oddDay: String): String {
        val name = Subjects.byKey(subjectKey)?.name ?: subjectKey
        val a = curChapter(c, subjectKey)
        if (a == null) return "All $name chapters done — pick revision or MCQs."
        val dayEven = (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % 2) == 0
        val act = if (dayEven) evenDay else oddDay
        return "$act — ${a.first + 1}. ${a.second}"
    }

    private fun amBlocks(c: Context, out: MutableList<Block>) {
        val (wH, wM) = Store.wakeHM(c)
        val (eH, eM) = Store.morningEndHM(c)
        var t = wH * 60 + wM
        val end = eH * 60 + eM
        val avail = end - t
        if (avail < 45) return
        val (bioAm, _) = bioPair(c)

        // All three subjects get a guaranteed slot every morning. Biology is weighted
        // (~42%); Chemistry & Physics split the rest evenly. Blocks flex to the window
        // so the last one is never silently dropped on short mornings.
        val gap = if (avail >= 110) 5 else 2
        val work = avail - 2 * gap
        val bioLen = (work * 42 / 100).coerceAtLeast(15)
        val chemLen = ((work - bioLen) / 2).coerceAtLeast(12)
        val phyLen = (work - bioLen - chemLen).coerceAtLeast(12)

        fun slot(id: String, subj: String, len: Int, title: String, sub: String, chip: String = "") {
            val e = (t + len).coerceAtMost(end)
            if (e > t) add(out, id, t, e, KIND_MISC, subj, "", title, sub, chip)
            t = e + gap
        }
        slot("bio_am", bioAm, bioLen, "🧬 Biology", sprintLabel(c, bioAm), "Watch lecture ▸")
        slot("chem_am", "CHEM", chemLen, "⚗️ Chemistry",
            workText(c, "CHEM",
                "Notes + write your own, then DPP practice",
                "DPP practice + revise notes"))
        slot("phy_am", "PHY", phyLen, "⚡ Physics",
            workText(c, "PHY",
                "Theory + formula sheet, then numericals",
                "Numericals + MCQs, mark weak spots"))
    }

    // ============================== Ayush's daily plan ==============================
    // v10.2: the timetable Ayush wrote out himself, pinned to the clock rather than
    // derived from the routine settings. The intelligence stays — the Biology cards
    // still carry the live chapter sprint, the lecture link and any Momentum test
    // date; Chemistry and Physics still name the chapter he's on; the bus and night
    // blocks still open their checklists. Only the windows are fixed now.

    val DAILY_TARGETS = listOf(
        "Physics" to "3 hrs",
        "Chemistry" to "2 – 2.5 hrs",
        "Biology" to "1.5 – 2 hrs",
        "Bus time" to "light revision"
    )

    val DAILY_PRIORITY = listOf(
        "Today's coaching revision",
        "Physics — 3 hours",
        "Chemistry practice",
        "Biology NCERT",
        "DPP / homework",
        "PYQs",
        "Error notebook revision"
    )

    const val DAILY_RULE =
        "Finish today's coaching revision and DPP before starting extra material."

    private fun buildClassDay(c: Context, out: MutableList<Block>) {
        val (bioAm, bioPm) = bioPair(c)
        val odd = (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % 2) == 1
        // The 9:45 weak-topic slot alternates Chemistry and Biology by day, so both
        // get their "go back over what's shaky" time across the week.
        val mixSubj = if (odd) "CHEM" else bioPm
        val mixTitle = if (mixSubj == "CHEM") "⚗️ Chemistry — weak topics" else "🧬 Biology — weak topics"
        val mixSub = if (mixSubj == "CHEM")
            "Weak-topic revision · DPP/PYQs\n" +
                workText(c, "CHEM", "Weakest chapters first", "Mixed DPP, mark what you miss")
        else
            sprintLabel(c, mixSubj) + "\nWeak-topic revision · DPP/PYQs"

        // ── morning ───────────────────────────────────────────────────────────
        add(out, "chem_am", 6 * 60, 7 * 60 + 30, KIND_MISC, "CHEM", "",
            "⚗️ Chemistry",
            "Concepts + coaching revision · DPP/MCQs · PYQs\n" +
                workText(c, "CHEM", "Notes first, then DPP practice", "DPP practice + revise notes"))

        add(out, "breakfast", 7 * 60 + 30, 8 * 60, KIND_MISC, "", "",
            "Breakfast + freshen up", "Eat properly — Biology is next.")

        val bioA = curChapter(c, bioAm)
        add(out, "bio_am", 8 * 60, 9 * 60 + 30, KIND_MISC, bioAm, "",
            if (bioA == null) "🧬 Biology — all chapters done 🎉" else "🧬 Biology",
            sprintLabel(c, bioAm) + "\nNCERT line-by-line · MCQs · important NCERT facts",
            if (bioA == null) "" else "Watch lecture ▸")

        add(out, "break1", 9 * 60 + 30, 9 * 60 + 45, KIND_MISC, "", "",
            "Short break", "Stretch, water, eyes off the screen.")

        add(out, "mix_am", 9 * 60 + 45, 10 * 60 + 45, KIND_MISC, mixSubj, "",
            mixTitle, mixSub, if (mixSubj == "CHEM") "" else "Watch lecture ▸")

        add(out, "lunch", 10 * 60 + 45, 11 * 60 + 30, KIND_MISC, "", "",
            "Get ready + lunch", "Pack bag and notes for coaching.")

        add(out, "leave", 11 * 60 + 30, 12 * 60, KIND_MISC, "", "",
            "Leave for the bus", "Bag, notes, charged phone — the bus is study time.")

        add(out, "bus_out", 12 * 60, 13 * 60, KIND_BUS, "", "",
            "🚌 Bus to Momentum", "Biology NCERT · inorganic Chemistry · formula revision", "Open checklist")

        add(out, "class", 13 * 60, 18 * 60 + 30, KIND_CLASS, "", "", "Momentum class",
            "Focus on concepts · make short notes · mark doubts and important questions", "Class 1:00 – 6:30")

        add(out, "bus_in", 18 * 60 + 30, 19 * 60 + 30, KIND_BUS, "", "",
            "🚌 Bus home", "Light revision or formula revision — rest if you're tired", "Open checklist")

        add(out, "dinner", 19 * 60 + 30, 20 * 60, KIND_MISC, "", "",
            "Dinner + freshen up", "Reset before the Physics push.")

        // ── evening: three Physics blocks, exactly as Ayush laid them out ─────
        add(out, "phy_pm1", 20 * 60, 21 * 60 + 30, KIND_MISC, "PHY", "",
            "⚡ Physics — Session 1",
            "Coaching concept revision · theory · important examples\n" +
                workText(c, "PHY", "Theory + formula sheet", "Coaching concept revision"))

        add(out, "break2", 21 * 60 + 30, 21 * 60 + 45, KIND_MISC, "", "",
            "Short break", "Stand up, water, back in.")

        add(out, "phy_pm2", 21 * 60 + 45, 23 * 60 + 15, KIND_MISC, "PHY", "",
            "⚡ Physics — Session 2",
            "DPP · MCQs · PYQs\n" + workText(c, "PHY", "Numericals + MCQs", "DPP + PYQs"),
            "Open Practice tab")

        add(out, "phy_final", 23 * 60 + 15, 23 * 60 + 30, KIND_MISC, "PHY", "",
            "⚡ Physics — final revision", "Formulas · error notebook · important mistakes")

        add(out, "bed", 23 * 60 + 30, 24 * 60, KIND_BED, "", "",
            "Tonight checklist + sleep", "5 quick ticks, then lights out by 11:30.", "Open checklist")
    }

    private fun buildHomeDay(c: Context, out: MutableList<Block>) {
        // Sunday / coaching off-day: no bus, no class — longer self-study + weekly review.
        val (wH, wM) = Store.wakeHM(c)
        val (cH, cM) = Store.bedCheckHM(c)
        val (bH, bM) = Store.bedHM(c)
        val w = wH * 60 + wM
        add(out, "wake", w, w + 20, KIND_MISC, "", "", "Wake up & get ready", "Full home day — build a big backlog dent.")
        amBlocks(c, out)
        add(out, "review_mid", 10 * 60, 11 * 60, KIND_MISC, "", "", "Weekly review", "Go over last week's notes + mistakes once, fresh eyes.")
        add(out, "mock", 11 * 60, 12 * 60 + 30, KIND_MISC, "", "", "Momentum test / timed practice", "If there's a test today, treat this as exam time.", "Open Practice tab")
        add(out, "lunch", 12 * 60 + 30, 13 * 60 + 30, KIND_MISC, "", "", "Lunch & rest", "Walk, stretch, don't scroll.")
        val (_, bioSunPm) = bioPair(c)
        add(out, "bio_afternoon", 13 * 60 + 30, 15 * 60, KIND_MISC, bioSunPm, "",
            "🧬 Biology — ${Subjects.byKey(bioSunPm)?.name ?: ""}", sprintLabel(c, bioSunPm), "Watch lecture ▸")
        add(out, "chem_pm", 15 * 60, 16 * 60 + 30, KIND_MISC, "CHEM", "", "⚗️ Chemistry", "Weak reactions + notes rework", "")
        add(out, "phy_pm", 16 * 60 + 30, 18 * 60, KIND_MISC, "PHY", "", "⚡ Physics", "Numerical-heavy block — weakest topics", "")
        add(out, "dinner", 18 * 60, 19 * 60, KIND_MISC, "", "", "Dinner & rest", "")
        val (sH, sM) = Store.eveningStartHM(c)
        var t = sH * 60 + sM
        val end = cH * 60 + cM
        if (end - t >= 45) {
            add(out, "practice_sun", t, (t + 50).coerceAtMost(end), KIND_MISC, "", "", "🎯 Big MCQ block", "Clear 80+ questions — full mixed subjects", "Open Practice tab")
        }
        val ck = cH * 60 + cM
        val bed = bH * 60 + bM
        add(out, "bed", ck, ck + 10, KIND_BED, "", "", "Tonight checklist", "5 quick ticks — close the day, feed the streak", "Open checklist")
        add(out, "wind", (ck + 15).coerceAtMost(bed), bed, KIND_SLEEP, "", "", "Wind down & sleep by ${hh(bH, bM)}", "Tomorrow's a fresh grind. 6 hours.")
    }
}
