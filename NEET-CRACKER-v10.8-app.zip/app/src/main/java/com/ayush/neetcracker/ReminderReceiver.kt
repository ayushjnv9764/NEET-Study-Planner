package com.ayush.neetcracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Fires at the study-reminder time, the nightly checklist time, and each plan block start. */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_BEDCHECK = "com.ayush.neetcracker.BEDCHECK"
        const val ACTION_PLAN_BLOCK = "com.ayush.neetcracker.PLAN_BLOCK"
        const val ACTION_PLAN_REFRESH = "com.ayush.neetcracker.PLAN_REFRESH"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_BEDCHECK -> {
                postBedCheck(context)
                return
            }
            ACTION_PLAN_REFRESH -> {
                // 00:05 — arm the new day's plan alerts.
                Alarms.schedulePlan(context)
                return
            }
            ACTION_PLAN_BLOCK -> {
                postPlanBlock(context, intent)
                return
            }
        }
        // Daily study reminder: don't nag if today's study is already logged.
        if (!Store.studiedToday(context)) {
            postStudyReminder(context)
        }
    }

    /** v10.5: "this block starts now" — the whole day's plan, one ping per block. */
    private fun postPlanBlock(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: return
        if (!Store.planAlerts(context)) return
        val body = intent.getStringExtra("body").orEmpty()
        val from = intent.getStringExtra("from").orEmpty()
        val to = intent.getStringExtra("to").orEmpty()
        val window = if (from.isEmpty()) "" else "Starts now · $from – $to"

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        channel(nm, "plan_block", "Plan alerts")

        val openApp = PendingIntent.getActivity(
            context, 3,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = builder(context, "plan_block")
            .setContentTitle(title)
            .setContentText(listOf(window, body).filter { it.isNotEmpty() }.joinToString(" · "))
            .setStyle(Notification.BigTextStyle().bigText(
                listOf(window, body).filter { it.isNotEmpty() }.joinToString("\n")))
            .setContentIntent(openApp)
        nm.notify(100 + intent.getIntExtra("slot", 0), builder.build())
    }

    private fun postStudyReminder(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        channel(nm, "study_reminder", "Study reminder")

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // v10.8: the wording is editable in God Mode, so read it rather than hard-code it.
        val builder = builder(context, "study_reminder")
            .setContentTitle(Store.notifTitle(context))
            .setContentText(Store.notifBody(context))
            .setContentIntent(openApp)
        nm.notify(1, builder.build())
    }

    private fun postBedCheck(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        channel(nm, "bedcheck", "Tonight checklist")

        val openChecklist = PendingIntent.getActivity(
            context, 1,
            Intent(context, ChecklistActivity::class.java).putExtra("mode", "bed"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = builder(context, "bedcheck")
            .setContentTitle("Tonight checklist")
            .setContentText("5 quick ticks before lights out — close your day")
            .setContentIntent(openChecklist)
        nm.notify(2, builder.build())
    }

    private fun channel(nm: NotificationManager, id: String, name: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun builder(context: Context, channelId: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channelId)
        } else {
            @Suppress("deprecation")
            Notification.Builder(context)
        }.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
}
