package com.ayush.neetcracker

import android.content.Context
import java.util.Calendar

/**
 * v8 ANC coach — a tiny OFFLINE rule engine that reads the real Store data
 * (attempts, daily log, streak) and turns it into the "today's priority" a
 * human mentor would name: which chapter is actually weak, why, and what to do.
 * No internet, no API — pure rules over what Ayush already records.
 */
object Coach {

    data class ChapterStat(
        val subject: String,
        val chapter: String,
        val answered: Int,
        val correct: Int
    ) {
        val acc: Int get() = if (answered == 0) -1 else correct * 100 / answered
    }

    /** Per-chapter rollups from the attempt log, busiest chapters first. */
    fun chapterStats(c: Context): List<ChapterStat> {
        val map = LinkedHashMap<Pair<String, String>, IntArray>()
        for (a in Store.attempts(c)) {
            val arr = map.getOrPut(a.subject to a.chapter) { IntArray(2) }
            arr[0]++
            if (a.correct) arr[1]++
        }
        return map.map { (k, v) -> ChapterStat(k.first, k.second, v[0], v[1]) }
            .sortedByDescending { it.answered }
    }

    fun overallAccuracy(c: Context): Int {
        val all = Store.attempts(c)
        if (all.isEmpty()) return -1
        return all.count { it.correct } * 100 / all.size
    }

    /** Questions answered since midnight — matches the Home "today" story. */
    fun attemptsToday(c: Context): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        return Store.attempts(c).count { it.ts >= start }
    }

    /** Chapters clearly underperforming (acc < [band]), worst first, ≤ 3. */
    fun weakList(c: Context, band: Int = 60, min: Int = 3): List<ChapterStat> =
        chapterStats(c).filter { it.answered >= min && it.acc in 0 until band }
            .sortedBy { it.acc }.take(3)

    /** The single chapter to work on: worst of the weak ones, else lowest-acc scored one. */
    fun priority(c: Context, min: Int = 3): ChapterStat? {
        weakList(c, band = 60, min = min).firstOrNull()?.let { return it }
        val scored = chapterStats(c).filter { it.answered >= min }
        return scored.minWithOrNull(compareBy({ it.acc }, { -it.answered }))
    }

    fun bandLabel(acc: Int): String = when {
        acc < 0 -> "—"
        acc < 50 -> "WEAK"
        acc < 70 -> "AVERAGE"
        acc < 85 -> "GOOD"
        else -> "STRONG"
    }

    fun subjectName(key: String): String = Subjects.byKey(key)?.name ?: key

    /** Short human instruction for a chapter's accuracy band. */
    fun recommend(acc: Int): String = when {
        acc < 0 -> "Answer a few questions and I'll find your weak spots."
        acc < 50 -> "Revise the chapter once, then re-drill — this is your fastest mark gain."
        acc < 70 -> "Run a focused re-drill and re-read the ones you miss."
        else -> "Solid. Re-check it with a fresh chapter test to lock it in."
    }

    /** Ids (capped) to launch a chapter drill straight from a coach card. */
    fun drillIds(c: Context, subject: String, chapter: String, cap: Int = 50): List<String> =
        Store.questionBank(c).filter { it.subject == subject && it.chapter == chapter }
            .take(cap).map { it.id }
}
