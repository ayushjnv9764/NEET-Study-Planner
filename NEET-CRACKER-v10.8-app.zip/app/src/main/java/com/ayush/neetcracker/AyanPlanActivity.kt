package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * v8.3 — Ayan's NRTS Real-Test 2027 series, its own clearly-differentiated
 * plan surface (teal identity, "AYAN" naming) so it never mixes with Ayush's
 * Momentum / ELITE plans. Reference calendar: next test with its per-subject
 * syllabus, then every remaining test. No prep ticks — Ayan's prep isn't
 * stored in this app.
 */
class AyanPlanActivity : Activity() {

    private val TEAL = 0xFF00695C.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        if (!AyanSeries.has(this)) {
            root.addView(Ui.text(this, "No NRTS plan loaded yet.", 15f, Ui.color(this, R.color.text_main)))
            setContentView(root)
            return
        }

        // ---- header ----
        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(this, "Ayan · NRTS Plan", 20f, TEAL, true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@AyanPlanActivity, 6)
        })
        root.addView(header)

        val sv = ScrollView(this)
        val list = Ui.column(this)
        val pad = Ui.dp(this, 16)
        list.setPadding(pad, 0, pad, Ui.dp(this, 24))
        sv.addView(list, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val c = this
        list.addView(Ui.text(c, "NRTS Real-Test 2027", 19f, Ui.color(c, R.color.text_main), true))
        list.addView(Ui.text(c, "Ayan's Sunday test series — Dropper NEET real tests", 12f, Ui.color(c, R.color.text_sub)))
        list.addView(Ui.space(c, 8))

        val nxt = AyanSeries.next(c)
        if (nxt != null) {
            list.addView(nextHero(nxt))
            list.addView(Ui.space(c, 8))
        }
        val rest = AyanSeries.upcoming(c).let { if (nxt == null) it else it.drop(1) }
        for (t in rest) list.addView(testRow(t))

        list.addView(Ui.space(c, 8))
        list.addView(Ui.text(c, "Series runs 26 Jul 2026 → 11 Apr 2027 · tests 15-21 are full-syllabus mocks.",
            11f, Ui.color(c, R.color.text_sub)))
        setContentView(root)
    }

    /** Next-test card: big label + countdown + per-subject syllabus. */
    private fun nextHero(t: AyanSeries.Item): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFE4F2F0.toInt(), 16, 0xFF9ECCC5.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        val top = Ui.row(c)
        val left = Ui.column(c)
        left.addView(Ui.text(c, "AYAN · NEXT UP", 11f, Ui.color(c, R.color.text_sub), true))
        left.addView(Ui.text(c, AyanSeries.label(t), 25f, TEAL, true))
        top.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val cd = Ui.text(c, countdown(t.date), 14f, TEAL, true)
        cd.gravity = Gravity.END or Gravity.BOTTOM
        top.addView(cd)
        card.addView(top)
        card.addView(Ui.text(c, humanDate(t.date) + " · " + AyanSeries.scopeLabel(t), 13f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 10))

        if (t.scope == "part") {
            for (slot in MomentumPlan.SLOTS) {
                val chapters = t.chapters(slot)
                if (chapters.isEmpty()) continue
                val sub = MomentumPlan.SLOT_NAME[slot] ?: slot
                val tint = MomentumPlan.SLOT_TINT[slot] ?: 0xFF5C6B7A.toInt()
                val head = Ui.row(c)
                head.gravity = Gravity.CENTER_VERTICAL
                val chip = Ui.text(c, slot, 10f, Color.WHITE, true)
                chip.gravity = Gravity.CENTER
                chip.setPadding(Ui.dp(c, 8), Ui.dp(c, 3), Ui.dp(c, 8), Ui.dp(c, 3))
                chip.background = Ui.cardBg(c, tint, 6)
                chip.minWidth = Ui.dp(c, 44)
                head.addView(chip)
                val st = Ui.text(c, sub, 14f, Ui.color(c, R.color.text_main), true)
                head.addView(st, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = Ui.dp(c, 9)
                })
                card.addView(head)
                card.addView(Ui.space(c, 2))
                for (ch in chapters) {
                    val row = Ui.row(c)
                    row.gravity = Gravity.CENTER_VERTICAL
                    val dot = Ui.text(c, "›", 13f, TEAL, true)
                    dot.setPadding(0, 0, Ui.dp(c, 6), 0)
                    row.addView(dot)
                    row.addView(Ui.text(c, ch, 14f, Ui.color(c, R.color.text_main)))
                    card.addView(row, Ui.margins(0, 2, 0, 0, c))
                }
                card.addView(Ui.space(c, 4))
            }
        } else {
            card.addView(Ui.text(c, if (t.scope == "xi") "Whole Class 11 syllabus — no chapters listed."
                else "Whole NEET syllabus — no chapters listed.", 14f, Ui.color(c, R.color.text_main)))
        }
        return card
    }

    /** Compact row for one coming test: name + date + scope + countdown. */
    private fun testRow(t: AyanSeries.Item): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 11), Ui.dp(c, 14), Ui.dp(c, 11))
        val top = Ui.row(c)
        top.addView(Ui.text(c, AyanSeries.label(t), 15f, TEAL, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Ui.text(c, humanDate(t.date), 13f, Ui.color(c, R.color.text_sub)))
        card.addView(top)
        card.addView(Ui.text(c, AyanSeries.scopeLabel(t), 12f, Ui.color(c, R.color.text_sub)))
        if (t.date >= Store.todayKey()) {
            card.addView(Ui.text(c, countdown(t.date), 12f, Ui.color(c, R.color.accent)))
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = Ui.dp(c, 9)
        card.layoutParams = lp
        return card
    }

    private fun humanDate(date: String): String {
        val cal = Store.parse(date) ?: return date
        return SimpleDateFormat("EEE, d MMM yyyy", Locale.US).format(cal.time)
    }

    private fun countdown(date: String): String {
        val cal = Store.parse(date) ?: return ""
        val label = SimpleDateFormat("d MMM", Locale.US).format(cal.time)
        return when (val d = daysBetween(date)) {
            0 -> "Today — $label"
            1 -> "Tomorrow — $label"
            in 2..Int.MAX_VALUE -> "in $d days — $label"
            else -> label
        }
    }

    private fun daysBetween(date: String): Int {
        val now = Calendar.getInstance()
        now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0); now.set(Calendar.SECOND, 0); now.set(Calendar.MILLISECOND, 0)
        val tm = Store.parse(date) ?: return Int.MIN_VALUE
        tm.set(Calendar.HOUR_OF_DAY, 0); tm.set(Calendar.MINUTE, 0); tm.set(Calendar.SECOND, 0); tm.set(Calendar.MILLISECOND, 0)
        return ((tm.timeInMillis - now.timeInMillis) / 86400000L).toInt()
    }
}
