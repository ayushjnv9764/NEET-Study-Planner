package com.ayush.neetcracker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * Schedules the daily study reminder, the nightly before-bed checklist alarm, and
 * (v10.5) a ping at the start of every block in the day's plan.
 */
object Alarms {

    private const val REQ_REMINDER = 1001
    private const val REQ_BEDCHECK = 1002
    private const val REQ_PLAN_REFRESH = 1003

    // One request code per plan slot — enough for any day the builder can produce.
    private const val PLAN_BASE = 3000
    private const val PLAN_SLOTS = 32

    fun scheduleAll(context: Context) {
        scheduleDaily(context)
        scheduleBedCheck(context)
        schedulePlanRefresh(context)
        schedulePlan(context)
    }

    fun scheduleDaily(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val hour = Store.reminderHour(context)
        val minute = Store.reminderMinute(context)
        val trigger = nextAt(hour, minute)
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            trigger,
            AlarmManager.INTERVAL_DAY,
            pendingIntent(context, REQ_REMINDER, "")
        )
    }

    fun scheduleBedCheck(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val (h, m) = Store.bedCheckHM(context)
        val trigger = nextAt(h, m)
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            trigger,
            AlarmManager.INTERVAL_DAY,
            pendingIntent(context, REQ_BEDCHECK, ReminderReceiver.ACTION_BEDCHECK)
        )
    }

    /**
     * v10.5: one alarm per block of today's plan, armed at that block's start time.
     * Blocks already gone by are skipped — the 00:05 refresher re-arms the whole day,
     * so the plan keeps ticking over even if the app is never opened.
     */
    fun schedulePlan(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until PLAN_SLOTS) {
            am.cancel(planPending(context, i, emptyIntent(context)))
        }
        if (!Store.planAlerts(context)) return

        val blocks = MyDay.build(context)
        val now = Calendar.getInstance()
        for ((i, b) in blocks.withIndex()) {
            if (i >= PLAN_SLOTS) break
            if (b.startMin <= 0 || b.startMin >= 24 * 60) continue
            val at = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, b.startMin / 60)
                set(Calendar.MINUTE, b.startMin % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (at.before(now)) continue

            val body = b.sub.lineSequence().firstOrNull { it.isNotBlank() } ?: ""
            val pi = planPending(context, i, Intent(context, ReminderReceiver::class.java)
                .setAction(ReminderReceiver.ACTION_PLAN_BLOCK)
                .putExtra("slot", i)
                .putExtra("title", b.title)
                .putExtra("body", body)
                .putExtra("from", MyDay.hh(b.startMin / 60, b.startMin % 60))
                .putExtra("to", MyDay.hh((b.endMin.coerceAtMost(24 * 60)) / 60, (b.endMin.coerceAtMost(24 * 60)) % 60)))
            fire(am, at.timeInMillis, pi)
        }
    }

    /**
     * v10.5: 00:05 daily — rebuilds and re-arms that day's plan alerts, so the set
     * survives across days without the app ever being launched.
     */
    fun schedulePlanRefresh(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 5)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent(context, REQ_PLAN_REFRESH, ReminderReceiver.ACTION_PLAN_REFRESH)
        )
    }

    fun reschedule(context: Context) {
        cancel(context)
        scheduleAll(context)
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, REQ_REMINDER, ""))
        am.cancel(pendingIntent(context, REQ_BEDCHECK, ReminderReceiver.ACTION_BEDCHECK))
        am.cancel(pendingIntent(context, REQ_PLAN_REFRESH, ReminderReceiver.ACTION_PLAN_REFRESH))
        for (i in 0 until PLAN_SLOTS) am.cancel(planPending(context, i, emptyIntent(context)))
    }

    /** Exact where the OS allows it, close-enough otherwise — never silently dropped. */
    private fun fire(am: AlarmManager, at: Long, pi: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun emptyIntent(context: Context) =
        Intent(context, ReminderReceiver::class.java).setAction(ReminderReceiver.ACTION_PLAN_BLOCK)

    private fun planPending(context: Context, slot: Int, intent: Intent): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            PLAN_BASE + slot,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun nextAt(hour: Int, minute: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun pendingIntent(context: Context, code: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            code,
            Intent(context, ReminderReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
