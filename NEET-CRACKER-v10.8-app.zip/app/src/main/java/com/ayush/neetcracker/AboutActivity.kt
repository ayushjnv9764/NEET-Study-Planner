package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * About the Developer (v8.19). Ayush's own developer note, rendered like a
 * letter: app icon on top, serif type for the body, vision line centred,
 * signature at the end. Reached by tapping the "About the Developer" icon row
 * at the bottom of the Profile tab. Pure UI — no logic.
 */
class AboutActivity : Activity() {

    private val NAVY = 0xFF0B1233.toInt()
    private val SUB = 0xFF5A6480.toInt()

    private fun serif(text: String, sp: Float, color: Int, bold: Boolean = false, italic: Boolean = false): TextView {
        val tv = Ui.text(this, text, sp, color, false)
        tv.setTypeface(Typeface.create("serif", when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }))
        return tv
    }

    /** Body paragraph with comfortable line spacing. */
    private fun para(text: String): TextView {
        val tv = serif(text, 16f, Ui.color(this, R.color.text_main))
        tv.setLineSpacing(Ui.dp(this, 6).toFloat(), 1.0f)
        tv.textAlignment = TextView.TEXT_ALIGNMENT_TEXT_START
        return tv
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        setContentView(root)

        // top bar
        val bar = Ui.row(this)
        bar.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 2))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        bar.addView(back)
        bar.addView(Ui.heading(this, "About the Developer").apply {
            setTypeface(Typeface.create("serif", Typeface.BOLD))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@AboutActivity, 6)
        })
        root.addView(bar)

        val sv = ScrollView(this)
        val col = Ui.column(this)
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(Ui.dp(this, 26), Ui.dp(this, 10), Ui.dp(this, 26), Ui.dp(this, 32))
        sv.addView(col, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // app icon in a rounded frame
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_app)
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        logo.background = Ui.cardBg(this, 0xFFFFFFFF.toInt(), 26)
        logo.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8))
        val logoWrap = Ui.column(this)
        logoWrap.background = Ui.cardBg(this, 0xFFFFFFFF.toInt(), 26)
        logoWrap.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6))
        logoWrap.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 84)))
        col.addView(logoWrap)

        col.addView(Ui.space(this, 18))
        col.addView(serif("Ayush Kumar Gupta", 24f, NAVY, bold = true))
        col.addView(Ui.space(this, 2))
        col.addView(serif("Developer · Creator of NEET CRACKER", 14f, SUB))

        col.addView(Ui.space(this, 20))
        val rule = Ui.text(this, "———", 14f, Ui.color(this, R.color.text_sub))
        rule.gravity = Gravity.CENTER
        col.addView(rule)
        col.addView(Ui.space(this, 14))

        fun body(text: String) {
            col.addView(para(text))
            col.addView(Ui.space(this, 12))
        }
        body("Greetings. I am Ayush Kumar Gupta, the developer and creator of NEET CRACKER.")
        body("I am a NEET aspirant with a strong interest in technology, education, and the development of practical tools for students. I created NEET CRACKER with the objective of making NEET preparation more structured, efficient, and accessible.")
        body("This application is designed to assist NEET aspirants with chapter-wise practice, previous year questions, revision, planning, testing, and performance enhancement.")
        body("As a student, I am aware of the challenges associated with NEET preparation. Consequently, I am committed to continuously improving NEET CRACKER by incorporating advanced features, a modern user interface, intelligent study tools, and high-quality practice resources.")

        col.addView(Ui.space(this, 6))
        val visionKicker = serif("My Vision", 12f, Ui.color(this, R.color.primary), bold = true)
        visionKicker.gravity = Gravity.CENTER
        col.addView(visionKicker)
        col.addView(Ui.space(this, 4))
        val vision = serif("Learn. Practice. Revise. Analyze. Crack NEET.", 18f, NAVY, bold = true, italic = true)
        vision.gravity = Gravity.CENTER
        vision.setLineSpacing(Ui.dp(this, 3).toFloat(), 1.0f)
        col.addView(vision)

        col.addView(Ui.space(this, 20))
        val thanks = serif("Thank you for utilizing NEET CRACKER.", 17f, Ui.color(this, R.color.text_main), italic = true)
        thanks.gravity = Gravity.CENTER
        thanks.setLineSpacing(Ui.dp(this, 4).toFloat(), 1.0f)
        col.addView(thanks)

        col.addView(Ui.space(this, 24))
        val sign = serif("Developed with dedication by Ayush Kumar Gupta", 15f, NAVY, bold = true)
        sign.gravity = Gravity.CENTER
        sign.setLineSpacing(Ui.dp(this, 4).toFloat(), 1.0f)
        sign.textAlignment = TextView.TEXT_ALIGNMENT_CENTER
        col.addView(sign)
        col.addView(Ui.space(this, 2))
        val signSub = serif("Creator of NEET CRACKER", 13f, SUB)
        signSub.gravity = Gravity.CENTER
        col.addView(signSub)
    }
}
