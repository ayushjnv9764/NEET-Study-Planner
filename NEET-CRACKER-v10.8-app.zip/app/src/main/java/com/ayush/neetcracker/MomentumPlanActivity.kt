package com.ayush.neetcracker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * v8.1 — the full Momentum course flow for Ayush's own batch (CNR-1).
 * Shows where the course stands today (Day N + this day's four chapters),
 * the class days coming up, and the PT/MT tests Momentum has scheduled.
 */
class MomentumPlanActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        if (!MomentumPlan.has(this)) {
            root.addView(Ui.text(this, "No Momentum plan loaded yet.", 15f, Ui.color(this, R.color.text_main)))
            setContentView(root)
            return
        }

        // ---- header ----
        val header = Ui.row(this)
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = Ui.text(this, "Plan + Test Series", 20f, Ui.color(this, R.color.text_main), true)
        title.setTypeface(null, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@MomentumPlanActivity, 6)
        })
        root.addView(header)

        val sv = ScrollView(this)
        val list = Ui.column(this)
        val pad = Ui.dp(this, 16)
        list.setPadding(pad, 0, pad, Ui.dp(this, 24))
        sv.addView(list, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val c = this
        val today = MomentumPlan.today(c)
        val anchor = MomentumPlan.anchor(c)

        // ---- today's position card ----
        val todayCard = Ui.column(c)
        todayCard.background = Ui.cardBg(c, 0xFFFFF3E0.toInt(), 16, 0xFFE3C58F.toInt())
        todayCard.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        todayCard.addView(Ui.text(c, "MOMENTUM · CNR-1", 12f, 0xFFB26A00.toInt(), true))
        todayCard.addView(
            Ui.text(
                c, "Ambition (NEET)-260 · Gorakhpur — your coaching timetable",
                12f, Ui.color(c, R.color.text_sub)
            )
        )
        todayCard.addView(Ui.space(c, 12))

        if (anchor != null) {
            val line1 = Ui.row(c)
            line1.gravity = Gravity.BOTTOM
            val big = Ui.text(c, "Day ${anchor.day}", 34f, 0xFF9A4A00.toInt(), true)
            line1.addView(big)
            val of = Ui.text(c, " of ${MomentumPlan.planDays(c)}", 15f, Ui.color(c, R.color.text_sub), true)
            of.setPadding(0, 0, 0, Ui.dp(c, 6))
            line1.addView(of)
            todayCard.addView(line1)
            todayCard.addView(Ui.space(c, 2))
            todayCard.addView(Ui.text(c, humanDate(anchor.date) + (if (anchor.date == Store.todayKey()) " — today" else ""),
                14f, Ui.color(c, R.color.text_main), true))
        }

        if (today != null && today.kind == "test") {
            todayCard.addView(Ui.text(c, "📍 Test day — ${today.label}", 15f, 0xFFB26A00.toInt(), true))
        } else if (today != null && today.kind == "holiday") {
            todayCard.addView(Ui.text(c, "🌴 No class today — off day", 15f, 0xFFB26A00.toInt(), true))
        } else if (anchor != null) {
            todayCard.addView(Ui.space(c, 8))
            todayCard.addView(Ui.text(c, "What Momentum teaches today", 12f, Ui.color(c, R.color.text_sub), true))
            for (slot in MomentumPlan.SLOTS) {
                val topic = anchor.topic(slot)
                if (topic == "-") continue
                subjectLine(todayCard, slot, topic)
            }
        }
        list.addView(todayCard)
        list.addView(Ui.space(c, 14))

        // ---- ELITE test series: next test + your prep for it ----
        if (EliteSeries.has(c)) eliteSection(list)

        // ---- upcoming class days ----
        val up = MomentumPlan.nextClassDays(c, 10)
        if (up.isNotEmpty() && up.first().date > Store.todayKey()) {
            list.addView(Ui.text(c, "Coming up in class", 18f, Ui.color(c, R.color.text_main), true))
            list.addView(Ui.space(c, 4))
            for (row in up) list.addView(classDayCard(row))
            list.addView(Ui.space(c, 14))
        }

        // ---- scheduled tests ----
        val tests = MomentumPlan.nextTests(c, 6)
        if (tests.isNotEmpty()) {
            list.addView(Ui.text(c, "Tests on your plan", 18f, Ui.color(c, R.color.text_main), true))
            list.addView(Ui.space(c, 4))
            for (t in tests) list.addView(testCard(t))
            list.addView(Ui.space(c, 14))
        }

        list.addView(
            Ui.text(
                c, "Day 1 = 10 Jul 2026 · Sunday off · sourced from your Momentum CNR-1 timetable",
                11f, Ui.color(c, R.color.text_sub)
            )
        )
        setContentView(root)
    }

    // ============================== v8.2 ELITE test series ==============================

    /** Next-test hero + every coming test of the ELITE Sunday series. */
    private fun eliteSection(list: LinearLayout) {
        val c = this
        list.addView(Ui.text(c, "Your test series · ELITE NEET-2027", 19f, Ui.color(c, R.color.text_main), true))
        list.addView(Ui.text(c, "28 tests, every Sunday — your prep for the next one", 12f, Ui.color(c, R.color.text_sub)))
        list.addView(Ui.space(c, 8))
        val nxt = EliteSeries.next(c)
        if (nxt != null) {
            list.addView(nextTestHero(nxt))
            list.addView(Ui.space(c, 6))
        }
        val rest = EliteSeries.upcoming(c).let { if (nxt == null) it else it.drop(1) }
        for (t in rest) list.addView(eliteRow(t))
        if (rest.isEmpty() && nxt != null) {
            list.addView(Ui.text(c, "That's the last test in the series.", 13f, Ui.color(c, R.color.text_sub)))
        }
        list.addView(Ui.space(c, 6))
        list.addView(Ui.text(c, "Runs 23 Aug 2026 → 24 Apr 2027 · first 3 were 23 Aug, 6 Sep, 20 Sep.",
            11f, Ui.color(c, R.color.text_sub)))
        list.addView(Ui.space(c, 14))
    }

    /** Big card for the next test: label + countdown + per-subject prep ticks. */
    private fun nextTestHero(t: EliteSeries.Item): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFF4EFFD.toInt(), 16, 0xFFCFC2F2.toInt())
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        val top = Ui.row(c)
        val left = Ui.column(c)
        left.addView(Ui.text(c, "NEXT UP", 11f, Ui.color(c, R.color.text_sub), true))
        left.addView(Ui.text(c, EliteSeries.label(t), 25f, 0xFF4A2BA8.toInt(), true))
        top.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val cd = Ui.text(c, countdown(t.date), 14f, 0xFF4A2BA8.toInt(), true)
        cd.gravity = Gravity.END or Gravity.BOTTOM
        top.addView(cd)
        card.addView(top)
        card.addView(Ui.text(c, EliteSeries.sub(t), 12f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.space(c, 12))

        val prep = EliteSeries.prepFor(c, t)
        if (prep.isNotEmpty()) {
            card.addView(Ui.text(c, "Your prep for this test", 12f, Ui.color(c, R.color.text_sub), true))
            card.addView(Ui.space(c, 2))
            for (sp in prep) addSlotPrep(card, sp)
        }
        return card
    }

    /** One subject of a test's syllabus: header with x/y done + a tick line per chapter. */
    private fun addSlotPrep(card: LinearLayout, sp: EliteSeries.SlotPrep) {
        val c = this
        val head = Ui.row(c)
        head.gravity = Gravity.CENTER_VERTICAL
        val tint = MomentumPlan.SLOT_TINT[sp.slot] ?: 0xFF5C6B7A.toInt()
        val chip = Ui.text(c, sp.slot, 10f, Color.WHITE, true)
        chip.gravity = Gravity.CENTER
        chip.setPadding(Ui.dp(c, 8), Ui.dp(c, 3), Ui.dp(c, 8), Ui.dp(c, 3))
        chip.background = Ui.cardBg(c, tint, 6)
        chip.minWidth = Ui.dp(c, 44)
        head.addView(chip)
        val subName = MomentumPlan.SLOT_NAME[sp.slot] ?: sp.slot
        val allDone = sp.total > 0 && sp.done == sp.total
        val headColor = if (allDone) 0xFF1B8A3A.toInt() else Ui.color(c, R.color.text_main)
        val statusTxt = if (sp.total > 0) "$subName — ${sp.done} of ${sp.total} done"
            else if (sp.preps.isNotEmpty()) "$subName — topics set"
            else "$subName"
        val st = Ui.text(c, statusTxt, 14f, headColor, true)
        head.addView(st, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 9)
        })
        card.addView(head)
        card.addView(Ui.space(c, 2))
        for (p in sp.preps) {
            val row = Ui.row(c)
            row.gravity = Gravity.CENTER_VERTICAL
            val mark = if (!p.tracked) "•" else if (p.done) "✓" else "○"
            val mcol = when {
                !p.tracked -> 0xFFC9CED7.toInt()
                p.done -> 0xFF1B8A3A.toInt()
                else -> 0xFF9AA0AA.toInt()
            }
            val g = Ui.text(c, mark, 15f, mcol, true)
            g.gravity = Gravity.CENTER
            g.minWidth = Ui.dp(c, 22)
            row.addView(g)
            val nm = Ui.text(c, p.name + if (!p.tracked) "  ·  not on your tracker yet" else "", 14f,
                Ui.color(c, R.color.text_main))
            row.addView(nm, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 6)
            })
            card.addView(row, Ui.margins(0, 2, 0, 0, c))
        }
        card.addView(Ui.space(c, 6))
    }

    /** Compact row for one upcoming series test. */
    private fun eliteRow(t: EliteSeries.Item): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFF3EFFF.toInt(), 14, 0xFFC9BBF5.toInt())
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 11), Ui.dp(c, 14), Ui.dp(c, 11))
        val top = Ui.row(c)
        top.addView(Ui.text(c, EliteSeries.label(t), 15f, 0xFF5B3FC4.toInt(), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Ui.text(c, humanDate(t.date), 13f, Ui.color(c, R.color.text_sub)))
        card.addView(top)
        card.addView(Ui.text(c, EliteSeries.sub(t), 12f, Ui.color(c, R.color.text_sub)))
        card.addView(Ui.text(c, countdown(t.date), 12f, Ui.color(c, R.color.accent)))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = Ui.dp(c, 9)
        card.layoutParams = lp
        return card
    }

    /** Compact upcoming-class-day card: day number + date + the four topics inline. */
    private fun classDayCard(row: MomentumPlan.Row): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
        val top = Ui.row(c)
        val left = Ui.column(c)
        left.addView(Ui.text(c, "Day ${row.day}", 15f, Ui.color(c, R.color.primary), true))
        left.addView(Ui.text(c, humanDate(row.date), 12f, Ui.color(c, R.color.text_sub)))
        top.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(top)
        card.addView(Ui.space(c, 6))
        for (slot in MomentumPlan.SLOTS) {
            val t = row.topic(slot)
            if (t == "-") continue
            subjectLine(card, slot, t)
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = Ui.dp(this@MomentumPlanActivity, 10)
        card.layoutParams = lp
        return card
    }

    private fun testCard(t: MomentumPlan.Row): LinearLayout {
        val c = this
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFF3EFFF.toInt(), 14, 0xFFC9BBF5.toInt())
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
        val head = Ui.row(c)
        head.addView(Ui.text(c, t.label, 15f, 0xFF5B3FC4.toInt(), true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.text(c, humanDate(t.date), 13f, Ui.color(c, R.color.text_sub)))
        card.addView(head)
        card.addView(Ui.text(c, countdown(t.date), 13f, Ui.color(c, R.color.accent)))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = Ui.dp(c, 10)
        card.layoutParams = lp
        return card
    }

    /** Small colored subject chip + its topic text on one line. */
    private fun subjectLine(container: LinearLayout, slot: String, topic: String) {
        val c = this
        val row = Ui.row(c)
        val tint = MomentumPlan.SLOT_TINT[slot] ?: 0xFF5C6B7A.toInt()
        val chip = Ui.text(c, slot, 10f, Color.WHITE, true)
        chip.gravity = Gravity.CENTER
        chip.setPadding(Ui.dp(c, 7), Ui.dp(c, 3), Ui.dp(c, 7), Ui.dp(c, 3))
        chip.background = Ui.cardBg(c, tint, 6)
        chip.minWidth = Ui.dp(c, 40)
        row.addView(chip)
        val tv = Ui.text(c, topic, 14f, Ui.color(c, R.color.text_main))
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 10)
        })
        container.addView(row, Ui.margins(0, 4, 0, 0, c))
    }

    private fun humanDate(date: String): String {
        val cal = Store.parse(date) ?: return date
        return SimpleDateFormat("EEE, d MMM yyyy", Locale.US).format(cal.time)
    }

    private fun countdown(date: String): String {
        val cal = Store.parse(date) ?: return ""
        val label = SimpleDateFormat("d MMM", Locale.US).format(cal.time)
        return when (val d = daysBetween(date)) {
            0 -> "Today — $label"
            1 -> "Tomorrow — $label"
            in 2..Int.MAX_VALUE -> "in $d days — $label"
            else -> label
        }
    }

    private fun daysBetween(date: String): Int {
        val now = Calendar.getInstance()
        now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0); now.set(Calendar.SECOND, 0); now.set(Calendar.MILLISECOND, 0)
        val tm = Store.parse(date) ?: return Int.MIN_VALUE
        tm.set(Calendar.HOUR_OF_DAY, 0); tm.set(Calendar.MINUTE, 0); tm.set(Calendar.SECOND, 0); tm.set(Calendar.MILLISECOND, 0)
        return ((tm.timeInMillis - now.timeInMillis) / 86400000L).toInt()
    }
}
