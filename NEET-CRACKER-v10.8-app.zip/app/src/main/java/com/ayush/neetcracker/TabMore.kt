package com.ayush.neetcracker

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

object TabPractice {

    fun build(host: MainActivity): ScrollView {
        val (sv, col) = tabScroll2(host)
        val c = host

        // ---- page intro (design spec §8) ----
        col.addView(Ui.text(c, "Practice", 22f, Ui.color(c, R.color.text_main), true))
        col.addView(Ui.text(c, "Improve your performance — question by question", 13f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 14))

        // ---- quick practice: one-tap 10 / 25 / 50 rounds (mixed subjects) ----
        col.addView(Ui.text(c, "QUICK PRACTICE", 11f, Ui.color(c, R.color.text_sub), true))
        col.addView(Ui.space(c, 8))
        val quick = Ui.row(c)
        col.addView(quick, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 84)))
        quickRound(quick, c, "10 MCQs") { randomRound(c, host, 10) }
        quickRound(quick, c, "25 MCQs") { randomRound(c, host, 25) }
        quickRound(quick, c, "50 MCQs") { randomRound(c, host, 50) }
        col.addView(Ui.space(c, 2))

        // ---- summary numbers (computed once; shared by the hero and the strip) ----
        val all = Store.attempts(c)
        val attempted = all.size
        val correct = all.count { it.correct }
        val acc = if (attempted == 0) -1 else correct * 100 / attempted
        val mistakes = Store.mistakes(c)
        val bookmarks = Store.bookmarks(c).size
        val todayKey = Store.todayKey()
        val today = all.filter { Store.fmt(java.util.Date(it.ts)) == todayKey }
        val todayAcc = if (today.isEmpty()) -1 else today.count { it.correct } * 100 / today.size
        val reviseDue = Store.revisionDue(c).size
        val weekday = java.text.SimpleDateFormat("EEEE", Locale.US).format(java.util.Date())

        // ---- v9.9 hero: where today stands, before the wall of cards ----
        val hero = Ui.column(c)
        hero.background = Ui.cardBg(c, Ui.color(c, R.color.primary), 18)
        hero.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14))
        val htop = Ui.row(c)
        htop.gravity = Gravity.CENTER_VERTICAL
        htop.addView(Ui.text(c, "TODAY", 11f, 0xCCFFFFFF.toInt(), true))
        htop.addView(android.view.View(c), LinearLayout.LayoutParams(0, 1, 1f))
        htop.addView(Ui.text(c, weekday, 12f, 0xCCFFFFFF.toInt()))
        hero.addView(htop)
        hero.addView(Ui.space(c, 10))
        val hrow = Ui.row(c)
        heroCell(hrow, c, "${today.size}", "answered today")
        heroCell(hrow, c, if (todayAcc < 0) "—" else "$todayAcc%", "accuracy today")
        heroCell(hrow, c, "$reviseDue", "to revise")
        hero.addView(hrow)
        if (today.isEmpty()) {
            hero.addView(Ui.space(c, 8))
            hero.addView(Ui.text(c, "Nothing logged yet today — start with a quick round below.", 12f, 0xCCFFFFFF.toInt()))
        }
        col.addView(hero, Ui.margins(0, 0, 0, 16, c))

        // ---- all-time strip ----
        sect(col, c, "ALL TIME")
        col.card2(c) {
            val row = Ui.row(c)
            addView(row)
            stat(row, c, "$attempted", "answered")
            stat(row, c, if (acc < 0) "—" else "$acc%", "accuracy")
            stat(row, c, "${mistakes.size}", "mistakes")
            stat(row, c, "$bookmarks", "saved")
        }

        // ---- revision centre (v8.27) + question filters (v8.28) ----
        sect(col, c, "REVISE & DRILL")
        hubCard(
            col, c, "R", Ui.color(c, R.color.primary), "Revision centre",
            if (reviseDue == 0) "Nothing waiting — you're all clear"
            else "$reviseDue questions waiting to be revised"
        ) { host.startPlain(RevisionActivity::class.java) }
        hubCard(
            col, c, "F", 0xFF5B3FC4.toInt(), "Question filters",
            "Pick a subject, a chapter and how many — build your own round"
        ) { host.startPlain(FiltersActivity::class.java) }

        // ---- PYQ hub (v9.2 §11) + NEET mock (full exam feel) ----
        sect(col, c, "PAPERS & MOCKS")
        hubCard(
            col, c, "P", 0xFFB26A00.toInt(), "Past Year Papers",
            "Year-wise full papers + chapter-wise past questions"
        ) { host.startPlain(PyqActivity::class.java) }
        hubCard(
            col, c, "▶", 0xFF00695C.toInt(), "NEET Mock Test",
            "full exam feel · +4 correct · −1 wrong · timed · no hints"
        ) { host.startPlain(ExamActivity::class.java) }

        // ---- custom practice ----
        val counts = intArrayOf(10, 25, 50)
        var subjIdx = 0
        var countIdx = 0
        fun chipView(row: LinearLayout, label: String, onPick: () -> Unit) {
            val t = Ui.text(c, label, 13f, Ui.color(c, R.color.text_main), true)
            t.gravity = Gravity.CENTER
            t.setPadding(Ui.dp(c, 10), Ui.dp(c, 9), Ui.dp(c, 10), Ui.dp(c, 9))
            t.background = Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
            t.setOnClickListener { onPick() }
            Ui.clickable(c, t)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (row.childCount > 0) lp.marginStart = Ui.dp(c, 8)
            row.addView(t, lp)
        }
        fun setSel(v: android.view.View, sel: Boolean) {
            val tv = v as TextView
            tv.background = if (sel) Ui.cardBg(c, Ui.color(c, R.color.primary), 10)
            else Ui.cardBg(c, 0xFFEAF1EC.toInt(), 10)
            tv.setTextColor(if (sel) Color.WHITE else Ui.color(c, R.color.text_main))
        }
        fun repaint(row: LinearLayout, sel: Int) {
            for (k in 0 until row.childCount) setSel(row.getChildAt(k), k == sel)
        }
        val subjRow = Ui.row(c)
        for ((si, s) in Subjects.ALL.withIndex()) chipView(subjRow, s.key) {
            subjIdx = si; repaint(subjRow, subjIdx)
        }
        repaint(subjRow, 0)
        val cntRow = Ui.row(c)
        for ((ci, n) in counts.withIndex()) chipView(cntRow, "$n") {
            countIdx = ci; repaint(cntRow, countIdx)
        }
        repaint(cntRow, 0)

        sect(col, c, "BUILD A ROUND")
        col.card2(c) {
            addView(Ui.text(c, "Custom practice", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 2))
            addView(Ui.text(c, "build your own round — pick a subject and length", 13f, Ui.color(c, R.color.text_sub)))
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "SUBJECT", 11f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.space(c, 6))
            addView(subjRow)
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "QUESTIONS", 11f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.space(c, 6))
            addView(cntRow)
            addView(Ui.space(c, 12))
            val go = Ui.button(c, "START PRACTICE", true)
            go.setOnClickListener {
                val key = Subjects.ALL[subjIdx].key
                val n = counts[countIdx]
                val ids = Store.questionBank(c).filter { it.subject == key }
                    .shuffled().take(n).joinToString(",") { it.id }
                if (ids.isEmpty()) Ui.toast(c, "No questions in this subject's bank yet")
                else host.startSub(QuizActivity::class.java, "ids", ids)
            }
            addView(go)
        }

        // ---- review your errors ----
        sect(col, c, "FIX YOUR ERRORS")
        col.card2(c) {
            addView(Ui.text(c, "Review your errors", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 8))
            bigAction(c, this, "Mistake book", "${mistakes.size} questions to redo") {
                host.startSub(ReviewActivity::class.java, "mode", "mistakes")
            }
            bigAction(c, this, "Bookmarks", "$bookmarks questions you saved") {
                host.startSub(ReviewActivity::class.java, "mode", "bookmarks")
            }
            if (mistakes.isNotEmpty()) {
                bigAction(c, this, "Drill my mistakes", "Practice only the wrong ones again") {
                    host.startSub(QuizActivity::class.java, "ids", mistakes.joinToString(",") { it.qid })
                }
            }
        }

        col.addView(Ui.text(c, "Pick a subject", 16f, Ui.color(c, R.color.text_main), true))
        col.addView(Ui.space(c, 6))
        for (s in Subjects.ALL) {
            subjectCard(c, col, host, s)
        }

        col.addView(Ui.space(c, 4))
        col.addView(Ui.text(c, "More question packs land without updating the app — Import is in Profile.", 13f, Ui.color(c, R.color.text_sub)))
        return sv
    }

    /** One large quick-practice tile (10/25/50) — mixed-subject random round. */
    private fun quickRound(row: LinearLayout, c: MainActivity, label: String, onClick: () -> Unit) {
        val b = Ui.column(c)
        b.background = Ui.cardBg(c, 0xFFF2EFFC.toInt(), 14)
        b.setPadding(Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12))
        b.gravity = Gravity.CENTER
        b.addView(Ui.text(c, label, 15f, 0xFF5B3FC4.toInt(), true))
        b.addView(Ui.text(c, "mixed subjects", 10f, Ui.color(c, R.color.text_sub)))
        b.setOnClickListener { onClick() }
        Ui.clickable(c, b)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        if (row.childCount > 0) lp.marginStart = Ui.dp(c, 8)
        row.addView(b, lp)
    }

    /** Pull N random questions from the whole bank and start a drill. */
    private fun randomRound(c: MainActivity, host: MainActivity, n: Int) {
        val bank = Store.questionBank(c)
        if (bank.isEmpty()) {
            Ui.toast(c, "No questions yet — import a pack from Profile")
            return
        }
        val ids = bank.shuffled().take(n).joinToString(",") { it.id }
        host.startSub(QuizActivity::class.java, "ids", ids)
    }

    private fun stat(row: LinearLayout, c: android.content.Context, big: String, label: String) {
        val v = Ui.column(c)
        v.gravity = Gravity.CENTER
        v.addView(Ui.text(c, big, 22f, Ui.color(c, R.color.primary), true))
        v.addView(Ui.text(c, label, 12f, Ui.color(c, R.color.text_sub)))
        row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    /** v9.9 — small-caps section label that groups the card list into readable blocks. */
    private fun sect(col: LinearLayout, c: android.content.Context, label: String) {
        col.addView(Ui.text(c, label, 11f, Ui.color(c, R.color.text_sub), true).apply {
            setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 8))
        })
    }

    /** v9.9 — one white-on-primary big number + caption inside the today hero. */
    private fun heroCell(row: LinearLayout, c: android.content.Context, big: String, label: String) {
        val v = Ui.column(c)
        v.addView(Ui.text(c, big, 24f, Color.WHITE, true))
        v.addView(Ui.text(c, label, 11f, 0xCCFFFFFF.toInt()))
        row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    /** v9.9 — hub row with a colour chip, mirroring the subject tiles, so the list scans. */
    private fun hubCard(
        col: LinearLayout, c: MainActivity,
        chip: String, chipBg: Int, title: String, sub: String,
        onClick: () -> Unit
    ) {
        col.card2(c) {
            val rr = Ui.row(c)
            rr.gravity = Gravity.CENTER_VERTICAL
            addView(rr)
            val ch = Ui.text(c, chip, 14f, Color.WHITE, true)
            ch.gravity = Gravity.CENTER
            ch.background = Ui.cardBg(c, chipBg, 16)
            rr.addView(ch, LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34)))
            val l = Ui.column(c)
            l.addView(Ui.text(c, title, 16f, Ui.color(c, R.color.text_main), true))
            l.addView(Ui.text(c, sub, 13f, Ui.color(c, R.color.text_sub)))
            rr.addView(l, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 12)
            })
            rr.addView(Ui.text(c, "›", 24f, Ui.color(c, R.color.primary)))
            setOnClickListener { onClick() }
            Fx.press(this)
        }
    }

    private fun bigAction(c: android.content.Context, container: LinearLayout, title: String, sub: String, onClick: () -> Unit) {
        val card = Ui.column(c)
        card.background = Ui.cardBg(c, 0xFFEAF4EE.toInt(), 12)
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
        card.addView(Ui.text(c, title, 15f, Ui.color(c, R.color.primary), true))
        card.addView(Ui.text(c, sub, 13f, Ui.color(c, R.color.text_sub)))
        card.setOnClickListener { onClick() }
        Ui.clickable(c, card)
        container.addView(card, Ui.margins(0, 0, 0, 8, c))
    }

    private fun subjectCard(c: android.content.Context, container: LinearLayout, host: MainActivity, s: Subject) {
        val total = Store.questionBank(c).count { it.subject == s.key }
        val answered = Store.answeredCount(c, s.key)
        val a = Store.accuracy(c, s.key)
        val accent = subjAccent(c, s.key)

        // premium tile (spec §10-11): monogram chip + live drill stats, mirroring Home/Study
        val tile = Ui.column(c)
        tile.background = Ui.cardBg(c, subjFill(s.key), 16)
        tile.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12))
        container.addView(tile, Ui.margins(0, 0, 0, 10, c))

        val top = Ui.row(c)
        tile.addView(top)
        val chip = Ui.text(c, subjLetter(s.key), 15f, accent, true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(c, Color.WHITE, 18)
        top.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))
        val mid = Ui.column(c)
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(Ui.text(c, s.name, 16f, Ui.color(c, R.color.text_main), true))
        val sub = if (answered == 0) "$total questions ready"
        else "$total questions · $answered answered · " + (if (a < 0) "—" else "$a% accuracy")
        mid.addView(Ui.text(c, sub, 12f, Ui.color(c, R.color.text_sub)))
        top.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 12)
        })
        top.addView(Ui.text(c, "›", 20f, accent))

        // whole tile = full-subject drill (big tap target, rule 2)
        tile.setOnClickListener { host.startSub(QuizActivity::class.java, "subject", s.key) }
        Fx.press(tile)

        // v8.11: quick random round — whole-subject drills can run 100+, so offer a ~3 min warm-up
        if (total >= 10) {
            tile.addView(Ui.space(c, 8))
            val strip = Ui.row(c)
            strip.background = Ui.cardBg(c, Color.WHITE, 10)
            strip.setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8))
            strip.addView(Ui.text(c, "⚡ Quick 10 — random mix across chapters", 12f, accent, true))
            strip.setOnClickListener {
                val ids = Store.questionBank(c).filter { it.subject == s.key }
                    .shuffled().take(10).joinToString(",") { it.id }
                host.startSub(QuizActivity::class.java, "ids" to ids, "subject" to s.key)
            }
            Ui.clickable(c, strip)
            tile.addView(strip)
        }
    }
}

object TabProgress {

    fun build(host: MainActivity): ScrollView {
        val (sv, col) = tabScroll2(host)
        val c = host

        // ---- page intro (design spec §12) ----
        col.addView(Ui.text(c, "Your Progress", 22f, Ui.color(c, R.color.text_main), true))
        col.addView(Ui.text(c, "every chapter, question and minute — at a glance", 13f, Ui.color(c, R.color.text_sub)))
        col.addView(Ui.space(c, 14))

        // ---- main card: overall preparation ----
        val totalCh = Subjects.totalChapters.coerceAtLeast(1)
        val doneCh = Store.totalDone(c)
        val overallFrac = doneCh.toFloat() / totalCh
        val main = Ui.column(c)
        main.background = Ui.cardBg(c)
        main.setPadding(Ui.dp(c, 18), Ui.dp(c, 16), Ui.dp(c, 18), Ui.dp(c, 18))
        main.addView(Ui.text(c, "OVERALL PREPARATION", 11f, Ui.color(c, R.color.text_sub), true))
        main.addView(Ui.space(c, 2))
        main.addView(Ui.text(c, "${(overallFrac * 100).toInt()}%", 46f, Ui.color(c, R.color.primary), true))
        main.addView(Ui.text(c, "$doneCh of $totalCh chapters complete", 13f, Ui.color(c, R.color.text_sub)))
        main.addView(Ui.space(c, 12))
        val track = LinearLayout(c)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(c, 0xFFE4EBE7.toInt(), 7)
        val fill = android.view.View(c)
        fill.background = Ui.cardBg(c, Ui.color(c, R.color.primary), 7)
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(c, 12), overallFrac.coerceIn(0f, 1f)))
        main.addView(track, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 12)))
        fill.pivotX = 0f
        fill.scaleX = 0f
        fill.animate().scaleX(1f).setInterpolator(android.view.animation.DecelerateInterpolator(1.4f))
            .setDuration(600).setStartDelay(80).start()
        col.addView(main, Ui.margins(0, 0, 0, 12, c))

        // ---- stats grid: questions / accuracy / tests / study hours ----
        val attemptsAll = Store.attempts(c)
        val accAll = if (attemptsAll.isEmpty()) -1 else attemptsAll.count { it.correct } * 100 / attemptsAll.size
        val mocksTaken = Store.mockHistory(c).size
        val studyH = Store.totalMinutesAll(c) / 60
        val g1 = Ui.row(c)
        col.addView(g1)
        statTile(g1, c, "📗", "${attemptsAll.size}", "questions solved", 0xFFEAF1F8.toInt())
        statTile(g1, c, "🎯", if (accAll < 0) "—" else "$accAll%", "accuracy", 0xFFFFF3E0.toInt())
        val g2 = Ui.row(c)
        col.addView(g2, Ui.margins(0, 10, 0, 0, c))
        statTile(g2, c, "🏁", "$mocksTaken", "mock tests", 0xFFEDEAF7.toInt())
        statTile(g2, c, "⏱", "${studyH}h", "study time", 0xFFE7F3EC.toInt())
        col.addView(Ui.space(c, 2))

        // ---- weak topics (v9.0): the lowest-accuracy chapters, drillable ----
        val practised = Coach.chapterStats(c).filter { it.answered > 0 }
        val worst = practised.minWithOrNull(compareBy({ it.acc }, { -it.answered }))
        col.card2(c) {
            addView(Ui.text(c, "Weak topics", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 4))
            addView(
                Ui.text(
                    c,
                    if (worst == null) "Practise a few chapters and this names exactly what is dragging your score."
                    else "Lowest right now: ${worst.chapter} · ${worst.acc}% — tap to see them all and drill.",
                    13f, Ui.color(c, R.color.text_sub)
                )
            )
            addView(Ui.space(c, 12))
            val b = Ui.button(c, "Open weak topics", true)
            b.gravity = Gravity.CENTER
            b.setOnClickListener { host.startPlain(WeakTopicsActivity::class.java) }
            addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 46)))
        }

        // ---- subject progress ----
        col.card2(c) {
            addView(Ui.text(c, "Subject progress", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 10))
            for (s in Subjects.ALL) {
                val total = s.chapters.size.coerceAtLeast(1)
                val done = Store.doneCount(c, s.key)
                val frac = done.toFloat() / total
                val accent = subjAccent(c, s.key)
                val top = Ui.row(c)
                top.addView(Ui.text(c, s.name, 15f, Ui.color(c, R.color.text_main), true),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                top.addView(Ui.text(c, "${(frac * 100).toInt()}%", 15f, accent, true))
                addView(top)
                addView(Ui.space(c, 3))
                val st = LinearLayout(c)
                st.orientation = LinearLayout.HORIZONTAL
                st.weightSum = 1f
                st.background = Ui.cardBg(c, 0xFFE4EBE7.toInt(), 5)
                val sf = android.view.View(c)
                sf.background = Ui.cardBg(c, accent, 5)
                st.addView(sf, LinearLayout.LayoutParams(0, Ui.dp(c, 8), frac.coerceIn(0f, 1f)))
                addView(st, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 8)))
                addView(Ui.space(c, 9))
            }
        }

        // ---- this week ----
        col.card2(c) {
            addView(Ui.text(c, "This week", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 6))
            var weekMin = 0
            var todayMin = 0
            for (s in Store.getSessions(c)) {
                val diff = daysBetweenNow(s.date)
                if (diff == 0) todayMin += s.durMin
                if (diff in 0..6) weekMin += s.durMin
            }
            addView(Ui.text(c, "Today: ${todayMin / 60}h ${todayMin % 60}m", 14f, Ui.color(c, R.color.text_main)))
            addView(Ui.text(c, "Last 7 days: ${weekMin / 60}h ${weekMin % 60}m", 14f, Ui.color(c, R.color.text_sub)))
        }

        // ---- question accuracy + mistakes ----
        col.card2(c) {
            addView(Ui.text(c, "Question practice", 16f, Ui.color(c, R.color.text_main), true))
            addView(Ui.space(c, 6))
            val all = Store.attempts(c)
            val overall = if (all.isEmpty()) "—" else "${all.count { it.correct } * 100 / all.size}%"
            accRow(this, c, "Overall", overall)
            for (s in Subjects.ALL) {
                addView(Ui.space(c, 4))
                val a = Store.accuracy(c, s.key)
                accRow(this, c, s.name, if (a < 0) "—" else "$a%")
            }
            addView(Ui.space(c, 8))
            addView(Ui.text(c, "${Store.mistakes(c).size} questions in your mistake book", 13f, Ui.color(c, R.color.text_sub)))
            val mocks = Store.mockHistory(c)
            addView(
                Ui.text(
                    c,
                    if (mocks.isEmpty()) "Run a NEET Mock from the Practice tab — +4/−1, timed, no hints."
                    else "Mocks: ${mocks.size} taken · best +${Store.bestMock(c)} marks (NEET scoring)",
                    13f, Ui.color(c, R.color.text_sub)
                )
            )
        }
        return sv
    }

    private fun accRow(container: LinearLayout, c: android.content.Context, label: String, value: String) {
        val r = Ui.row(c)
        r.addView(Ui.text(c, label, 14f, Ui.color(c, R.color.text_main)))
        val v = Ui.text(c, value, 14f, Ui.color(c, R.color.primary), true)
        v.gravity = Gravity.END
        r.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 12)
        })
        container.addView(r)
    }

    /** One mini stat tile in the analytics grid — echoes Home's quick-action language. */
    private fun statTile(row: LinearLayout, c: android.content.Context, emoji: String, big: String, label: String, fill: Int) {
        val t = Ui.column(c)
        t.background = Ui.cardBg(c, fill, 16)
        t.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 12))
        val head = Ui.row(c)
        t.addView(head)
        val chip = Ui.text(c, emoji, 14f, Color.BLACK)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(c, Color.WHITE, 16)
        head.addView(chip, LinearLayout.LayoutParams(Ui.dp(c, 30), Ui.dp(c, 30)))
        head.addView(Ui.text(c, big, 19f, Ui.color(c, R.color.text_main), true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(c, 10)
            })
        val lb = Ui.text(c, label, 11f, Ui.color(c, R.color.text_sub))
        t.addView(lb, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(c, 2)
        })
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        if (row.childCount > 0) lp.marginStart = Ui.dp(c, 8)
        row.addView(t, lp)
    }

    private fun stat(row: LinearLayout, c: android.content.Context, big: String, label: String) {
        val v = Ui.column(c)
        v.gravity = Gravity.CENTER
        v.addView(Ui.text(c, big, 20f, Ui.color(c, R.color.primary), true))
        v.addView(Ui.text(c, label, 11f, Ui.color(c, R.color.text_sub)))
        row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun daysBetweenNow(dateKey: String): Int {
        val cal = Store.parse(dateKey) ?: return 999
        val now = Calendar.getInstance()
        val a = Calendar.getInstance().apply {
            timeInMillis = cal.timeInMillis
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val b = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return ((b.timeInMillis - a.timeInMillis) / 86400000L).toInt()
    }
}

object TabSettings {

    fun build(host: MainActivity): ScrollView {
        val (sv, col) = tabScroll2(host)
        val c = host

        // v10.0 — the hero's numbers are derived once and reused by both stat rows.
        val sylDone = Subjects.ALL.sumOf { s -> s.chapters.indices.count { Store.isDone(c, s.key, it) } }
        val sylTotal = Subjects.ALL.sumOf { it.chapters.size }
        val sylFrac = if (sylTotal > 0) sylDone.toFloat() / sylTotal else 0f
        val at = Store.attempts(c)
        val qAsked = at.size
        val qAcc = if (qAsked > 0) at.count { it.correct } * 100 / qAsked else -1

        // profile identity hero (v8.9)
        val hero = Ui.column(c)
        hero.background = Fx.gradient(0xFF3D2B9F.toInt(), 0xFF7B2FF7.toInt())
        hero.setPadding(Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 16))
        val top = Ui.row(c)
        // v8.23: profile picture = Ayush's own photo (circular), matching Home.
        val avatar = android.widget.ImageView(c)
        avatar.setImageResource(R.mipmap.user_pic)
        avatar.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        avatar.background = Ui.cardBg(c, 0x55FFFFFF.toInt(), 30)
        val avaParams = LinearLayout.LayoutParams(Ui.dp(c, 60), Ui.dp(c, 60))
        top.addView(avatar, avaParams)
        val info = Ui.column(c)
        info.addView(Ui.text(c, Store.name(c), 22f, Color.WHITE, true))
        info.addView(Ui.space(c, 2))
        info.addView(Ui.text(c, "NEET ${Store.examDate(c).take(4)} aspirant", 13f, 0xFFD9E2FF.toInt()))
        top.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 14)
        })
        hero.addView(top)
        hero.addView(Ui.space(c, 14))
        val stats = Ui.row(c)
        fun heroStat(container: LinearLayout, big: String, label: String) {
            val s = Ui.column(c)
            s.gravity = Gravity.CENTER
            s.addView(Ui.text(c, big, 19f, Color.WHITE, true))
            s.addView(Ui.text(c, label, 11f, 0xFFB9C6FF.toInt()))
            container.addView(s, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        heroStat(stats, "${Store.daysToExam(c)}", "days to go")
        heroStat(stats, "${Store.streak(c)}", "day streak")
        heroStat(stats, "${Store.totalMinutesAll(c) / 60}h", "study time")
        hero.addView(stats)

        // v10.0 — syllabus progress on the hero, then a second row of live counters.
        hero.addView(Ui.space(c, 14))
        val sylRow = Ui.row(c)
        sylRow.addView(
            Ui.text(c, "SYLLABUS", 10.5f, 0xFFB9C6FF.toInt(), true).apply { letterSpacing = 0.08f },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val sylPct = Ui.text(c, "${(sylFrac * 100).toInt()}%", 12.5f, Color.WHITE, true)
        sylPct.gravity = Gravity.END
        sylRow.addView(sylPct)
        hero.addView(sylRow)
        hero.addView(Ui.space(c, 6))
        val sylTrack = LinearLayout(c)
        sylTrack.orientation = LinearLayout.HORIZONTAL
        sylTrack.weightSum = 1f // lone weighted child renders at [sylFrac], not full width
        sylTrack.background = Ui.cardBg(c, 0x33FFFFFF.toInt(), 5)
        val sylFill = android.view.View(c)
        // translucent white on purpose: the hero is a fixed violet gradient, so no dark mapping
        sylFill.background = Ui.cardBg(c, 0xF2FFFFFF.toInt(), 5)
        sylTrack.addView(sylFill, LinearLayout.LayoutParams(0, Ui.dp(c, 8), sylFrac.coerceIn(0f, 1f)))
        hero.addView(sylTrack, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 8)))
        hero.addView(Ui.space(c, 14))
        val stats2 = Ui.row(c)
        heroStat(stats2, "$sylDone/$sylTotal", "chapters done")
        heroStat(stats2, "$qAsked", "questions")
        heroStat(stats2, if (qAcc < 0) "—" else "$qAcc%", "accuracy")
        hero.addView(stats2)

        col.addView(hero, Ui.margins(0, 0, 0, 12, c))

        // account & preferences
        col.card2(c) {
            addView(Ui.text(c, "ACCOUNT & GOALS", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 4))
            row(this, c, "Your name", Store.name(c)) {
                val input = EditText(c)
                input.setText(Store.name(c))
                AlertDialog.Builder(c)
                    .setTitle("Your name")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ -> Store.setName(c, input.text.toString()); host.refresh() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            row(this, c, "Daily goals", goalSummary(c)) { editGoals(host) }
            row(this, c, "NEET exam date", Store.examLabel(c)) { pickExamDate(host) }
            row(this, c, "Daily reminder", Store.timeHM(Store.reminderHour(c), Store.reminderMinute(c))) { pickReminder(host) }
        }

        col.card2(c) {
            addView(Ui.text(c, "MY DAY ROUTINE", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 2))
            val wh = Store.wakeHM(c); val am = Store.morningEndHM(c)
            val pm = Store.eveningStartHM(c); val ck = Store.bedCheckHM(c)
            addView(Ui.text(c, "My Day reshapes around these times.", 12f, Ui.color(c, R.color.text_sub)))
            addView(Ui.space(c, 2))
            row(this, c, "Wake up", Store.timeHM(wh.first, wh.second)) {
                pickTime(host, "Wake up", wh.first, wh.second) { h, m -> Store.setWake(c, h, m) }
            }
            row(this, c, "Morning study until", Store.timeHM(am.first, am.second)) {
                pickTime(host, "Morning study until", am.first, am.second) { h, m -> Store.setMorningEnd(c, h, m) }
            }
            row(this, c, "Evening study starts", Store.timeHM(pm.first, pm.second)) {
                pickTime(host, "Evening study starts", pm.first, pm.second) { h, m -> Store.setEveningStart(c, h, m) }
            }
            row(this, c, "Night checklist", Store.timeHM(ck.first, ck.second)) {
                pickTime(host, "Night checklist", ck.first, ck.second) { h, m ->
                    Store.setBedCheck(c, h, m)
                    Alarms.reschedule(c)
                }
            }
            val alertRow = Ui.row(c)
            alertRow.setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
            alertRow.addView(
                Ui.text(c, "Plan start alerts", 15f, Ui.color(c, R.color.text_main)),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            val alertSw = Switch(c)
            alertSw.isChecked = Store.planAlerts(c)
            alertSw.setOnCheckedChangeListener { _, on ->
                Store.setPlanAlerts(c, on)
                Alarms.reschedule(c)
                host.toast(if (on) "Alerts on — a ping at every block start" else "Plan alerts off")
            }
            alertRow.addView(alertSw)
            addView(alertRow)
            addView(Ui.text(c, "A notification at the start of every block in today's plan.", 12f, Ui.color(c, R.color.text_sub)))

            // ---- v10.6: the plan itself is editable ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "EDIT THE PLAN", 12f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 2))
            addView(Ui.text(c, "Tap Edit on any block in Today's plan to retime it, rename it or hide it.", 12f, Ui.color(c, R.color.text_sub)))
            row(this, c, "Add a plan block", "New") { host.addPlanBlock() }
            val hiddenBlocks = Store.hiddenPlanBlocks(c)
            if (hiddenBlocks.isNotEmpty()) {
                row(this, c, "Hidden blocks", "${hiddenBlocks.size} hidden") { host.restoreHiddenPlanBlocks() }
            }
            if (Store.hasPlanEdits(c)) {
                row(this, c, "Reset plan", "My timetable", danger = true) { host.resetPlan() }
            }
        }

        col.card2(c) {
            val tests = Store.momentumTests(c).sortedBy { it.date }
            val testHead = Ui.row(c)
            testHead.addView(
                Ui.text(c, "MOMENTUM TESTS", 13f, Ui.color(c, R.color.primary), true),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            if (tests.isNotEmpty()) {
                val cnt = Ui.text(c, "${tests.size} scheduled", 12f, Ui.color(c, R.color.text_sub), true)
                cnt.gravity = Gravity.END
                testHead.addView(cnt)
            }
            addView(testHead)
            addView(Ui.space(c, 4))
            addView(Ui.text(c, "Coaching test dates — My Day shows each deadline so you finish the chapter before its test.", 12f, Ui.color(c, R.color.text_sub)))
            addView(Ui.space(c, 6))
            if (tests.isEmpty()) {
                addView(Ui.text(c, "No tests added yet — add your next one.", 14f, Ui.color(c, R.color.text_sub)))
            } else {
                for ((i, t) in tests.withIndex()) {
                    val sub = Subjects.byKey(t.subject)
                    val nm = sub?.name ?: t.subject
                    val ch = sub?.chapters?.getOrNull(t.chapter) ?: "Chapter ${t.chapter + 1}"
                    val label = "$nm · $ch · ${prettyTestDate(t.date)}"
                    row(this, c, label, "✕", chevron = false) {
                        AlertDialog.Builder(c)
                            .setTitle("Remove this test?")
                            .setMessage(label)
                            .setPositiveButton("Remove") { _, _ ->
                                val l = Store.momentumTests(c).toMutableList()
                                l.removeAt(i)
                                Store.setMomentumTests(c, l)
                                host.refresh()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            }
            addView(Ui.space(c, 6))
            val addRow = Ui.row(c)
            addRow.background = Ui.cardBg(c, 0xFFEAF4EE.toInt(), 12)
            addRow.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
            addRow.addView(Ui.text(c, "＋ Add Momentum test", 15f, Ui.color(c, R.color.primary), true))
            addRow.setOnClickListener { addMomentumFlow(host) }
            Ui.clickable(c, addRow)
            this.addView(addRow)
        }

        col.card2(c) {
            addView(Ui.text(c, "BIOLOGY LECTURES", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 4))
            addView(Ui.text(c, "Botany + Zoology one-shot series linked to every Bio sprint day — tap “Watch lecture” on a Biology card.", 13f, Ui.color(c, R.color.text_sub)))
        }

        col.card2(c) {
            addView(Ui.text(c, "DATA", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 4))
            addView(
                Ui.text(
                    c,
                    "${Store.questionBank(c).size} questions in your bank — all of it lives on this phone.",
                    12f, Ui.color(c, R.color.text_sub)
                )
            )
            addView(Ui.space(c, 4))
            row(this, c, "Import question pack", "add MCQs from a file") { host.openQuestionPackPicker() }
        }

        // ============================== v10.7 god mode ==============================
        // A hidden panel behind Ayush's code: colours, the plan, the test calendar and
        // the whole question bank. Everything in it is reversible — each section keeps
        // its own reset, and nothing here touches the shipped assets.
        col.addView(Ui.space(c, 8))
        godCard(host, col)

        // v10.0 — the destructive action gets its own red-framed card, apart from
        // the everyday rows, so it can never be tapped by accident mid-scroll.
        val dangerInk = Theme.ink(c, 0xFFE0524D.toInt())
        val dangerCard = Ui.column(c)
        dangerCard.background = Ui.cardBg(c, 0xFFFBEFF3.toInt(), 14, dangerInk)
        dangerCard.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 4))
        dangerCard.addView(
            Ui.text(c, "DANGER ZONE", 12.5f, dangerInk, true).apply { letterSpacing = 0.06f }
        )
        dangerCard.addView(Ui.space(c, 2))
        dangerCard.addView(
            Ui.text(c, "Clears your progress but keeps your name and exam date.", 12f, Ui.color(c, R.color.text_sub))
        )
        row(dangerCard, c, "Reset all progress", "", danger = true) {
            AlertDialog.Builder(c)
                .setTitle("Reset everything?")
                .setMessage("This clears your tasks, chapters, sessions, targets, streak, question answers, bookmarks and imported question packs. Your name and exam date are kept.")
                .setPositiveButton("Reset") { _, _ ->
                    Store.reset(c)
                    host.toast("All progress cleared")
                    host.refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        col.addView(dangerCard, Ui.margins(0, 0, 0, 12, c))

        col.card2(c) {
            addView(Ui.text(c, "THEME", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 4))
            addView(Ui.text(c, "The dark palette is easier on the eyes in low light — try it before bed.", 12f, Ui.color(c, R.color.text_sub)))
            addView(Ui.space(c, 2))
            val r = Ui.row(c)
            r.setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
            r.addView(Ui.text(c, "Dark mode", 15f, Ui.color(c, R.color.text_main)),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val sw = Switch(c)
            sw.isChecked = Theme.isDark(c)
            sw.setOnCheckedChangeListener { _, on -> Theme.setDark(c, on); host.recreate() }
            r.addView(sw)
            addView(r)
        }

        // About the Developer — icon row that opens Ayush's note in an elegant letter layout.
        col.addView(Ui.space(c, 8))
        val aboutCard = Ui.column(c)
        aboutCard.background = Ui.cardBg(c, 0xFFF3EFFF.toInt(), 16)
        aboutCard.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
        val aboutRow = Ui.row(c)
        val appIcon = ImageView(c)
        appIcon.setImageResource(R.mipmap.ic_app)
        appIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        appIcon.background = Ui.cardBg(c, 0xFFFFFFFF.toInt(), 18)
        appIcon.setPadding(Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3))
        aboutRow.addView(appIcon, LinearLayout.LayoutParams(Ui.dp(c, 46), Ui.dp(c, 46)))
        val aboutTxt = Ui.column(c)
        aboutTxt.addView(Ui.text(c, "About the Developer", 15f, Ui.color(c, R.color.text_main), true))
        aboutTxt.addView(Ui.text(c, "Learn. Practice. Revise. Analyze. Crack NEET.", 11f, Ui.color(c, R.color.text_sub)))
        aboutRow.addView(aboutTxt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(c, 12)
        })
        val chev = Ui.text(c, "›", 22f, Ui.color(c, R.color.text_sub), true)
        chev.gravity = Gravity.CENTER_VERTICAL
        aboutRow.addView(chev, LinearLayout.LayoutParams(Ui.dp(c, 20), LinearLayout.LayoutParams.WRAP_CONTENT))
        aboutCard.addView(aboutRow)
        aboutCard.setOnClickListener {
            c.startActivity(Intent(c, AboutActivity::class.java))
        }
        Ui.clickable(c, aboutCard)
        col.addView(aboutCard, Ui.margins(0, 0, 0, 4, c))

        // v10.0 — screen-wide footer so the installed version is always checkable.
        col.addView(Ui.space(c, 12))
        val ver = Ui.text(c, "NEET CRACKER · v10.8 · BY AYUSH", 11.5f, Ui.color(c, R.color.text_sub))
        ver.gravity = Gravity.CENTER
        col.addView(ver)
        return sv
    }

    private fun goalSummary(c: android.content.Context): String {
        val g = Store.goals(c)
        return "${g.min / 60}h · ${g.q}q · ${g.r}r"
    }

    private fun editGoals(host: MainActivity) {
        val c = host
        val g = Store.goals(c)
        val col = Ui.column(c)
        fun field(hint: String, init: Int): EditText {
            val et = EditText(c)
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setHint(hint)
            et.setText("$init")
            col.addView(et, Ui.margins(0, 0, 0, 6, c))
            return et
        }
        val h = field("Study hours per day", g.min / 60)
        val q = field("Questions per day", g.q)
        val r = field("Revision tasks per day", g.r)
        val ch = field("Chapters per day", g.ch)
        val lec = field("Lectures per day", g.lec)
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 12), Ui.dp(c, 24), 0)
        AlertDialog.Builder(c)
            .setTitle("Daily goals")
            .setView(col)
            .setPositiveButton("Save") { _, _ ->
                Store.setGoals(
                    c,
                    h.text.toString().toIntOrNull() ?: 6,
                    q.text.toString().toIntOrNull() ?: 80,
                    r.text.toString().toIntOrNull() ?: 3,
                    ch.text.toString().toIntOrNull() ?: 2,
                    lec.text.toString().toIntOrNull() ?: 2
                )
                host.refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickExamDate(host: MainActivity) {
        val c = host
        val parts = Store.examDate(c).split("-")
        var y = parts.getOrNull(0)?.toIntOrNull() ?: 2027
        var m = (parts.getOrNull(1)?.toIntOrNull() ?: 5) - 1
        var d = parts.getOrNull(2)?.toIntOrNull() ?: 2
        DatePickerDialog(c, { _, yy, mm, dd ->
            val cal = Calendar.getInstance()
            cal.set(yy, mm, dd)
            Store.setExamDate(c, Store.fmt(cal.time))
            host.toast("NEET date updated")
            host.refresh()
        }, y, m, d).show()
    }

    private fun prettyTestDate(date: String): String {
        val cal = Store.parse(date)
        return if (cal != null) java.text.SimpleDateFormat("d MMM", Locale.US).format(cal.time) else date
    }

    /** Subject → chapter → date pickers; appends a Momentum test. */
    private fun addMomentumFlow(host: MainActivity) {
        val c = host
        val subs = Subjects.ALL
        AlertDialog.Builder(c)
            .setTitle("Which subject?")
            .setItems(subs.map { it.name }.toTypedArray()) { _, which ->
                val sub = subs[which]
                AlertDialog.Builder(c)
                    .setTitle("${sub.name} — which chapter is being tested?")
                    .setItems(sub.chapters.toTypedArray()) { _, ch ->
                        val cal = Calendar.getInstance()
                        cal.add(Calendar.DAY_OF_YEAR, 7) // sensible default: next week
                        DatePickerDialog(c, { _, yy, mm, dd ->
                            val t = Calendar.getInstance()
                            t.set(yy, mm, dd)
                            Store.addMomentumTest(c, sub.key, ch, Store.fmt(t.time))
                            Ui.toast(c, "Test added — My Day will show its deadline")
                            host.refresh()
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickReminder(host: MainActivity) {
        val c = host
        TimePickerDialog(c, { _, hh, mm ->
            Store.setReminderTime(c, hh, mm)
            Alarms.reschedule(c)
            host.toast("Daily reminder set to ${Store.timeHM(hh, mm)}")
            host.refresh()
        }, Store.reminderHour(c), Store.reminderMinute(c), true).show()
    }

    private fun pickTime(host: MainActivity, title: String, h: Int, m: Int, onSet: (Int, Int) -> Unit) {
        val c = host
        TimePickerDialog(c, { _, hh, mm ->
            onSet(hh, mm)
            host.toast("$title set to ${Store.timeHM(hh, mm)}")
            host.refresh()
        }, h, m, true).show()
    }

    // ============================== v10.7 god mode ==============================

    private val SWATCHES = listOf(
        0xFF0E7A4C.toInt(), 0xFF17A86F.toInt(), 0xFF00897B.toInt(), 0xFF2F6FB2.toInt(),
        0xFF3949AB.toInt(), 0xFF6C5CE7.toInt(), 0xFF9C27B0.toInt(), 0xFFB03A5B.toInt(),
        0xFFE0524D.toInt(), 0xFFE08A00.toInt(), 0xFFB8860B.toInt(), 0xFF2E7D32.toInt(),
        0xFF5C6B7A.toInt(), 0xFF11161A.toInt(), 0xFFF2F4F3.toInt(), 0xFF0B1410.toInt()
    )

    private val OVR_LABELS = mapOf(
        "primary" to "Accent", "accent" to "Highlight", "bg" to "Background",
        "card" to "Cards", "text_main" to "Main text", "text_sub" to "Sub text"
    )

    private var godDialog: AlertDialog? = null

    private fun resIdOf(slot: String): Int = when (slot) {
        "primary" -> R.color.primary
        "accent" -> R.color.accent
        "bg" -> R.color.bg
        "card" -> R.color.card
        "text_main" -> R.color.text_main
        else -> R.color.text_sub
    }

    /** Reload the tab after a god-mode change; the plan moved, so re-arm the alarms. */
    private fun afterGod(host: MainActivity, msg: String) {
        Alarms.reschedule(host)
        host.refresh()
        host.toast(msg)
    }

    private fun godCard(host: MainActivity, col: LinearLayout) {
        val c = host
        if (!Store.godUnlocked(c)) {
            col.card2(c) {
                addView(Ui.text(c, "DEVELOPER SETTINGS", 13f, Ui.color(c, R.color.primary), true))
                addView(Ui.space(c, 2))
                addView(Ui.text(c, "A hidden panel: recolour the whole app, resize the text, round the cards, reword the reminder, rewrite questions, reshape the plan and the test calendar.", 12f, Ui.color(c, R.color.text_sub)))
                row(this, c, "Unlock with your code", "locked") { askGodCode(host) }
            }
            return
        }

        col.card2(c) {
            addView(Ui.text(c, "GOD MODE", 13f, Ui.color(c, R.color.primary), true))
            addView(Ui.space(c, 2))
            addView(Ui.text(c, "Everything here is reversible — every section has its own reset.", 12f, Ui.color(c, R.color.text_sub)))

            // ---- colours ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "COLOURS", 11.5f, Ui.color(c, R.color.text_sub), true))
            for (slot in Theme.OVR_SLOTS) swatchRow(this, c, host, slot)
            if (Theme.overrides.isNotEmpty()) {
                row(this, c, "Reset colours", "", danger = true) {
                    Theme.clearOverrides(c)
                    host.recreate()
                }
            }

            // ---- size & shape (v10.8) ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "SIZE & SHAPE", 11.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.text(c, "One dial for every label in the app, one for how round the cards are.", 12f, Ui.color(c, R.color.text_sub)))
            choiceRow(this, c, host, "Text size", TEXT_STEPS, Theme.textScale) { v ->
                Theme.setTextScale(c, v)
                host.recreate()
            }
            choiceRow(this, c, host, "Card roundness", RADIUS_STEPS, Theme.radiusScale) { v ->
                Theme.setRadiusScale(c, v)
                host.recreate()
            }
            if (Theme.textScale != 1f || Theme.radiusScale != 1f) {
                row(this, c, "Reset size & shape", "", danger = true) {
                    Theme.clearScale(c)
                    host.recreate()
                }
            }

            // ---- notifications (v10.8) ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "NOTIFICATIONS", 11.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.text(c, "The daily study reminder is yours to word. Block-start pings read the block itself, so they follow the plan.", 12f, Ui.color(c, R.color.text_sub)))
            row(this, c, "Reminder title", ellipsis(Store.notifTitle(c))) {
                editTextDialog(c, "Reminder title", Store.notifTitle(c), Store.DEFAULT_NOTIF_TITLE) { v ->
                    Store.setNotifTitle(c, v)
                    host.refresh()
                    host.toast(if (v.isBlank()) "Reminder title back to default" else "Reminder title set")
                }
            }
            row(this, c, "Reminder second line", ellipsis(Store.notifBody(c))) {
                editTextDialog(c, "Reminder second line", Store.notifBody(c), Store.DEFAULT_NOTIF_BODY) { v ->
                    Store.setNotifBody(c, v)
                    host.refresh()
                    host.toast(if (v.isBlank()) "Second line back to default" else "Second line set")
                }
            }
            if (Store.hasNotifText(c)) {
                row(this, c, "Reset the reminder wording", "", danger = true) {
                    Store.resetNotifText(c)
                    host.refresh()
                    host.toast("Reminder wording reset")
                }
            }

            // ---- plan ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "PLAN", 11.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.text(c, "Any block can be retimed, renamed or hidden — the Edit button sits on every card in Today's plan.", 12f, Ui.color(c, R.color.text_sub)))
            row(this, c, "Add a plan block", "") { host.addPlanBlock() }
            if (Store.hiddenPlanBlocks(c).isNotEmpty()) {
                row(this, c, "Restore a hidden block", "${Store.hiddenPlanBlocks(c).size} hidden") { host.restoreHiddenPlanBlocks() }
            }
            if (Store.hasPlanEdits(c)) {
                row(this, c, "Reset the plan", "My timetable", danger = true) { host.resetPlan() }
            }

            // ---- tests ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "MOMENTUM TESTS", 11.5f, Ui.color(c, R.color.text_sub), true))
            val tests = Store.momentumTests(c)
            row(this, c, "Edit a test", "${tests.size} scheduled") { pickTestToEdit(host) }
            if (tests.isNotEmpty()) {
                row(this, c, "Clear the test calendar", "", danger = true) {
                    AlertDialog.Builder(c)
                        .setTitle("Clear every test?")
                        .setMessage("Removes all ${tests.size} Momentum test dates. Your plan and questions are untouched.")
                        .setPositiveButton("Clear") { _, _ ->
                            Store.clearMomentumTests(c)
                            afterGod(host, "Test calendar cleared")
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }

            // ---- questions ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "QUESTIONS", 11.5f, Ui.color(c, R.color.text_sub), true))
            addView(Ui.text(c, "Rewrite any question in your bank, remove one, or write your own. Questions inside PYQ papers stay read-only.", 12f, Ui.color(c, R.color.text_sub)))
            row(this, c, "Edit a question", "subject › chapter › pick") { pickQuestion(host) }
            row(this, c, "Write a new question", "subject › chapter") { writeQuestion(host) }
            val touched = Store.questionEdits(c).size + Store.deletedQuestionIds(c).size
            if (touched > 0) {
                row(this, c, "Reset question edits", "$touched changed", danger = true) {
                    AlertDialog.Builder(c)
                        .setTitle("Put every question back?")
                        .setMessage("Drops your question edits and brings back everything you removed.")
                        .setPositiveButton("Reset") { _, _ ->
                            Store.resetQuestionEdits(c)
                            host.refresh()
                            host.toast("Questions restored")
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }

            // ---- reset everything (v10.8) ----
            addView(Ui.space(c, 10))
            addView(Ui.text(c, "RESET", 11.5f, Ui.color(c, R.color.text_sub), true))
            row(this, c, "Reset all developer settings", "colours · size · plan · questions", danger = true) {
                AlertDialog.Builder(c)
                    .setTitle("Put everything back?")
                    .setMessage("Colours, text size, card roundness, plan edits, question edits and the reminder wording all return to how the app shipped. Your Momentum test calendar is left exactly as it is.")
                    .setPositiveButton("Reset all") { _, _ ->
                        Store.resetAllGod(c)
                        host.recreate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            // ---- lock ----
            addView(Ui.space(c, 10))
            row(this, c, "Lock developer settings", "", danger = true) {
                Store.setGodUnlocked(c, false)
                host.refresh()
                host.toast("God mode off")
            }
        }
    }

    private fun askGodCode(host: MainActivity) {
        val c = host
        val input = EditText(c)
        input.setHint("Code")
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        val box = Ui.column(c)
        box.setPadding(Ui.dp(c, 20), Ui.dp(c, 8), Ui.dp(c, 20), 0)
        box.addView(input)
        AlertDialog.Builder(c)
            .setTitle("Developer code")
            .setView(box)
            .setPositiveButton("Unlock") { _, _ ->
                if (Store.godCodeOk(input.text.toString())) {
                    Store.setGodUnlocked(c, true)
                    host.refresh()
                    host.toast("God mode on")
                } else {
                    host.toast("Wrong code")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- v10.8: size, shape and the reminder wording ----

    private val TEXT_STEPS = listOf(0.9f to "Compact", 1f to "Normal", 1.1f to "Large", 1.2f to "Huge")
    private val RADIUS_STEPS = listOf(0.4f to "Square", 1f to "Normal", 1.8f to "Round")

    private fun labelOf(steps: List<Pair<Float, String>>, v: Float): String =
        steps.firstOrNull { it.first == v }?.second ?: steps[1].second

    /** A labelled row that opens a one-choice picker — the shape of every v10.8 dial. */
    private fun choiceRow(
        container: LinearLayout, c: MainActivity, host: MainActivity, label: String,
        steps: List<Pair<Float, String>>, current: Float, onPick: (Float) -> Unit
    ) {
        val r = Ui.row(c)
        r.setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
        r.addView(Ui.text(c, label, 15f, Ui.color(c, R.color.text_main)),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.text(c, labelOf(steps, current), 12.5f, Ui.color(c, R.color.text_sub)))
        r.setOnClickListener {
            AlertDialog.Builder(c)
                .setTitle(label)
                .setSingleChoiceItems(steps.map { it.second }.toTypedArray(),
                    steps.indexOfFirst { it.first == current }) { d, which ->
                    onPick(steps[which].first)
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        Ui.clickable(c, r)
        container.addView(r)
    }

    private fun ellipsis(s: String, n: Int = 26): String =
        if (s.length <= n) s else s.take(n - 1).trimEnd() + "…"

    /** Free-text editor. "Default" saves an empty value, which is how the app's own text comes back. */
    private fun editTextDialog(c: MainActivity, title: String, value: String, hint: String, onSave: (String) -> Unit) {
        val input = EditText(c)
        input.setHint(hint)
        input.setText(value)
        input.setSingleLine()
        val box = Ui.column(c)
        box.setPadding(Ui.dp(c, 20), Ui.dp(c, 8), Ui.dp(c, 20), 0)
        box.addView(input)
        AlertDialog.Builder(c)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Save") { _, _ -> onSave(input.text.toString()) }
            .setNeutralButton("Default") { _, _ -> onSave("") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun swatchRow(container: LinearLayout, c: MainActivity, host: MainActivity, slot: String) {
        val r = Ui.row(c)
        r.setPadding(0, Ui.dp(c, 10), 0, Ui.dp(c, 10))
        r.addView(Ui.text(c, OVR_LABELS[slot] ?: slot, 15f, Ui.color(c, R.color.text_main)),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val custom = Theme.overrideOf(c, slot)
        val dot = View(c)
        dot.background = Ui.cardBg(c, custom ?: Theme.color(c, resIdOf(slot)), 20, 0x33000000)
        r.addView(dot, LinearLayout.LayoutParams(Ui.dp(c, 26), Ui.dp(c, 26)))
        r.addView(Ui.text(c, if (custom == null) "   default" else "   custom", 11.5f, Ui.color(c, R.color.text_sub)))
        r.setOnClickListener { pickColour(host, slot) }
        Ui.clickable(c, r)
        container.addView(r)
    }

    private fun pickColour(host: MainActivity, slot: String) {
        val c = host
        val box = Ui.column(c)
        val pad = Ui.dp(c, 16)
        box.setPadding(pad, Ui.dp(c, 10), pad, 0)
        var line = Ui.row(c)
        for ((i, colour) in SWATCHES.withIndex()) {
            if (i > 0 && i % 5 == 0) {
                box.addView(line)
                line = Ui.row(c)
            }
            val sw = View(c)
            sw.background = Ui.cardBg(c, colour, 20, 0x33000000)
            val lp = LinearLayout.LayoutParams(Ui.dp(c, 42), Ui.dp(c, 42))
            lp.rightMargin = Ui.dp(c, 10)
            lp.bottomMargin = Ui.dp(c, 10)
            sw.layoutParams = lp
            sw.setOnClickListener {
                Theme.setOverride(c, slot, colour)
                godDialog?.dismiss()
                host.recreate()
            }
            line.addView(sw)
        }
        box.addView(line)
        godDialog = AlertDialog.Builder(c)
            .setTitle("${OVR_LABELS[slot] ?: slot} colour")
            .setView(box)
            .setNeutralButton("Default") { _, _ ->
                Theme.clearOverride(c, slot)
                host.recreate()
            }
            .setNegativeButton("Cancel", null)
            .create()
        godDialog?.show()
    }

    // ---------------- tests ----------------

    private fun pickTestToEdit(host: MainActivity) {
        val c = host
        val labels = Store.momentumTests(c).map { testLabel(it) }
        if (labels.isEmpty()) {
            host.toast("No tests in the calendar yet")
            return
        }
        AlertDialog.Builder(c)
            .setTitle("Pick a test")
            .setItems(labels.toTypedArray()) { _, i -> testActions(host, i) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun testLabel(t: Store.MTest): String {
        val sub = Subjects.byKey(t.subject)
        val ch = sub?.chapters?.getOrNull(t.chapter) ?: "Chapter ${t.chapter + 1}"
        return "${sub?.name ?: t.subject} · $ch · ${prettyTestDate(t.date)}"
    }

    private fun testActions(host: MainActivity, index: Int) {
        val c = host
        val t = Store.momentumTests(c).getOrNull(index) ?: return
        AlertDialog.Builder(c)
            .setTitle(testLabel(t))
            .setItems(arrayOf("Change the date", "Move to another chapter", "Remove this test")) { _, which ->
                when (which) {
                    0 -> pickTestDate(host, t.date) { d ->
                        Store.updateMomentumTest(c, index, t.subject, t.chapter, d)
                        afterGod(host, "Date changed")
                    }
                    1 -> pickSubject(host, "Move to which subject?") { key ->
                        pickChapter(host, key, "Which chapter?") { ch ->
                            Store.updateMomentumTest(c, index, key, ch, t.date)
                            afterGod(host, "Test moved")
                        }
                    }
                    else -> {
                        Store.removeMomentumTest(c, index)
                        afterGod(host, "Test removed")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickTestDate(host: MainActivity, current: String, onSet: (String) -> Unit) {
        val c = host
        val cal = Store.parse(current) ?: Calendar.getInstance()
        DatePickerDialog(c, { _, y, m, d ->
            val t = Calendar.getInstance()
            t.set(y, m, d)
            onSet(Store.fmt(t.time))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---------------- questions ----------------

    private fun pickSubject(host: MainActivity, title: String, onPick: (String) -> Unit) {
        val subs = Subjects.ALL
        AlertDialog.Builder(host)
            .setTitle(title)
            .setItems(subs.map { it.name }.toTypedArray()) { _, i -> onPick(subs[i].key) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickChapter(host: MainActivity, subjectKey: String, title: String, onPick: (Int) -> Unit) {
        val sub = Subjects.byKey(subjectKey) ?: return
        val counts = HashMap<String, Int>()
        for (q in Store.questionBank(host)) if (q.subject == subjectKey) counts[q.chapter] = (counts[q.chapter] ?: 0) + 1
        val labels = sub.chapters.map { ch -> "$ch  ·  ${counts[ch] ?: 0} Qs" }
        AlertDialog.Builder(host)
            .setTitle("${sub.name} — $title")
            .setItems(labels.toTypedArray()) { _, i -> onPick(i) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Pick an existing question out of the bank, then edit it. */
    private fun pickQuestion(host: MainActivity) {
        pickSubject(host, "Which subject?") { key ->
            pickChapter(host, key, "which chapter?") { idx ->
                val sub = Subjects.byKey(key) ?: return@pickChapter
                val chapter = sub.chapters.getOrNull(idx) ?: return@pickChapter
                val qs = Store.questionBank(host).filter { it.subject == key && it.chapter == chapter }
                if (qs.isEmpty()) {
                    host.toast("No questions in that chapter yet")
                    return@pickChapter
                }
                val labels = qs.map { q ->
                    val t = q.text.replace('\n', ' ')
                    if (t.length > 70) t.take(70) + "…" else t
                }
                AlertDialog.Builder(host)
                    .setTitle("${qs.size} questions")
                    .setItems(labels.toTypedArray()) { _, i -> questionForm(host, qs[i], key, chapter) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    /** Pick subject + chapter, then start a blank question. */
    private fun writeQuestion(host: MainActivity) {
        pickSubject(host, "Which subject?") { key ->
            pickChapter(host, key, "which chapter?") { idx ->
                val sub = Subjects.byKey(key) ?: return@pickChapter
                val chapter = sub.chapters.getOrNull(idx) ?: return@pickChapter
                questionForm(host, null, key, chapter)
            }
        }
    }

    /**
     * The question editor. [existing] = null starts a blank one. Options are laid out
     * one field each (the shape the bank actually stores), and the correct answer is
     * picked with the A/B/C/D pills — no hidden index to get wrong.
     */
    private fun questionForm(host: MainActivity, existing: Store.Question?, subjectKey: String, chapter: String) {
        val c = host
        val box = Ui.column(c)
        val pad = Ui.dp(c, 18)
        box.setPadding(pad, Ui.dp(c, 6), pad, 0)

        val qIn = EditText(c)
        qIn.setHint("Question")
        qIn.setText(existing?.text ?: "")
        qIn.setSingleLine(false)
        box.addView(qIn)

        val n = (existing?.options?.size ?: 4).coerceIn(2, 5)
        val optIn = ArrayList<EditText>()
        for (i in 0 until n) {
            val e = EditText(c)
            e.setHint("Option ${('A' + i)}")
            e.setSingleLine()
            if (existing != null && i < existing.options.size) e.setText(existing.options[i])
            box.addView(e)
            optIn.add(e)
        }

        var answer = (existing?.answer ?: 0).coerceIn(0, n - 1)
        val ansRow = Ui.row(c)
        ansRow.setPadding(0, Ui.dp(c, 10), 0, 0)
        ansRow.addView(Ui.text(c, "Correct:", 13f, Ui.color(c, R.color.text_sub)))
        val pills = ArrayList<TextView>()
        for (i in 0 until n) {
            val p = Ui.text(c, "  ${('A' + i)}  ", 14f, Ui.color(c, R.color.text_main), true)
            p.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6))
            p.setOnClickListener {
                answer = i
                for ((j, pill) in pills.withIndex()) paintPill(c, pill, j == i)
                Fx.pop(p)
            }
            paintPill(c, p, i == answer)
            pills.add(p)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = Ui.dp(c, 8)
            ansRow.addView(p, lp)
        }
        box.addView(ansRow)

        val expIn = EditText(c)
        expIn.setHint("Explanation (optional)")
        expIn.setText(existing?.explain ?: "")
        expIn.setSingleLine(false)
        box.addView(expIn)

        val dlg = AlertDialog.Builder(c)
            .setTitle(if (existing == null) "New question" else "Edit question")
            .setView(box)
            .setPositiveButton(if (existing == null) "Add" else "Save") { _, _ ->
                val q = qIn.text.toString().trim()
                val opts = optIn.map { it.text.toString().trim() }
                when {
                    q.isEmpty() -> host.toast("The question needs some text")
                    opts.any { it.isEmpty() } -> host.toast("Fill in every option")
                    answer !in opts.indices -> host.toast("Pick the correct option")
                    else -> {
                        Store.saveQuestion(c, Store.Question(
                            id = existing?.id ?: "god" + System.currentTimeMillis(),
                            subject = subjectKey, chapter = chapter, text = q,
                            options = opts, answer = answer, explain = expIn.text.toString().trim()))
                        host.refresh()
                        host.toast(if (existing == null) "Question added" else "Question updated")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
        if (existing != null) {
            dlg.setNeutralButton("Delete") { _, _ ->
                Store.deleteQuestion(c, existing.id)
                host.refresh()
                host.toast("Question removed")
            }
        }
        dlg.show()
    }

    private fun paintPill(c: MainActivity, pill: TextView, on: Boolean) {
        pill.background = Ui.cardBg(c, if (on) Ui.color(c, R.color.primary) else 0x10000000.toInt(), 10)
        pill.setTextColor(if (on) Theme.onAccent(c) else Ui.color(c, R.color.text_main))
    }

    /**
     * One settings row: label on the left, current value on the right, then a
     * chevron so the row reads as tappable. [danger] paints it red (Reset).
     * [chevron] = false for rows that end in their own action affordance (✕).
     */
    private fun row(
        container: LinearLayout,
        c: android.content.Context,
        label: String,
        value: String,
        danger: Boolean = false,
        chevron: Boolean = true,
        onClick: () -> Unit
    ) {
        val r = Ui.row(c)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, Ui.dp(c, 12), 0, Ui.dp(c, 12))
        val dangerInk = Theme.ink(c, 0xFFE0524D.toInt())
        r.addView(
            Ui.text(c, label, 15f, if (danger) dangerInk else Ui.color(c, R.color.text_main), danger),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val v = Ui.text(
            c, value, 14f,
            when {
                danger -> dangerInk
                value.isEmpty() -> Ui.color(c, R.color.accent)
                else -> Ui.color(c, R.color.primary)
            },
            true
        )
        v.gravity = Gravity.END
        r.addView(v)
        if (chevron) {
            val cv = Ui.text(c, "›", 20f, if (danger) dangerInk else Ui.color(c, R.color.text_sub), true)
            cv.gravity = Gravity.CENTER_VERTICAL
            r.addView(cv, LinearLayout.LayoutParams(Ui.dp(c, 18), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        r.setOnClickListener { onClick() }
        Ui.clickable(c, r)
        container.addView(r)
    }
}

// ---- local re-implementations so the private helpers of TabMain stay private ----
private fun tabScroll2(host: MainActivity): Pair<ScrollView, LinearLayout> {
    val sv = ScrollView(host)
    sv.setBackgroundColor(Ui.color(host, R.color.bg))
    sv.isFillViewport = true
    val col = Ui.column(host)
    val pad = Ui.dp(host, 16)
    col.setPadding(pad, Ui.dp(host, 18), pad, Ui.dp(host, 24))
    sv.addView(col, android.widget.FrameLayout.LayoutParams(
        android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
    return sv to col
}

private fun LinearLayout.card2(host: MainActivity, body: LinearLayout.() -> Unit): LinearLayout {
    val card = Ui.column(host)
    card.background = Ui.cardBg(host)
    card.setPadding(Ui.dp(host, 16), Ui.dp(host, 14), Ui.dp(host, 16), Ui.dp(host, 14))
    card.body()
    this.addView(card, Ui.margins(0, 0, 0, 0, host).apply {
        bottomMargin = Ui.dp(host, 12)
    })
    return card
}

// subject colour identity shared by the premium tiles (mirrors TabMain's TabStudy helpers)
private fun subjFill(key: String): Int = when (key) {
    "PHY" -> 0xFFEAF1F8.toInt()
    "CHEM" -> 0xFFFFF3E0.toInt()
    else -> 0xFFE7F3EC.toInt() // Botany & Zoology keep the bio-green family
}

private fun subjAccent(c: android.content.Context, key: String): Int = when (key) {
    "PHY" -> 0xFF2F6FB2.toInt()
    "CHEM" -> 0xFFC77B1F.toInt()
    else -> Ui.color(c, R.color.primary)
}

private fun subjLetter(key: String): String = when (key) {
    "PHY" -> "P"
    "CHEM" -> "C"
    "BOT" -> "B"
    else -> "Z"
}
