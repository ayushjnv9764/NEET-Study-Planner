package com.ayush.neetcracker

data class Subject(val key: String, val name: String, val chapters: List<String>)

object Subjects {

    private val PHYSICS = Subject(
        key = "PHY",
        name = "Physics",
        chapters = listOf(
            "Physical World, Units & Measurement",
            "Motion in a Straight Line",
            "Motion in a Plane",
            "Laws of Motion",
            "Work, Energy & Power",
            "System of Particles & Rotational Motion",
            "Gravitation",
            "Mechanical Properties of Solids",
            "Mechanical Properties of Fluids",
            "Thermal Properties of Matter",
            "Thermodynamics",
            "Kinetic Theory of Gases",
            "Oscillations",
            "Waves",
            "Electric Charges & Fields",
            "Electrostatic Potential & Capacitance",
            "Current Electricity",
            "Moving Charges & Magnetism",
            "Magnetism & Matter",
            "Electromagnetic Induction",
            "Alternating Current",
            "Electromagnetic Waves",
            "Ray Optics & Optical Instruments",
            "Wave Optics",
            "Dual Nature of Radiation & Matter",
            "Atoms & Nuclei",
            "Semiconductor Electronics"
        )
    )

    private val CHEMISTRY = Subject(
        key = "CHEM",
        name = "Chemistry",
        chapters = listOf(
            "Some Basic Concepts of Chemistry",
            "Structure of Atom",
            "Classification of Elements & Periodicity",
            "Chemical Bonding & Molecular Structure",
            "States of Matter",
            "Thermodynamics",
            "Equilibrium",
            "Redox Reactions",
            "Hydrogen",
            "The s-Block Elements",
            "The p-Block Elements (Class XI)",
            "Organic Chemistry: Some Basic Principles",
            "Hydrocarbons",
            "Environmental Chemistry",
            "The Solid State",
            "Solutions",
            "Electrochemistry",
            "Chemical Kinetics",
            "Surface Chemistry",
            "General Principles of Isolation of Elements",
            "The p-Block Elements (Class XII)",
            "Haloalkanes & Haloarenes",
            "Alcohols, Phenols & Ethers",
            "Aldehydes, Ketones & Carboxylic Acids",
            "Amines",
            "Biomolecules",
            "Polymers",
            "Chemistry in Everyday Life",
            "The d & f Block Elements",
            "Coordination Compounds"
        )
    )

    private val BOTANY = Subject(
        key = "BOT",
        name = "Botany",
        chapters = listOf(
            "The Living World",
            "Biological Classification",
            "Plant Kingdom",
            "Morphology of Flowering Plants",
            "Anatomy of Flowering Plants",
            "Cell: The Unit of Life",
            "Cell Cycle & Cell Division",
            "Biomolecules",
            "Transport in Plants",
            "Mineral Nutrition",
            "Photosynthesis in Higher Plants",
            "Respiration in Plants",
            "Plant Growth & Development",
            "Sexual Reproduction in Flowering Plants",
            "Principles of Inheritance & Variation",
            "Molecular Basis of Inheritance",
            "Evolution"
        )
    )

    private val ZOOLOGY = Subject(
        key = "ZOO",
        name = "Zoology",
        chapters = listOf(
            "Animal Kingdom",
            "Structural Organisation in Animals",
            "Digestion & Absorption",
            "Breathing & Exchange of Gases",
            "Body Fluids & Circulation",
            "Excretory Products & their Elimination",
            "Locomotion & Movement",
            "Neural Control & Coordination",
            "Chemical Coordination & Integration",
            "Human Reproduction",
            "Reproductive Health",
            "Human Health & Disease",
            "Strategies for Enhancement in Food Production",
            "Microbes in Human Welfare",
            "Biotechnology: Principles & Processes",
            "Biotechnology & its Applications",
            "Organisms & Populations",
            "Ecosystem",
            "Biodiversity & Conservation",
            "Environmental Issues"
        )
    )

    val ALL = listOf(PHYSICS, CHEMISTRY, BOTANY, ZOOLOGY)

    fun byKey(key: String): Subject? = ALL.firstOrNull { it.key == key }

    /** Total chapters across all subjects. */
    val totalChapters: Int = ALL.sumBy { it.chapters.size }
}
