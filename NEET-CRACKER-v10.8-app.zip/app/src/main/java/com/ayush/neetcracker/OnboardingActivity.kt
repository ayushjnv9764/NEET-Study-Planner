package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * v8.7 onboarding — three intro screens per Ayush's spec:
 * YOUR COMPLETE NEET SYSTEM / MASTER PYQs / KNOW YOUR WEAKNESS,
 * with SKIP · NEXT · GET STARTED and dot indicators. Runs once on fresh
 * installs (see SplashActivity routing), then hands off to ProfileActivity.
 */
class OnboardingActivity : Activity() {

    private data class Page(val kind: Int, val title: String, val desc: String)

    private val pages = listOf(
        Page(0, "YOUR COMPLETE NEET SYSTEM",
            "Plan, study, practice and analyze everything in one place."),
        Page(1, "MASTER PYQs",
            "Practice chapter-wise and year-wise NEET and previous year questions."),
        Page(2, "KNOW YOUR WEAKNESS",
            "Analyze mistakes and improve your NEET score with smart recommendations.")
    )

    private lateinit var content: FrameLayout
    private lateinit var dotsRow: LinearLayout
    private lateinit var cta: TextView
    private val dots = ArrayList<View>()
    private var idx = 0

    private val NAVY = 0xFF0B1233.toInt()
    private val VIOLET = 0xFF6C5CE7.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        setContentView(root)

        // ---- top: SKIP ----
        val skipRow = Ui.row(this)
        skipRow.gravity = Gravity.END
        skipRow.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 6), 0)
        val skip = Ui.text(this, "SKIP", 14f, VIOLET, true)
        skip.setAllCaps(true)
        skip.letterSpacing = 0.12f
        skip.setPadding(Ui.dp(this, 18), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
        Ui.clickable(this, skip)
        Fx.press(skip)
        skip.setOnClickListener { toProfile() }
        skipRow.addView(skip)
        root.addView(skipRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // ---- center: sliding page area ----
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- bottom: dots + CTA ----
        val foot = Ui.column(this)
        dotsRow = Ui.row(this)
        dotsRow.gravity = Gravity.CENTER
        foot.addView(dotsRow)
        foot.addView(Ui.space(this, 20))
        cta = Ui.text(this, "NEXT", 16f, Color.WHITE, true)
        cta.setAllCaps(true)
        cta.letterSpacing = 0.16f
        cta.gravity = Gravity.CENTER
        cta.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16))
        cta.background = roundGradient(Ui.dp(this, 16), 0xFF6C5CE7.toInt(), 0xFF3B2F8F.toInt())
        Ui.clickable(this, cta)
        Fx.press(cta)
        cta.setOnClickListener { next() }
        foot.addView(cta, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val footWrap = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        footWrap.setMargins(Ui.dp(this, 26), Ui.dp(this, 10), Ui.dp(this, 26), Ui.dp(this, 26))
        root.addView(foot, footWrap)

        buildDots()
        show(0, from = -1)
    }

    // ---------------------------------------------------------------- pages

    private fun buildDots() {
        dots.clear()
        for (i in pages.indices) {
            val d = View(this)
            d.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 8), Ui.dp(this, 8))
            if (i > 0) (d.layoutParams as LinearLayout.LayoutParams)
                .setMargins(Ui.dp(this, 6), 0, 0, 0)
            dotsRow.addView(d)
            dots.add(d)
        }
        paintDots()
    }

    private fun paintDots() {
        for (i in dots.indices) {
            val d = dots[i]
            val active = i == idx
            val g = GradientDrawable()
            g.cornerRadius = Ui.dp(this, 6).toFloat()
            g.setColor(if (active) VIOLET else Theme.surface(this, 0xFFCBD3E1.toInt()))
            d.background = g
            val lp = d.layoutParams as LinearLayout.LayoutParams
            lp.width = Ui.dp(this, if (active) 24 else 8)
            d.layoutParams = lp
            if (active) {
                d.alpha = 0f
                d.animate().alpha(1f).setDuration(180).start()
            }
        }
    }

    private fun show(i: Int, from: Int) {
        idx = i
        paintDots()
        val w = resources.displayMetrics.widthPixels

        val old = if (content.childCount > 0) content.getChildAt(0) else null
        val page = buildPage(pages[i])
        content.addView(page, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        if (old == null) return // first page: no motion needed

        if (from != -1) {
            page.translationX = (if (from < i) w else -w).toFloat()
            val outDir = if (from < i) -w.toFloat() else w.toFloat()
            old.animate().translationX(outDir).alpha(0.3f).setDuration(230)
                .withEndAction { if (old.parent === content) content.removeView(old) }.start()
        } else {
            content.removeView(old)
        }
        page.animate().translationX(0f).setDuration(250)
            .setInterpolator(DecelerateInterpolator(1.3f)).start()

        cta.text = if (i == pages.size - 1) "GET STARTED" else "NEXT"
    }

    private fun buildPage(p: Page): LinearLayout {
        val page = Ui.column(this)
        page.gravity = Gravity.CENTER_HORIZONTAL

        // icon disc
        val icon = GlyphView(this, p.kind)
        icon.background = disc(iconColors(p.kind))
        val ilp = LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.dp(this, 150))
        ilp.topMargin = Ui.dp(this, 24)
        page.addView(icon, ilp)

        val title = Ui.text(this, p.title, 24f, NAVY, true)
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        title.gravity = Gravity.CENTER
        title.setPadding(Ui.dp(this, 40), 0, Ui.dp(this, 40), 0)
        val tlp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = Ui.dp(this, 34)
        page.addView(title, tlp)

        val desc = Ui.text(this, p.desc, 15f, 0xFF5A6480.toInt())
        desc.gravity = Gravity.CENTER
        desc.setPadding(Ui.dp(this, 44), 0, Ui.dp(this, 44), 0)
        desc.setLineSpacing(Ui.dp(this, 3).toFloat(), 1f)
        val dlp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = Ui.dp(this, 12)
        page.addView(desc, dlp)

        // reveal: icon pops, then the copy fades up
        icon.alpha = 0f
        icon.scaleX = 0.86f
        icon.scaleY = 0.86f
        icon.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(80).setDuration(360)
            .setInterpolator(OvershootInterpolator(1.6f)).start()
        return page
    }

    private fun iconColors(kind: Int): IntArray = when (kind) {
        0 -> intArrayOf(0xFF22D3EE.toInt(), 0xFF3B2F8F.toInt())
        1 -> intArrayOf(0xFF6C5CE7.toInt(), 0xFF22D3EE.toInt())
        else -> intArrayOf(0xFF0E7A4C.toInt(), 0xFF22D3EE.toInt())
    }

    private fun disc(colors: IntArray): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.orientation = GradientDrawable.Orientation.TL_BR
        g.colors = colors
        return g
    }

    private fun roundGradient(r: Int, a: Int, b: Int): GradientDrawable {
        val g = GradientDrawable()
        g.orientation = GradientDrawable.Orientation.TL_BR
        g.cornerRadius = r.toFloat()
        g.colors = intArrayOf(a, b)
        return g
    }

    private fun next() {
        if (idx < pages.size - 1) show(idx + 1, from = idx) else toProfile()
    }

    private fun toProfile() {
        startActivity(Intent(this, ProfileActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}

/** Draws simple flat white glyphs on a gradient disc (no icon assets needed). */
private class GlyphView(c: android.content.Context, private val kind: Int) : View(c) {
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 5 * d
        when (kind) {
            0 -> checklist(canvas, p, d, w, h)   // complete NEET system (tasks/cards)
            1 -> target(canvas, p, w, h)          // master PYQs (target)
            2 -> chart(canvas, p, d, w, h)        // know your weakness (bars)
        }
    }

    private fun checklist(canvas: Canvas, p: Paint, d: Float, w: Float, h: Float) {
        val rows = floatArrayOf(0.12f, 0.38f, 0.64f)
        val rh = h * 0.17f
        for (r in rows) {
            canvas.drawRoundRect(w * 0.2f, h * r, w * 0.8f, h * r + rh, 8 * d, 8 * d, p)
            val cy = h * r + rh / 2
            val line = Paint(p)
            line.color = Color.argb(200, 255, 255, 255)
            line.strokeWidth = 4 * d
            canvas.drawLine(w * 0.36f, cy, w * 0.68f, cy, line)
        }
        // little check dot on the top row
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = Color.WHITE
        canvas.drawCircle(w * 0.32f, h * 0.12f + rh / 2, 5 * d, dot)
    }

    private fun target(canvas: Canvas, p: Paint, w: Float, h: Float) {
        val cx = w / 2
        val cy = h / 2
        canvas.drawCircle(cx, cy, w * 0.34f, p)
        canvas.drawCircle(cx, cy, w * 0.21f, p)
        val fill = Paint(p)
        fill.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, w * 0.055f, fill)
    }

    private fun chart(canvas: Canvas, p: Paint, d: Float, w: Float, h: Float) {
        val base = h * 0.82f
        canvas.drawLine(w * 0.2f, base, w * 0.84f, base, p)
        val fill = Paint(p)
        fill.style = Paint.Style.FILL
        val bw = w * 0.075f
        val xs = floatArrayOf(0.3f, 0.5f, 0.7f)
        val tops = floatArrayOf(0.60f, 0.48f, 0.34f)
        for (i in xs.indices) {
            canvas.drawRoundRect(
                w * xs[i] - bw / 2, h * tops[i], w * xs[i] + bw / 2, base, 4 * d, 4 * d, fill)
        }
    }
}
