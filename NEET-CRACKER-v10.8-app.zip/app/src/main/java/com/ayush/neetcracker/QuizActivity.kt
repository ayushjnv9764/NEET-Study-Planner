package com.ayush.neetcracker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/**
 * Practice quiz (§9 design): run a set of MCQs, tap an option, get instant
 * feedback + explanation. Every first answer is recorded (Store.addAttempt) for
 * accuracy and the mistake book.
 *
 * v8.20 layout pass (UI spec §9): header carries the counter ("Q 5 / 25"),
 * the subject and an elapsed session clock; a thin progress bar sits under it;
 * options are large cards with a letter badge and a clean selected/correct/
 * wrong language; PREVIOUS / NEXT are fixed at the bottom and always visible.
 * The flow logic is unchanged — an option is locked in on first tap, exactly
 * one attempt per question, and going PREVIOUS shows a question already answered
 * without letting it be re-answered (no double counting).
 */
class QuizActivity : Activity() {

    private var subjectKey = "PHY"
    private var questions = emptyList<Store.Question>()
    private var index = 0
    private var done = false
    private var currentAnswered = false

    /** pick[i] = option the user chose for question i, or -1 while unanswered. */
    private var picks = IntArray(0)

    // view handles updated in place (no full rebuild on answer tap)
    private lateinit var timerLabel: TextView
    private lateinit var tallyLine: TextView
    private lateinit var explainCard: LinearLayout
    private lateinit var prevBtn: TextView
    private lateinit var nextBtn: TextView
    private lateinit var scroller: ScrollView
    private val opts = ArrayList<OptCard>()

    private var startAt = 0L
    private val ticker = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { renderTimer(); ticker.postDelayed(this, 500) }
    }

    private class OptCard(val card: LinearLayout, val badge: TextView, val body: TextView)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ids = intent.getStringExtra("ids")
        if (!ids.isNullOrBlank()) {
            // drill a chosen set (e.g. my mistakes, a quick random round) across subjects
            subjectKey = intent.getStringExtra("subject") ?: ""
            questions = ids.split(",").mapNotNull { Store.questionById(this, it.trim()) }
        } else {
            subjectKey = intent.getStringExtra("subject") ?: "PHY"
            val chapter = intent.getStringExtra("chapter") ?: ""
            questions =
                if (chapter.isEmpty()) Store.questionBank(this).filter { it.subject == subjectKey }
                else Store.questionsFor(this, subjectKey, chapter)
            questions = questions.shuffled() // v8.11: fresh order on every drill
        }
        startAt = System.currentTimeMillis()
        picks = IntArray(questions.size) { -1 }
        render()
    }

    override fun onStop() {
        super.onStop()
        ticker.removeCallbacks(tick)
    }

    private fun render() {
        ticker.removeCallbacks(tick)
        if (done) { renderSummary(); return }
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        header(root, tools = questions.isNotEmpty())

        if (questions.isEmpty()) {
            root.addView(emptyState())
            setContentView(root)
            return
        }

        val q = questions[index]

        // thin session progress bar (fraction of questions reached)
        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(this, 0xFFE4EBE7.toInt(), 2)
        val fill = android.view.View(this)
        fill.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 2)
        val frac = (index + 1).toFloat() / questions.size
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(this, 4), frac))
        root.addView(track, Ui.margins(16, 2, 16, 2, this))

        // scrollable question area (options stay touchable on small screens)
        scroller = ScrollView(this)
        val col = Ui.column(this)
        col.setPadding(0, 0, 0, Ui.dp(this, 6))
        scroller.addView(col, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(scroller, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        qMeta(col, q)
        qText(col, q)
        opts.clear()
        for ((i, opt) in q.options.withIndex()) col.addView(buildOption(col, i, opt), Ui.margins(14, 0, 14, 10, this))
        col.addView(buildExplain(col, q), Ui.margins(14, 0, 14, 8, this))
        explainCard.visibility = android.view.View.GONE

        buildBottom(root)
        setContentView(root)

        // step-in animation (question text, then options)
        val tv = scroller.getChildAt(0) as? LinearLayout
        val first = (tv?.getChildAt(0)) ?: scroller
        first.alpha = 0f
        first.animate().alpha(1f).setDuration(180).start()
        for ((j, o) in opts.withIndex()) {
            o.card.alpha = 0f
            o.card.translationY = Ui.dp(this, 5).toFloat()
            o.card.animate().alpha(1f).translationY(0f).setDuration(190)
                .setStartDelay(70 + j * 45L).start()
        }

        // restore an already-answered question when navigating back (no re-record)
        if (picks[index] >= 0) revealState()

        refreshButtons()
        startTicker()
    }

    /** Where this question comes from — subject chip + chapter, so a drill is never context-free. */
    private fun qMeta(col: LinearLayout, q: Store.Question) {
        val row = Ui.row(this)
        row.setPadding(Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 18), 0)
        val chip = Ui.text(this, Subjects.byKey(q.subject)?.name ?: q.subject, 11.5f, Theme.onAccent(this), true)
        chip.gravity = Gravity.CENTER
        chip.background = Ui.cardBg(this, accent(q.subject), 10)
        chip.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        row.addView(chip)
        if (q.chapter.isNotBlank()) {
            val ch = Ui.text(this, q.chapter, 12f, Ui.color(this, R.color.text_sub))
            ch.maxLines = 1
            ch.ellipsize = android.text.TextUtils.TruncateAt.END
            ch.setPadding(Ui.dp(this, 8), 0, 0, 0)
            row.addView(ch, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(row)
    }

    /** Per-subject chip fill (physics = brand, the rest tinted so they read apart). */
    private fun accent(key: String): Int = when (key) {
        "CHEM" -> Theme.ink(this, 0xFFB26A00.toInt())
        "BOT" -> Theme.ink(this, 0xFF2E7D4F.toInt())
        "ZOO" -> Theme.ink(this, 0xFF00695C.toInt())
        else -> Ui.color(this, R.color.primary)
    }

    /** Header sub-line: subject + a live ✓/✕ tally once anything is answered. */
    private fun headerSub(): String {
        val subj = Subjects.byKey(subjectKey)?.name ?: ""
        var answered = 0
        var right = 0
        for (i in questions.indices) {
            val p = picks.getOrNull(i) ?: -1
            if (p >= 0) {
                answered++
                if (p == questions[i].answer) right++
            }
        }
        val tally = if (answered > 0) "  ·  ✓ $right  ✕ ${answered - right}" else ""
        return subj + tally
    }

    private fun qText(col: LinearLayout, q: Store.Question) {
        val tv = Ui.text(this, q.text, 18f, Ui.color(this, R.color.text_main), true)
        tv.setLineSpacing(Ui.dp(this, 3).toFloat(), 1.14f)
        tv.setPadding(Ui.dp(this, 18), Ui.dp(this, 12), Ui.dp(this, 18), Ui.dp(this, 10))
        col.addView(tv)
    }

    private fun buildOption(col: LinearLayout, i: Int, text: String): LinearLayout {
        val card = Ui.row(this)
        val letter = ('A' + i).toString()
        val line = if (Theme.isDark(this)) 0x26FFFFFF.toInt() else 0x14000000.toInt()

        card.background = Ui.cardBg(this, 0xFFFFFFFF.toInt(), 15, line)
        card.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10))

        val badge = Ui.text(this, letter, 15f, Ui.color(this, R.color.text_main), true)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.cardBg(this, 0xFFEAF1EC.toInt(), 15)
        val bs = Ui.dp(this, 31)
        card.addView(badge, LinearLayout.LayoutParams(bs, bs))

        val body = Ui.text(this, text, 16f, Ui.color(this, R.color.text_main), true)
        body.setLineSpacing(0f, 1.08f)
        body.setPadding(Ui.dp(this, 12), 0, 0, 0)
        card.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        card.setOnClickListener { onPick(i) }
        Fx.press(card)
        opts.add(OptCard(card, badge, body))
        return card
    }

    private fun buildExplain(col: LinearLayout, q: Store.Question): LinearLayout {
        explainCard = Ui.column(this)
        explainCard.background = Ui.cardBg(this, 0xFFFFF3D9.toInt(), 14)
        explainCard.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
        val expLabel = Ui.text(this, "Explanation", 13f, Ui.color(this, R.color.accent), true)
        expLabel.setTypeface(null, Typeface.BOLD)
        explainCard.addView(expLabel)
        val expBody = Ui.text(this, q.explain, 14.5f, Ui.color(this, R.color.text_main))
        expBody.setLineSpacing(0f, 1.12f)
        expBody.setPadding(0, Ui.dp(this, 4), 0, 0)
        explainCard.addView(expBody)
        return explainCard
    }

    /** Fixed PREVIOUS / NEXT bar — always visible, buttons follow the enabled state. */
    private fun buildBottom(root: LinearLayout) {
        val bar = Ui.row(this)
        bar.setBackgroundColor(Ui.color(this, R.color.card))
        bar.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 10))

        prevBtn = Ui.button(this, "PREVIOUS", false)
        prevBtn.gravity = Gravity.CENTER
        prevBtn.setOnClickListener { onPrevious() }
        bar.addView(prevBtn, LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f))

        nextBtn = Ui.button(
            this,
            if (index == questions.size - 1) "SEE RESULT" else "NEXT",
            true
        )
        nextBtn.gravity = Gravity.CENTER
        nextBtn.setOnClickListener { onNext() }
        val lp = LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f)
        lp.setMargins(Ui.dp(this, 12), 0, 0, 0)
        bar.addView(nextBtn, lp)
        root.addView(bar)
    }

    private fun refreshButtons() {
        prevBtn.alpha = if (index == 0) 0.45f else 1f
        nextBtn.alpha = if (currentAnswered) 1f else 0.5f
    }

    private fun onPrevious() {
        if (index == 0) { Fx.shake(prevBtn); return }
        index--
        currentAnswered = false
        render()
    }

    private fun onNext() {
        if (!currentAnswered) {
            Ui.toast(this, "Pick an answer first")
            Fx.shake(nextBtn)
            return
        }
        if (index + 1 >= questions.size) { done = true; render() }
        else { index++; currentAnswered = false; render() }
    }

    private fun header(root: LinearLayout, tools: Boolean) {
        val h = Ui.row(this)
        h.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 2))
        val back = Ui.text(this, "‹", 30f, Ui.color(this, R.color.primary), true)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        Fx.press(back)
        h.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))

        val center = Ui.column(this)
        center.gravity = Gravity.CENTER
        if (questions.isNotEmpty() && index < questions.size) {
            val counter = Ui.text(this, "Q ${index + 1} / ${questions.size}", 19f, Ui.color(this, R.color.text_main), true)
            center.addView(counter)
        }
        tallyLine = Ui.text(this, headerSub(), 12f, Ui.color(this, R.color.text_sub))
        tallyLine.setPadding(0, Ui.dp(this, 1), 0, 0)
        center.addView(tallyLine)
        h.addView(center, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        if (tools && index < questions.size) {
            val q = questions[index]
            val star = Ui.text(
                this,
                if (Store.isBookmarked(this, q.id)) "★" else "☆",
                22f, Ui.color(this, R.color.accent), true
            )
            star.gravity = Gravity.CENTER
            star.setOnClickListener {
                Store.toggleBookmark(this, q.id)
                star.text = if (Store.isBookmarked(this, q.id)) "★" else "☆"
                Ui.toast(this, if (Store.isBookmarked(this, q.id)) "Bookmarked ✓" else "Bookmark removed")
            }
            Fx.press(star)
            h.addView(star, LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)))
        }

        if (tools) {
            timerLabel = Ui.text(this, "--:--", 13f, Ui.color(this, R.color.primary), true)
            timerLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            timerLabel.gravity = Gravity.CENTER
            timerLabel.background = Ui.cardBg(this, 0xFFE7F3EC.toInt(), 12)
            val pad = Ui.dp(this, 8)
            timerLabel.setPadding(pad, Ui.dp(this, 5), pad, Ui.dp(this, 5))
            h.addView(timerLabel, LinearLayout.LayoutParams(Ui.dp(this, 82), Ui.dp(this, 30)))
        }
        root.addView(h)
    }

    // ---------------- answering ----------------

    private fun onPick(i: Int) {
        if (currentAnswered) return
        currentAnswered = true
        picks[index] = i
        val q = questions[index]
        val correct = i == q.answer

        Store.addAttempt(this, q.id, q.subject, q.chapter, correct)
        revealState()
        refreshButtons()

        if (correct) Fx.pop(opts[i].card)
        else {
            Fx.shake(opts[i].card)
            Fx.pop(opts[q.answer].card, 1.03f)
        }
        scrollExplainIntoView()
    }

    /** Paints option cards to the revealed state for the current question. */
    private fun revealState() {
        val q = questions[index]
        val pi = picks[index]
        if (pi < 0) return
        currentAnswered = true
        val pri = Ui.color(this, R.color.primary)
        val err = Theme.ink(this, 0xFFE0524D.toInt())
        for ((j, o) in opts.withIndex()) {
            when {
                j == q.answer -> {
                    o.card.background = Ui.cardBg(this, 0xFFDDF0E4.toInt(), 15, pri)
                    o.card.alpha = 1f
                    o.badge.background = Ui.cardBg(this, pri, 15)
                    o.badge.text = "✓"
                    o.badge.setTextColor(Theme.onAccent(this))
                }
                j == pi -> {
                    o.card.background = Ui.cardBg(this, 0xFFFBEFF3.toInt(), 15, err)
                    o.card.alpha = 1f
                    o.badge.background = Ui.cardBg(this, err, 15)
                    o.badge.text = "✕"
                    o.badge.setTextColor(Theme.onAccent(this))
                }
                else -> {
                    o.card.alpha = 0.5f
                }
            }
        }
        explainCard.visibility = android.view.View.VISIBLE
        Fx.reveal(explainCard)
        if (::tallyLine.isInitialized) tallyLine.text = headerSub()
    }

    private fun scrollExplainIntoView() {
        scroller.post {
            scroller.smoothScrollTo(0, explainCard.bottom + Ui.dp(this, 10))
        }
    }

    private fun emptyState(): TextView =
        Ui.text(
            this,
            "No questions in this chapter yet.\nQuestion packs you import will appear here.",
            15f, Ui.color(this, R.color.text_sub)
        ).apply {
            gravity = Gravity.CENTER
            setPadding(Ui.dp(this@QuizActivity, 24), Ui.dp(this@QuizActivity, 60), Ui.dp(this@QuizActivity, 24), 0)
        }

    // ---------------- result ----------------

    private fun renderSummary() {
        ticker.removeCallbacks(tick)
        val root = Ui.column(this)
        root.setBackgroundColor(Ui.color(this, R.color.bg))
        header(root, tools = false)
        val pad = Ui.dp(this, 20)

        val sc = ScrollView(this)
        val col = Ui.column(this)
        col.setPadding(pad, pad, pad, Ui.dp(this, 24))
        sc.addView(col)
        root.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val subj = Subjects.byKey(subjectKey)?.name ?: ""
        col.addView(Ui.text(this, if (subj.isEmpty()) "Practice done!" else "$subj practice done!", 20f, Ui.color(this, R.color.text_main), true).apply {
            setTypeface(null, Typeface.BOLD)
        })
        col.addView(Ui.space(this, 14))

        val total = questions.size
        val correct = questions.indices.count { picks[it] == questions[it].answer }
        val wrong = total - correct
        val pct = if (total == 0) 0 else correct * 100 / total
        val el = (System.currentTimeMillis() - startAt) / 1000
        val msg = when {
            pct >= 90 -> "Outstanding! 🔥"
            pct >= 70 -> "Great work — almost there!"
            pct >= 50 -> "Good start, keep pushing."
            else -> "Don't worry — review and try again."
        }

        // score card — the one thing you look at first
        val card = Ui.column(this)
        card.background = Ui.cardBg(this, Ui.color(this, R.color.primary), 18)
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 16))
        val big = Ui.text(this, "$correct / $total", 42f, Color.WHITE, true)
        big.setTypeface(Typeface.DEFAULT_BOLD)
        card.addView(big)
        card.addView(Ui.text(this, "$pct% correct · $msg", 14.5f, 0xD9FFFFFF.toInt(), true))
        card.addView(Ui.space(this, 12))

        // accuracy bar (correct share of the paper)
        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.weightSum = 1f
        track.background = Ui.cardBg(this, 0x33FFFFFF.toInt(), 4)
        val fill = android.view.View(this)
        fill.background = Ui.cardBg(this, Color.WHITE, 4)
        val frac = if (total == 0) 0f else correct.toFloat() / total
        track.addView(fill, LinearLayout.LayoutParams(0, Ui.dp(this, 7), frac.coerceAtLeast(0.02f)))
        card.addView(track)
        card.addView(Ui.space(this, 14))

        // three cells: correct · wrong · time
        val cells = Ui.row(this)
        cells.weightSum = 3f
        cells.addView(statCell("CORRECT", "$correct", Ui.dp(this, 18)), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        cells.addView(statCell("WRONG", "$wrong", Ui.dp(this, 18)), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        cells.addView(statCell("TIME", fmt(el), Ui.dp(this, 0)), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(cells)
        col.addView(card)

        col.addView(Ui.space(this, 10))
        if (total > 0) {
            val blank = questions.indices.count { picks[it] < 0 }
            col.addView(
                Ui.text(
                    this,
                    "Avg ${el / total}s per question · $blank left blank",
                    13f, Ui.color(this, R.color.text_sub)
                )
            )
        }
        col.addView(Ui.space(this, 16))

        if (wrong > 0) {
            val note = Ui.text(
                this,
                "$wrong question${if (wrong == 1) "" else "s"} got added to your mistake book — you'll see them again for revision.",
                14f, Ui.color(this, R.color.text_sub)
            )
            col.addView(note)
            col.addView(Ui.space(this, 16))
        }

        val again = Ui.button(this, "Practice again", true)
        again.setOnClickListener {
            index = 0; currentAnswered = false; done = false
            for (k in picks.indices) picks[k] = -1
            startAt = System.currentTimeMillis()
            render()
        }
        col.addView(again, Ui.margins(0, 0, 0, 10, this))

        if (wrong > 0) {
            val review = Ui.button(this, "Review mistakes", false)
            review.setOnClickListener {
                startActivity(Intent(this, ReviewActivity::class.java).putExtra("mode", "mistakes"))
            }
            col.addView(review, Ui.margins(0, 0, 0, 10, this))
        }

        val finishBtn = Ui.button(this, "Done", false)
        finishBtn.setOnClickListener { finish() }
        col.addView(finishBtn)
        setContentView(root)
    }

    /** One mini stat inside the score card (white label + white value). */
    private fun statCell(label: String, value: String, rightPad: Int): LinearLayout {
        val cell = Ui.column(this)
        cell.setPadding(0, 0, rightPad, 0)
        val v = Ui.text(this, value, 20f, Color.WHITE, true)
        v.setTypeface(Typeface.DEFAULT_BOLD)
        cell.addView(v)
        cell.addView(Ui.text(this, label, 10.5f, 0xB3FFFFFF.toInt(), true).apply { letterSpacing = 0.08f })
        return cell
    }

    // ---------------- session clock ----------------

    private fun startTicker() {
        ticker.removeCallbacks(tick)
        if (::timerLabel.isInitialized) {
            renderTimer()
            ticker.post(tick)
        }
    }

    private fun renderTimer() {
        if (!::timerLabel.isInitialized) return
        val el = (System.currentTimeMillis() - startAt) / 1000
        timerLabel.text = fmt(el)
    }

    private fun fmt(sec: Long): String =
        if (sec >= 3600) String.format(Locale.US, "%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        else String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
}
