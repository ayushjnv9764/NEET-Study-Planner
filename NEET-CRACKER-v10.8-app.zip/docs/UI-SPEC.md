# NEET CRACKER — UI design spec (Ayush's brief, received in fragments)

Received across several messages (his client truncates long messages). Now
**complete: §1–§21** all in hand (last chunk delivered §13 body + §14–§21).

## Scope discipline (Ayush, verbatim intent)

"This update is ONLY for UI, DESIGN, SCREEN ARRANGEMENT, ICONS, SPACING AND
LIGHTWEIGHT ANIMATIONS. DO NOT CHANGE: App logic / Database / Question system /
Study data / Backend / Storage system."

Cross-cutting directive: **cards large enough for easy touch**.

## Branding
- App name: NEET CRACKER. Sub-line: **BY AYUSH** (NOT "AYUSH EDITION").
- Tagline: **Study Smart. Practice Hard. Crack NEET.**
- Colour system: max 1 primary accent + 1 secondary accent + success + warning +
  error. No random colours. (Current kit: primary green #0E7A4C, accent orange
  #FF9F1C, secondary violet #6C5CE7, success green, warning amber, error red.)

## §1–§3 (from msg 1) — philosophy / design system / splash
- Modern · minimal · premium · futuristic · clean · student-focused.
- Splash: centred logo, fades, short transition (already exists; only wording
  change AYUSH EDITION → BY AYUSH).

## §4 Home (from msg 1)
Greeting header (name) + profile icon → big NEET countdown card → **Today's
Progress card** (68% bar + "5/8 Tasks") → **Quick Stats horizontal row** (Study
time / Streak🔥 / Tasks) → **Today's Tasks list** (subject + progress) → large
**CONTINUE STUDYING** primary button.

## §5 Bottom nav — 5 items (from msg 1)
HOME 🏠 / STUDY 📚 / PRACTICE 🎯 / PROGRESS 📊 / PROFILE 👤.
Selected = highlighted icon + text + small indicator, fast scale animation.
→ v8.18 SHIPPED: nav restructured to these 5 (Study back in the bar, Analytics
renamed PROGRESS with 📊 icon).

## §6 Study screen (from msg 1; v8.18 header only)
STUDY title + subtitle "Continue your preparation" + vertical subject cards:
⚛️ PHYSICS / CHEMISTRY / BOTANY / ZOOLOGY, each icon, name, % progress, small
bar, "12/20 chapters".

## §7 Subject chapter screen (v8.19 BUILT — SubjectActivity.kt rewrite)
TOP: Back button · Subject name · Progress percentage (+ slim overall bar, count
caption). CHAPTER LIST large cards: "01" number chip (subject-tinted), chapter
name, chevron, then row: status pill + progress bar + %. STATUS: Completed
(success green pill) / In Progress (amber pill — derived from ≥1 question
attempt in that chapter) / Not Started (neutral pill). Progress % per chapter =
attempted / bank size (0 = not started, 100% = completed). Tap still toggles
the coaching "done" flag (logic unchanged). No overcrowding.

## §8 Practice screen (v8.18 DONE)
PRACTICE + subtitle **"Improve Your Performance"**.
QUICK PRACTICE: large buttons 10/25/50 MCQs as a clean grid.
PYQ PRACTICE card: "Practice Previous Year Questions" + arrow.
CUSTOM PRACTICE card: choose subject / chapter / questions / difficulty +
START PRACTICE. Use simple selection boxes.
(Note: difficulty & chapter-level selectors have no data behind them yet — v8.18
custom = subject + question count only.)

## §9 MCQ screen (NOT YET DONE — v8.19)
Top bar: close/back · Question · counter 05/25 · Timer 00:12:45. Question
progress: small horizontal bar. Question area: large readable text, line spacing,
no tiny text. Options: A/B/C/D lettered large touchable cards. Selected option =
highlighted border; correct = success indicator; wrong = error indicator.
Bottom: PREVIOUS / NEXT fixed.
⚠ Today's QuizActivity is instant-feedback + Next only (no timer / no prev).
Timer/PREV-NEXT change interaction → flagged for Ayush's "go" (logic boundary).

## §10 Test screen (NOT YET DONE — v8.19)
Test name · Question 25/45 · Timer 01:25:40. Clean large question text. Large
option cards, clear spacing. Bottom: Previous / Next / Question-Palette button.
Palette: compact grid, indicators Answered / Unanswered / Marked / Not Visited,
few colours.

## §11 PYQ screen (NOT YET DONE — v8.19)
PYQ PRACTICE. Filter area: YEAR / SUBJECT / CHAPTER / STATUS compact dropdowns.
Progress card: COMPLETED 65% · CORRECT 320 · WRONG 80. Question list: number,
subject, chapter, status, arrow.

## §12 Progress screen (v8.18 DONE)
"Your Progress". MAIN PROGRESS CARD: OVERALL PREPARATION bar+76%. STATS GRID:
QUESTIONS 2500 / ACCURACY 76% / TESTS 12 / STUDY HOURS 120h. SUBJECT PROGRESS:
PHYSICS/CHEMISTRY/BOTANY/ZOOLOGY rows with bars. Consistent spacing.

## §13 ANALYTICS UI (received, LIGHT)
"KEEP ANALYTICS LIGHTWEIGHT." Show: Accuracy / Questions Solved / Tests Taken /
Study Hours. Use simple progress bars, number cards, trend indicators. Avoid
heavy graphs, complex/animated charts, big libraries. (No such tab today —
Progress tab §12 is the closest home; a drill-down is optional.)

## §14 ERROR NOTEBOOK UI (received — needs new data)
MY MISTAKES. Filters ALL/PHYSICS/CHEMISTRY/BIOLOGY. Mistake card: Question No ·
Chapter · Mistake Type · Date · status icon. Mistake types: Conceptual / Factual
/ Calculation / Silly / Misreading / Guess. Buttons REVISE / RETRY.
⚠ Mistake TYPE is not recorded anywhere today → data-layer work; next round.

## §15 FOCUS TIMER UI (received — mostly restyle)
FOCUS TIMER. Main timer 00:45:00 **large**. Quick options 25/45/60/90 MIN.
START FOCUS button. Below: TODAY'S STUDY TIME 04h 20m. Keep minimal.
⚠ TimerActivity + sessions tracking already exist → mostly a restyle pass.

## §16 REVISION SCREEN UI (received — needs new data)
REVISION. Sections: 🔴 REVISION DUE (urgent) / 🟠 WEAK TOPICS (low accuracy) /
🟢 STRONG TOPICS (high accuracy). Topic card: chapter · accuracy · last
revision · REVISE NOW. ⚠ "last revision" + per-topic bucketing not stored →
next round (accuracy per subject exists via Store.accuracy).

## §17 PROFILE SCREEN UI (received)
Top: avatar · AYUSH · NEET ASPIRANT. Stats: QUESTIONS SOLVED / STUDY HOURS /
TESTS / STREAK. Menu: Settings / Backup / Restore / About NEET CRACKER.
⚠ Close to current Profile tab (TabSettings); polish + Backup/Restore not built.

## §18–§21 — CROSS-CUTTING DESIGN RULES (received)
- Cards: one card language everywhere — rounded corners, padding, hierarchy,
  soft border/elevation, consistent height & spacing, few styles.
- Buttons: PRIMARY large/rounded/clear (CONTINUE STUDYING, START PRACTICE, START
  TEST); SECONDARY lighter (VIEW ALL, PREVIOUS, CANCEL). Consistent tap size,
  height, corner radius.
- Icons: simple vector icons, one consistent style. Avoid mixing outlined /
  filled / random emoji. Set: HOME STUDY PRACTICE PROGRESS PROFILE PHYSICS
  CHEMISTRY BOTANY ZOOLOGY TIMER BOOKMARK SETTINGS BACK.
- Typography: LARGE = titles/countdown/timer/scores; MEDIUM = section/subject/
  chapter names; SMALL = descriptions/dates/secondary info.

## EXTRA — About the Developer (msg 719, v8.19)
Icon (app logo PNG) row at bottom of Profile tab → opens AboutActivity: Ayush's
developer note as an elegant serif letter (name, body, My Vision line,
signature). "Remove all tab buttons" still ambiguous (Profile inner rows vs
bottom nav) — asked Ayush (msg 723).

## Ship status
- v8.18 (code 33): 5-tab nav, splash "BY AYUSH", Home greeting avatar → Profile,
  Study header copy, Practice tab (§8), Progress tab (§12). Built + delivered.
- v8.19 (code 34, in build): Subject chapter screen §7 + About the Developer.
  Then §9 MCQ / §10 Test / §11 PYQ hub / Home §4 remain (data-hungry §14/§16
  deferred to a feature round).
