# NEET CRACKER — UX/UI spec (Ayush's design brief, pasted in pieces)

> Single source of truth for Ayush's UI/UX vision. He pastes it across several
> messages; this file accumulates the sections verbatim-ish so future builds
> (and cold-start reads after compaction) have the complete picture. Design
> north star lives alongside ROADMAP.md.

## Branding

- App name: NEET CRACKER
- Brand: AYUSH EDITION
- Tagline: STUDY SMART. PRACTICE HARD. CRACK NEET.
- Goal: modern, futuristic, premium, clean, highly organized. Not overcrowded.
  Every screen guides the student toward the next important study action.
- Philosophy flow: HOME → TODAY'S TASK → STUDY → PRACTICE → TEST → ANALYSIS → IMPROVEMENT
- Main focus: STUDY / PRACTICE / PYQ / TEST / ANALYSIS / REVISION / IMPROVEMENT

## FINAL UI DESIGN RULES (10)

1. Keep screens clean.
2. Important actions large and easy to find.
3. Do not overcrowd navigation.
4. Animations only to improve experience.
5. Keep animation duration fast.
6. Same card design everywhere.
7. Same button style everywhere.
8. Clear typography.
9. Focus on study productivity.
10. Every screen guides the student toward the next NEET action.

## Navigation structure

SPLASH → ONBOARDING → (LOGIN OR) PROFILE SETUP → HOME DASHBOARD → main nav.
Bottom nav = exactly 4 keys, one-hand reachable, selected item animates
(icon scales up, label appears, small indicator behind item, 150–250 ms).
Floating AI button (for AI Mentor) — extra features must NOT crowd the nav.

Bottom nav keys: HOME (home icon) · PRACTICE (target icon) · ANALYTICS (chart
icon) · PROFILE (user icon).

Top app bar: left MENU icon · center SCREEN TITLE · right NOTIFICATION icon.
Optional profile icon only on Home. Don't overcrowd the top bar.

## 4. Splash screen

Shows logo, "NEET CRACKER", "AYUSH EDITION", tagline. Sequence (timed):
0.0s logo invisible → 0.3s logo fades in → 0.5s logo slightly scales →
0.8s "NEET CRACKER" appears → 1.2s "AYUSH EDITION" appears → 1.8s transition
to Home or Onboarding. Use fade, scale, small glow. No excessive rotation/bounce.

## 5. Onboarding (3 screens)

- Screen 1: "YOUR COMPLETE NEET SYSTEM" — "Plan, study, practice and analyze everything in one place." Books/study elements slowly appear.
- Screen 2: "MASTER PYQs" — "Practice chapter-wise and year-wise NEET and previous year questions." Questions + progress indicators animate.
- Screen 3: "KNOW YOUR WEAKNESS" — "Analyze mistakes and improve your NEET score with smart recommendations." Performance chart gradually appears.
- Buttons: SKIP · NEXT · GET STARTED.

## 6. Home Dashboard (most important screen)

- Greeting "Good Morning, Ayush", study streak (e.g. "12 DAY STUDY STREAK").
- Today's Progress card: Study time (e.g. 6h 20m), Daily target (e.g. 8h), Progress % — animated circular or horizontal progress.
- Quick actions: exactly 4 — STUDY / PRACTICE / PYQ / TEST — in a 2×2 grid, each with icon + title + small description. Tap animates scale→96% then back to 100%, 100–150 ms.
- Continue Studying card (horizontal): current chapter, e.g. PHYSICS / ROTATIONAL MOTION, progress 65% + bar + CONTINUE button; animates slightly when clicked.
- Today's Task section: checklist format (✓/○ rows, e.g. Biology Revision done, Physics DPP / Chemistry PYQ / Organic Chemistry Revision pending). Completed task: animated checkmark, progress update, small completion effect. No large distracting animations.

## 10–11. Premium subject cards (4)

PHYSICS — physics symbol; subtitle "Mechanics • Electrodynamics • Modern Physics".
CHEMISTRY — flask icon; "Physical • Organic • Inorganic".
BOTANY — plant icon; "Plant Kingdom • Physiology".
ZOOLOGY — DNA icon; "Human Physiology • Genetics".
Each card: icon, name, number of chapters, current progress bar, CONTINUE button. Example block shows chapter chips + "Progress: 68% · CONTINUE →".

## 12. Chapter screen

Clean chapter list. Each chapter row: Chapter Number (01…), Chapter Name,
Progress %, Number of Questions, PYQ status (Completed/Pending),
Revision status (Completed/Pending).

## 13. Chapter priority system

Priority labels HIGH / MEDIUM / LOW PRIORITY. Tags: IMPORTANT FOR NEET,
FREQUENTLY ASKED, NCERT IMPORTANT, PYQ HEAVY, WEAK TOPIC.

## 14–15. Practice screen (PRACTICE CENTER)

Step flow: Choose Subject (PHY/CHEM/BOT/ZOO) → Choose Practice Type (PYQ / DPP /
CHAPTER QUESTIONS / WEAK TOPICS / CUSTOM PRACTICE) → Choose Difficulty (EASY /
MEDIUM / HARD) → START PRACTICE. Vertical arrangement: subject → chapter →
question type → difficulty → number of questions; START PRACTICE always clearly
visible at bottom.

## 16–17. PYQ bank

Dedicated section "NEET PYQ BANK": PHYSICS PYQs / CHEMISTRY PYQs / BIOLOGY PYQs.
Filters: YEAR · CHAPTER · TOPIC · DIFFICULTY · CORRECT QUESTIONS · WRONG
QUESTIONS · UNATTEMPTED QUESTIONS · BOOKMARKED QUESTIONS.
PYQ screen stats: Total Questions (e.g. 50,000+), Attempted (12,450), Correct,
Wrong, Accuracy (78%).

## 18. MCQ question screen

Top bar: BACK · SUBJECT NAME · TIMER. Question progress "QUESTION 24 / 180" +
bar. Clear question area. Options A.–D. Bottom: PREVIOUS · NEXT · MARK FOR REVIEW.

## 19. MCQ answer animation

Correct: small check animation, correct-answer highlight, score update. Wrong:
small shake, show correct answer after submission if enabled. No strong/distracting effects.

## 20. Question navigation

PREVIOUS · NEXT · MARK FOR REVIEW · BOOKMARK · REPORT QUESTION · question
palette. Palette states: Answered, Unanswered, Marked for Review, Correct,
Wrong, Current.

## 21–22. Test center

Sections: UPCOMING TEST · AVAILABLE TESTS · PAST TESTS · FULL SYLLABUS TESTS ·
PART TESTS · CUSTOM TEST. Upcoming test card: test name, date, time, syllabus,
duration, total questions, START TEST. Example: "FULL SYLLABUS MOCK TEST · 15
SEPTEMBER · 3 HOURS · 180 · START TEST".

## 23. Test screen

Top: test name, timer, question number, palette. Body: question + options.
Bottom: PREVIOUS · NEXT · MARK FOR REVIEW · SUBMIT TEST. Submit → confirmation
dialog: "ARE YOU SURE YOU WANT TO SUBMIT?" with UNATTENDED n / MARKED FOR REVIEW n
and SUBMIT TEST / CONTINUE TEST.

## 24. Result screen

TOTAL SCORE (612/720) · CORRECT (158) · WRONG (12) · UNATTEMPTED (10) ·
ACCURACY (89%) · TIME TAKEN.

## 25. Error analysis system

Classify every mistake: CONCEPTUAL / FACTUAL / CALCULATION / SILLY / MISREAD
QUESTION / GUESSWORK. Each category shows number of mistakes, affected topics,
recommended action. Example: "CONCEPTUAL MISTAKES — 12 Questions — Weak Topics: …"

25 tail (sample): affected topics e.g. Rotational Motion, Electrostatics;
Recommended action: Revise Concepts / Solve 50 Questions / Attempt PYQs.

## 26. Weak topic detection

Automatically identify: weak chapters, weak subjects, frequently wrong topics,
low-accuracy topics, slow-solving topics, guesswork topics. UI block:
"YOUR WEAK TOPICS" → topic (e.g. ROTATIONAL MOTION) → Accuracy 48% →
Recommended Practice: 50 Questions / 20 PYQs / 1 Revision Session →
START IMPROVEMENT.

## 27. Analytics screen

Title "PERFORMANCE ANALYTICS". Show: Total Score, Accuracy, Study Time,
Questions Solved, PYQs Completed, Tests Attempted, Current Streak.

## 28. Subject performance

Animated progress bars per subject, e.g. PHYSICS 68% / CHEMISTRY 82% /
BOTANY 91% / ZOOLOGY 88%.

## 29. Performance charts

Weekly Study Chart, Monthly Progress, Subject Accuracy, Test Score Trend,
Question Solving Trend, Weak Topic Trend. Do not overload one screen with
charts — use sections.

## 30. NEET command center

Futuristic dashboard. Show: NEET TARGET / Target Score / Current Estimated
Score / Study Streak / Study Hours / Questions Solved / PYQs Completed /
Weak Topics / Upcoming Test. Example panel: "NEET COMMAND CENTER — TARGET
SCORE 700+ — CURRENT PERFORMANCE 612 — STUDY STREAK 12 DAYS — TODAY'S STUDY
6 HOURS 20 MINUTES".

## 31–32. AI Mentor

Dedicated screen. Title "NEET AI MENTOR", status "AI READY". Quick actions:
SOLVE QUESTION · EXPLAIN CONCEPT · NCERT EXPLANATION · CREATE STUDY PLAN ·
FORMULA HELP · PYQ ANALYSIS · WEAK TOPIC ANALYSIS. Layout: title top,
animated AI orb center, "ASK ANYTHING ABOUT NEET", quick-suggestion chips
("Explain this Physics Question", "Teach this Biology Topic", "Create Today's
Study Plan", "Analyze My Mistakes"), bottom input: "ASK NEET AI" box + voice
button + send button.

## 33. AI animation states

Idle = slow breathing glow; Thinking = moving dots; Processing = small rotating
indicator; Answering = text gradually appears; Success = small check. No
excessive animation — intelligent and professional.

## 34. Floating AI button

One floating button ("AI HELP"). Tap expands a menu: SOLVE QUESTION · EXPLAIN
CONCEPT · FORMULA HELP · ASK DOUBT · STUDY PLAN. Prevents AI buttons everywhere.

## 35–36. Planner screen + features

Title "STUDY PLANNER" — daily timeline (e.g. 9:00 AM PHYSICS LECTURE
COMPLETED, 11:00 AM PHYSICS DPP PENDING, 2:00 PM CHEMISTRY PYQ, 7:00 PM
REVISION). Features: Add/Edit/Delete task, Set Priority, Set Time, Set
Reminder, Mark Complete, Carry Forward, Repeat Task. Categories: LECTURE ·
DPP · PYQ · REVISION · TEST · NOTES.

## 37–38. Revision center + spaced revision

Title "REVISION CENTER". Sections: TODAY'S REVISION · WEAK TOPIC REVISION ·
NCERT REVISION · FORMULA REVISION · PYQ REVISION · MISTAKE REVISION ·
BOOKMARKED QUESTIONS. Spaced revision schedule example: Day 1 learn → Day 2
quick revision → Day 7 → Day 21 → Day 45 final. Show reminders, revision
completion, pending revisions.

## 39. Notes screen

Per-subject notes: PHYSICS / CHEMISTRY / BOTANY / ZOOLOGY NOTES. Actions:
BOOKMARK · SEARCH · FAVORITE · IMPORTANT · REVISION.

## 40. Formula center

PHYSICS FORMULAS · PHYSICAL CHEMISTRY FORMULAS · IMPORTANT CONSTANTS · UNIT
CONVERSIONS · SHORT TRICKS. Allow Search · Bookmark · Practice Formula ·
Random Formula Quiz.

## 41. Card animations (staggered entry)

Screen open: Card 1 appears first, Card 2 at +80 ms, Card 3 at +160 ms,
Card 4 at +240 ms. Animation = fade in + slide up + small scale, 250–400 ms.

## 42. Button animation

Normal 100% → Pressed 96% → Released 100%, 100–150 ms, smooth. (Already the
Fx.press pattern.)

## 43. Screen transitions

HOME → SUBJECT: slide + fade. SUBJECT → CHAPTER: shared card animation.

## 43 tail (transitions, concluded)

CHAPTER → PRACTICE: smooth slide. Open bottom sheet = slide up; close =
slide down. BACK = reverse animation. Fast transitions, 200–350 ms.

## 44. Progress animation

All progress bars animate smoothly 0→25→50→75→100%, 500 ms–1 s. Not too slow.
(Already the Ui.addProgressRow fill, ~550 ms.)

## 45. Study streak animation

On opening Home: fire icon + "12 DAY STREAK", small flame animation. When a new
streak day completes: small achievement animation. No full-screen animation
every day.

## 46. Task completion animation

On complete: checkbox scales, checkmark appears, task fades slightly, progress
updates. Small success feedback only.

## 47. Loading screen

Never just "Loading...". Instead show staged copy: "NEET CRACKER — Preparing
Your Study System / Loading NCERT / Preparing Dashboard / Loading PYQ Bank /
Analyzing Progress / Starting AI Mentor". Use skeleton loading for cards.

## 48. Skeleton loading

Before data loads show placeholder cards, placeholder text, placeholder charts,
smooth loading transition. Avoid blank white screens.

## 49. Empty state design

No data → show icon + title + description + action button. Example:
"NO TESTS ATTEMPTED YET — Start your first test and track your performance. —
START TEST".

## 50. Notification center

Show: TODAY'S TASK REMINDER · REVISION DUE · UPCOMING TEST · STUDY STREAK ·
WEAK TOPIC ALERT · NEW PYQ AVAILABLE. Don't send unnecessary notifications.

## 51. Achievement system

Badges with progress: FIRST TEST · 1000 QUESTIONS · 7 DAY STREAK · 30 DAY
STREAK · PYQ MASTER · BIOLOGY MASTER · PHYSICS MASTER · REVISION KING.

## 52. Profile screen

Show: profile image, student name, NEET target, study streak, total study time,
questions solved, tests attempted, accuracy. Sections: MY PROGRESS ·
ACHIEVEMENTS · SETTINGS · BACKUP · ABOUT NEET CRACKER.

## 53. Settings screen

Sections: APPEARANCE · NOTIFICATIONS · STUDY SETTINGS · TEST SETTINGS · AI
SETTINGS · DATA BACKUP · PRIVACY · ABOUT.

## 54. Dark mode

LIGHT MODE · DARK MODE · SYSTEM DEFAULT. Smooth transition, save preference.

## 55. Visual design rules

Use: modern cards, rounded corners, proper spacing, minimal shadows, clear
typography, large important numbers, small supporting text, consistent icons,
consistent button style. Avoid: too many colors, too many buttons, too much
text, large shadows, random animations, different icon styles, crowded screens.

## 56. Home screen priority order

1 Greeting → 2 Study streak → 3 Today's progress → 4 Continue studying → 5 Quick
actions → 6 Today's tasks → 7 Upcoming test → 8 Weak topic → 9 Recent activity.
Order guides the student to studying immediately.

## 57. Complete user flow

SPLASH → ONBOARDING → PROFILE SETUP → HOME DASHBOARD → STUDY → SUBJECT →
CHAPTER → LECTURE OR NOTES → PRACTICE → PYQ OR DPP → TEST → RESULT → ERROR
ANALYSIS → WEAK TOPIC DETECTION → REVISION PLAN → IMPROVEMENT.

## 58. Main app structure

HOME (Today's tasks, Continue studying, Quick actions, Study streak, Upcoming
test). STUDY (PHY/CHEM/BOT/ZOO). PRACTICE (PYQ, DPP, Chapter questions, Weak
topics, Custom practice). TEST (Part, Full, Custom, Previous tests). ANALYTICS
(Score, Accuracy, Subject performance, Weak topics, Mistake analysis, Score
trend). REVISION (Today, Spaced revision, Weak topics, NCERT, Mistakes).
AI MENTOR (Solve question, Explain concept, NCERT help, Study plan, Analysis).
NOTE: STUDY/TEST/REVISION are secondary zones — they are NOT bottom-nav keys
(see §2/§59), so they're reached from Home quick actions + elsewhere.

## 59. Important key arrangement (final)

Bottom nav (4): HOME · PRACTICE · ANALYTICS · PROFILE. Floating button: NEET
AI. Top bar: MENU · SCREEN TITLE · NOTIFICATION. Never more than 4–5 major
navigation actions on one screen.

<!-- SPEC COMPLETE as of this paste (sections 1–59, message ending §59).
Marker kept at true tail; append only genuinely new sections. -->
