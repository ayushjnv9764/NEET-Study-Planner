#!/usr/bin/env bash
# Manual NEET CRACKER v2 build — sidesteps the Gradle/AGP daemon (OOM-killed at 2GB cgroup).
# Pipeline: aapt2 compile+link -> javac R -> kotlinc -> d8 -> merge dex -> zipalign -> apksigner
# One JVM at a time, heaps capped. Everything in build2/scratch, output NEET-CRACKER-v6.1.apk
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
OUT="$ROOT/NEET-CRACKER-v10.8.apk"

AAPT2="$ROOT/.tools/aapt2"                          # qemu-wrapped x86_64 aapt2
BT="$ROOT/.tools/android-sdk/build-tools/34.0.0"
ANDROID_JAR="$ROOT/.tools/android-sdk/platforms/android-34/android.jar"
JDK="$ROOT/.tools/jdk"
QEMU="$ROOT/.tools/emu/qemu-x86_64"
SYSROOT="$ROOT/.tools/emu/sysroot"
KC="$ROOT/.tools/kotlin/kotlin-compiler-embeddable-1.9.22.jar"
STDLIB="$ROOT/.tools/kotlin/kotlin-stdlib-1.9.22.jar"
SRC="app/src/main/java/com/ayush/neetcracker"
MANIFEST_SRC="app/src/main/AndroidManifest.xml"
KS="$ROOT/.tools/keys/debug.keystore"   # durable signing key (lives in project, not ~/.android)

TROVE="$ROOT/.tools/kotlin/trove4j-1.0.20200330.jar"
S="$ROOT/build2/scratch"
rm -rf "$ROOT/build2"; mkdir -p "$S/gen" "$S/classes" "$S/dex"

export JAVA_HOME="$JDK"
export PATH="$JDK/bin:$PATH"
export _JAVA_OPTIONS="-XX:+UseSerialGC -Xmx900m"

echo "── [1/8] aapt2 compile resources"
"$AAPT2" compile --dir app/src/main/res -o "$S/res.zip"

echo "── [2/8] manifest + aapt2 link"
python3 - "$MANIFEST_SRC" "$S/AndroidManifest.xml" <<'PY'
import re,sys
src,dst=sys.argv[1],sys.argv[2]
m=open(src).read()
if 'package=' not in m:
    m=m.replace('<manifest ', '<manifest package="com.ayush.neetcracker" ', 1)
open(dst,'w').write(m)
PY
"$AAPT2" link -o "$S/base.apk" -I "$ANDROID_JAR" \
    --manifest "$S/AndroidManifest.xml" \
    --java "$S/gen" --auto-add-overlay \
    -A "$ROOT/app/src/main/assets" \
    --min-sdk-version 24 --target-sdk-version 34 \
    --version-code 62 --version-name 10.8 \
    "$S/res.zip"

echo "── [3/8] javac R.java"
"$JDK/bin/javac" -cp "$ANDROID_JAR" -d "$S/classes" "$S/gen/com/ayush/neetcracker/R.java"

echo "── [4/8] kotlinc (heap capped)"
ANNOT="$ROOT/.tools/kotlin/annotations-13.0.jar"
"$JDK/bin/java" -Xmx1100m -XX:+UseSerialGC -cp "$KC:$STDLIB:$TROVE:$ANNOT" \
    org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -jvm-target 17 -nowarn -no-stdlib -no-reflect \
    -cp "$ANDROID_JAR:$S/classes:$STDLIB" \
    -d "$S/classes" \
    $(find "$SRC" -name '*.kt')

echo "── [5/8] jar classes + d8 -> dex"
"$JDK/bin/jar" --create --file "$S/app.jar" -C "$S/classes" .
"$BT/d8" --release --min-api 24 --lib "$ANDROID_JAR" --output "$S/dex" "$S/app.jar" "$STDLIB"

echo "── [6/8] merge classes.dex into apk"
python3 - "$S/base.apk" "$S/dex/classes.dex" "$S/unsigned.apk" <<'PY'
import sys,zipfile
base,dex,out=sys.argv[1],sys.argv[2],sys.argv[3]
zin=zipfile.ZipFile(base)
zout=zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)
for i in zin.infolist():
    zout.writestr(i, zin.read(i.filename))
zout.write(dex,'classes.dex')
zout.close(); zin.close()
print('merged, entries ok')
PY

echo "── [7/8] zipalign + apksigner"
"$QEMU" -L "$SYSROOT" "$BT/zipalign" -f 4 "$S/unsigned.apk" "$S/aligned.apk"
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:android \
    --ks-key-alias androiddebugkey --key-pass pass:android \
    --out "$OUT" "$S/aligned.apk"

echo "── [8/8] verify"
"$BT/apksigner" verify --print-certs "$OUT" 2>&1 | head -5
python3 - "$S/dex/classes.dex" <<'PY'
import sys
b=open(sys.argv[1],'rb').read()
for cls in (b'Lcom/ayush/neetcracker/MainActivity;', b'Lcom/ayush/neetcracker/Store;', b'Lcom/ayush/neetcracker/ExamActivity;', b'Lcom/ayush/neetcracker/ReviewActivity;', b'Lcom/ayush/neetcracker/RevisionActivity;', b'Lcom/ayush/neetcracker/FiltersActivity;', b'Lcom/ayush/neetcracker/WeakTopicsActivity;', b'Lcom/ayush/neetcracker/PyqActivity;'):
    print(('OK ' if cls in b else 'MISSING ')+cls.decode())
PY
ls -la "$OUT"
echo "BUILD DONE"
